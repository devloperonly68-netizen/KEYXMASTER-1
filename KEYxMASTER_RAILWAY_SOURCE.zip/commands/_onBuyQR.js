/**#command
name: /onBuyQR
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  if (!content) { 
    Api.sendMessage({ 
      chat_id: chat.chatid, 
      text: "❌ Error: No response from payment server. Please try again later.", 
      parse_mode: "HTML" 
    }); 
    return; 
  }

  var res;
  try {
    res = (typeof content === "object") ? content : JSON.parse(content);
  } catch (parseErr) {
    Api.sendMessage({
      chat_id: chat.chatid,
      text: "❌ <b>QR Parse Failed</b>\n<code>" + String(content).substring(0, 500) + "</code>",
      parse_mode: "HTML"
    });
    return;
  }

  if (!res || res.status !== "success" || !res.data) {
    Api.sendMessage({
      chat_id: chat.chatid,
      text: "<tg-emoji emoji-id='6219547832169273793'>❌</tg-emoji><b>QR Generation Failed</b>\n<code>" + JSON.stringify(res).substring(0, 500) + "</code>",
      parse_mode: "HTML"
    });
    return;
  }

  var order_id = res.data.order_id || res.data.orderid;
  var qr = res.data.qr_url || res.data.qrurl;
  var expire = res.data.expires_at_ist || res.data.expiresatist || "5 Minutes";
  var userId = user.telegramid;

  var price = Number(User.getProperty("buy_price") || 0);
  var userBal = Number(Libs.ResourcesLib.userRes("balance").value() || 0);
  var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
  var totalUserBal = userBal + bonusBal;

  var needpay = Number(User.getProperty("buy_needpay") || (price > totalUserBal ? price - totalUserBal : 0));
  var prodName = User.getProperty("buy_prod_name") || "Product";

  try {
    var genMsgid = Bot.getProperty("gen_msg_id_" + userId);
    if (genMsgid) {
      Api.deleteMessage({ chat_id: chat.chatid, message_id: genMsgid });
      Bot.setProperty("gen_msg_id_" + userId, null, "string");
    }
  } catch (e) {}

  var gatewayMsg = 
    "<tg-emoji emoji-id='6267225207560214192'>⚠️</tg-emoji><b>PAYMENT GATEWAY</b>\n\n" +
    "<tg-emoji emoji-id='6147767796097884213'>🏷️</tg-emoji><b>Product:</b> " + prodName + "\n" +
    "<tg-emoji emoji-id='6041705726206808304'>💰</tg-emoji><b>Price:</b> ₹" + price.toFixed(2) + "\n" +
    "<tg-emoji emoji-id='5348392971207194994'>💳</tg-emoji><b>Balance:</b> ₹" + totalUserBal.toFixed(2) + "\n" +
    "<tg-emoji emoji-id='619491118249881916'>📥</tg-emoji><b>Pay Now:</b> ₹" + needpay.toFixed(2) + "\n" +
    "<tg-emoji emoji-id='6266866272848321043'>⏳</tg-emoji><b>Expire Time:</b> <code>" + expire + "</code>\n\n" +
    "<tg-emoji emoji-id='5330237710655306682'>⚡</tg-emoji><b>Scan QR & pay exact amount</b>\n";

  var inlineButtons = [
    [
      {
        text: "I have paid",
        callback_data: "/check_buy " + order_id,
        style: "success",
        icon_custom_emoji_id: "5330237710655306682"
      },
      {
        text: "Cancel Order",
        callback_data: "/cancel_buy " + order_id,
        style: "danger",
        icon_custom_emoji_id: "6219547832169273793"
      }
    ]
  ];

  var sentQrMsg;
  try {
    sentQrMsg = Api.sendPhoto({
      chat_id: chat.chatid,
      photo: qr,
      caption: gatewayMsg,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: inlineButtons })
    });
  } catch (photoErr) {
    Api.sendMessage({
      chat_id: chat.chatid,
      text: "❌ <b>sendPhoto failed</b>\nQR URL: <code>" + qr + "</code>\nError: <code>" + photoErr.message + "</code>",
      parse_mode: "HTML"
    });
    return;
  }

  try {
    if (sentQrMsg) {
      var qrMsgId = sentQrMsg.result ? sentQrMsg.result.message_id : sentQrMsg.message_id;
      if (qrMsgId) {
        Bot.setProperty("buy_qr_msg_id_" + userId, qrMsgId, "string");
        User.setProperty("buy_pending_order_id", order_id, "string");
      }
    }
  } catch (e) {}
} catch (err) {
  Api.sendMessage({
    chat_id: chat.chatid,
    text: "⚠️ <b>System Error:</b> <code>" + (err && err.message ? err.message : String(err)) + "</code>",
    parse_mode: "HTML"
  });
}