/**#command
name: /onCheck
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var opts = (typeof options !== "undefined" && options) ? options : {};
  let isBackground = opts.is_background || false;
  let orderId = opts.order_id;
  let amount = opts.amount;
  let chatId = chat ? chat.chatid : null;
  let attempt = opts.attempt || 1;

  if (typeof params !== "undefined" && params && params.trim() !== "") {
    let splitParams = params.trim().split(" ");
    if (splitParams.length >= 1 && splitParams[0].length > 5) {
      orderId = splitParams[0];
    }
    if (splitParams.length >= 2) amount = splitParams[1];
  }

  let targetUserId = (typeof user !== "undefined" && user) ? user.telegramid : null;

  // 🛠️ ULTIMATE FALLBACK: Agar button ya params se orderId na mile, toh active pending order ID utha lo!
  if ((!orderId || orderId.trim() === "") && targetUserId) {
    orderId = User.getProperty("pending_order_id") || 
              Bot.getProperty("qr_order_id_" + targetUserId) || 
              User.getProperty("qr_order_id_" + targetUserId) ||
              User.getProperty("buy_pending_order_id");
  }

  let queryId = null;
  if (typeof request !== "undefined" && request) {
    if (request.callback_query && request.callback_query.id) {
      queryId = request.callback_query.id;
    } else if (request.id) {
      queryId = request.id;
    }
  }

  // 🎨 Premium emojis
  let e_chart = "<tg-emoji emoji-id='5992430854909989581'>📊</tg-emoji>";
  let e_plus = "<tg-emoji emoji-id='5346004239246183111'>➕</tg-emoji>";
  let e_arrow = "<tg-emoji emoji-id='5875506366050734240'>➡️</tg-emoji>";
  let e_coin = "<tg-emoji emoji-id='5778335621491723621'>🪙</tg-emoji>";
  let e_money = "<tg-emoji emoji-id='5348392971207194994'>💰</tg-emoji>";
  let e_time = "<tg-emoji emoji-id='5776213190387961618'>🕓</tg-emoji>";
  let e_check = "<tg-emoji emoji-id='5330237710655306682'>✅</tg-emoji>";

  function vanishQrMessage(uid, fallbackChatId) {
    try {
      let qrMsgId = Bot.getProperty("qr_msg_id_" + uid) ||
                    User.getProperty("qr_msg_id_" + uid) ||
                    User.getProperty("last_qr_message_id_" + uid);
      if (qrMsgId) {
        try { Api.deleteMessage({ chat_id: fallbackChatId, message_id: qrMsgId }); } catch (e) {}
      }
    } catch (e) {}
  }

  function clearQrState(uid) {
    Bot.setProperty("qr_msg_id_" + uid, null, "string");
    User.setProperty("qr_msg_id_" + uid, null, "string");
    User.setProperty("last_qr_message_id_" + uid, null, "string");
    Bot.setProperty("qr_order_id_" + uid, null, "string");
    User.setProperty("qr_order_id_" + uid, null, "string");
    Bot.setProperty("qr_watch_order_" + uid, null, "string");
    User.setProperty("qr_watch_order_" + uid, null, "string");
    Bot.setProperty("verifying_lock_" + uid, false, "boolean");
    User.setProperty("verifying_lock_" + uid, false, "boolean");
    User.setProperty("topup_verifying_lock_" + uid, false, "boolean");
    User.setProperty("pending_order_id", null);
  }

  function getUnifiedBalance(uid) {
    let resBal = 0;
    try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
    let bonusBal = Number(Bot.getProperty("balance" + uid) || 0);
    return resBal + bonusBal;
  }

  // ✅ STEP 1: Strict Order ID validation check
  if (!orderId || orderId.trim() === "") {
    if (queryId) {
      try {
        Api.answerCallbackQuery({
          callback_query_id: queryId,
          text: "⚠️ Active order nahi mila. Kripya pehle naya QR generate karein.",
          show_alert: true
        });
      } catch (e) {}
    }
    return;
  }

  // ✅ STEP 2: Duplicate Claim Check
  if (Bot.getProperty("claimed_topup_" + orderId)) {
    vanishQrMessage(targetUserId, chatId);
    if (targetUserId) clearQrState(targetUserId);

    if (queryId) {
      try {
        Api.answerCallbackQuery({
          callback_query_id: queryId,
          text: "✅ ALREADY CLAIMED ✅\nYe payment pehle hi verify hokar balance me add ho chuki hai.",
          show_alert: true
        });
      } catch (e) {}
    }
    return;
  }

  if (targetUserId && !isBackground) {
    let isChecking = User.getProperty("topup_verifying_lock_" + targetUserId);
    if (isChecking) {
      if (queryId) {
        try {
          Api.answerCallbackQuery({
            callback_query_id: queryId,
            text: "⏳ VERIFYING... PLEASE WAIT...",
            show_alert: true
          });
        } catch (e) {}
      }
      return;
    }
    User.setProperty("topup_verifying_lock_" + targetUserId, true, "boolean");
  }

  let responseData = (typeof content !== "undefined" && content) ? (typeof content === "object" ? content : JSON.parse(content)) : null;

  if (responseData && (responseData.status === "success" || responseData.status === "SUCCESS") && responseData.data) {

    // ✅ STEP 3: Mark claimed only NOW that payment is confirmed successful
    // (avoids race conditions on concurrent success calls, without falsely
    // locking out an order that hasn't actually been paid yet)
    if (Bot.getProperty("claimed_topup_" + orderId)) {
      // Someone else already processed this exact order in parallel — bail out
      if (targetUserId) User.setProperty("topup_verifying_lock_" + targetUserId, false, "boolean");
      return;
    }
    Bot.setProperty("claimed_topup_" + orderId, true, "boolean");

    let txData = responseData.data;
    let txAmount = txData.amount || amount;
    let utr = txData.utr || txData.transaction_id || "N/A";
    let senderName = txData.sender_name || (typeof user !== "undefined" && user ? user.first_name : "Valued User");
    let payTime = txData.payment_time_ist || "N/A";
    let addedAmount = parseFloat(txAmount) || 0;

    try {
      Libs.ResourcesLib.userRes("balance").add(addedAmount);
    } catch (e) {}
    let newBalance = getUnifiedBalance(targetUserId);

    // ==========================================
    // 🎁 REFER & EARN — referrer bonus jab referred friend PEHLI baar
    // balance add kare (sirf ek baar, farming rokne ke liye)
    // ==========================================
    try {
      let referredByTopup = User.getProperty("referred_by");
      if (referredByTopup && !User.getProperty("ref_topup_bonus_given")) {
        let refBonusTopup = Number(Bot.getProperty("refer_earn_topup_amount"));
        if (isNaN(refBonusTopup)) refBonusTopup = 2;
        if (refBonusTopup > 0) {
          Libs.ResourcesLib.anotherUserRes("balance", referredByTopup).add(refBonusTopup);
          let pastEarnTopup = Number(Bot.getProperty("refer_earnings_" + referredByTopup) || 0);
          Bot.setProperty("refer_earnings_" + referredByTopup, pastEarnTopup + refBonusTopup, "number");
          try {
            Api.sendMessage({
              chat_id: referredByTopup,
              text: "<blockquote>💸 <b>Referral Bonus!</b>\n\nAapke referred friend ne balance add kiya — aapko ₹" + refBonusTopup.toFixed(2) + " mile hain!</blockquote>",
              parse_mode: "HTML"
            });
          } catch (e) {}
        }
        User.setProperty("ref_topup_bonus_given", true, "boolean");
      }
    } catch (e) {}

    // 🔔 Admin notification for wallet balance top-up
    try {
      let walletLogAdminId = Bot.getProperty("owner_id") || "7088682169";
      let walletAdminMsg = "<blockquote>" +
        "🔔 <b>WALLET BALANCE ADDED</b> ✔️\n\n" +
        "👤 <b>User:</b> " + senderName + " (<code>" + targetUserId + "</code>)\n" +
        "💰 <b>Amount Added:</b> ₹" + addedAmount.toFixed(2) + "\n" +
        "🧾 <b>UTR:</b> <code>" + utr + "</code>\n" +
        "🆔 <b>Order ID:</b> <code>" + orderId + "</code>" +
        "</blockquote>";
      Api.sendMessage({ chat_id: walletLogAdminId, text: walletAdminMsg, parse_mode: "HTML" });
    } catch (e) {}

    if (queryId) {
      try {
        Api.answerCallbackQuery({
          callback_query_id: queryId,
          text: "✅ PAYMENT VERIFIED SUCCESSFULLY!",
          show_alert: false
        });
      } catch (e) {}
    }

    if (targetUserId) {
      vanishQrMessage(targetUserId, chatId);
      clearQrState(targetUserId);
    }

    if (User.getProperty("buy_reseller_upgrade")) {
      let resellerPrice = Number(User.getProperty("buy_reseller_price") || 0);
      User.setProperty("buy_reseller_upgrade", null, "boolean");
      User.setProperty("buy_reseller_price", null, "number");

      Bot.setProperty("is_reseller_" + targetUserId, true, "boolean");

      Api.sendMessage({
        chat_id: chatId,
        text: "<blockquote><tg-emoji emoji-id='6102856637343600044'>🎉</tg-emoji> <b>CONGRATULATIONS!</b></blockquote>\n\n" +
              "<tg-emoji emoji-id='6215386799133433653'>👑</tg-emoji> <b>You are now a Reseller!</b>\n\n" +
              "<i>Payment verified aur permanent reseller status activate ho gaya!</i>",
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "Explore Shop", callback_data: "/buy_hack", style: "success" }]] })
      });

      if (targetUserId) User.setProperty("topup_verifying_lock_" + targetUserId, false, "boolean");
      return;
    }

    let pendingProdIdx = User.getProperty("buy_prod_idx");
    let pendingPlanIdx = User.getProperty("buy_plan_idx");

    if (pendingProdIdx !== null && pendingProdIdx !== undefined && pendingProdIdx !== "" &&
        pendingPlanIdx !== null && pendingPlanIdx !== undefined && pendingPlanIdx !== "") {

      Api.sendMessage({ 
        chat_id: chatId, 
        text: e_check + " <b>Payment verified! Generating your key now...</b>", 
        parse_mode: "HTML" 
      });

      Bot.run({
        command: "/confirm_buyitem",
        options: { params: pendingProdIdx + " " + pendingPlanIdx }
      });

      User.setProperty("buy_prod_idx", null);
      User.setProperty("buy_plan_idx", null);
      User.setProperty("buy_price", null);
      User.setProperty("buy_needpay", null);

      if (targetUserId) User.setProperty("topup_verifying_lock_" + targetUserId, false, "boolean");
      return;
    }

    let successText = "━━━━━━━━━━━━━━━━━━━━\n" +
                      e_plus + " <b>PAYMENT SUCCESSFUL</b> " + e_plus + "\n" +
                      "━━━━━━━━━━━━━━━━━━━━\n\n" +
                      e_money + " <b>Added Amount:</b> ₹<b>" + addedAmount.toFixed(2) + "</b>\n" +
                      e_chart + " <b>New Balance:</b> ₹<b>" + newBalance.toFixed(2) + "</b>\n" +
                      e_arrow + " <b>UTR / Ref ID:</b> <code>" + utr + "</code>\n" +
                      e_time + " <b>Time:</b> " + payTime + "\n\n" +
                      "━━━━━━━━━━━━━━━━━━━━\n" +
                      e_coin + " <i>Your funds have been successfully credited! 🎉</i>";

    Api.sendMessage({
      chat_id: chatId,
      text: successText,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({
        inline_keyboard: [[
          { text: "🛒 Shop Now", callback_data: "/buy_hack", style: "success" },
          { text: "🔰 Profile", callback_data: "/profile", style: "primary" }
        ]]
      })
    });

    if (targetUserId) User.setProperty("topup_verifying_lock_" + targetUserId, false, "boolean");
    return;
  }

  if (queryId && !isBackground) {
    try {
      Api.answerCallbackQuery({
        callback_query_id: queryId,
        text: "⚠️ PAYMENT NOT RECEIVED YET\nPlease complete the payment first.",
        show_alert: true
      });
    } catch (e) {}
  }

  if (targetUserId) User.setProperty("topup_verifying_lock_" + targetUserId, false, "boolean");

} catch (err) {
  try {
    let uid = (typeof user !== "undefined" && user) ? user.telegramid : null;
    if (uid) User.setProperty("topup_verifying_lock_" + uid, false, "boolean");
  } catch (e) {}
  Bot.sendMessage("⚠️ Error in verification check: " + err.message);
}