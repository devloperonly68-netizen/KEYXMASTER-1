/**#command
name: /allstocks
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  // 🔥 CALLBACK DATA CLEARING PIPELINE (Bypass loading spinner on buttons)
  if (typeof request !== "undefined" && request) {
    let queryId = request.id || (request.callback_query && request.callback_query.id);
    if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: queryId }); } catch(qErr){} }
  }

  var adminId = "7088682169";
  var targetChatId = (chat && chat.chatid) ? chat.chatid : ((user && user.telegramid) ? user.telegramid : adminId);

  if (String(targetChatId) !== adminId) {
      Api.sendMessage({ chat_id: targetChatId, text: "❌ Access Denied: Secure admin perimeter restricted." });
      return;
  }

  var categories = Bot.getProperty("ff_categories") || {};
  var keys = Object.keys(categories);

  if (keys.length === 0) {
    Api.sendMessage({
      chat_id: targetChatId,
      text: "📦 <b>Database status: EMPTY</b>\n\nAbhi system parameters mein koi category mapped nahi hai.",
      parse_mode: "HTML"
    });
    return;
  }

  var stockText = "<blockquote>🔍 <b>LIVE SYSTEM ID STOCK REPORT</b>\n\n<i>Live database nodes status evaluation:</i></blockquote>\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n";

  for (var i = 0; i < keys.length; i++) {
    var slug = keys[i];
    var cat = categories[slug];
    var stockList = Bot.getProperty("ff_stock_" + slug) || [];
    if (!Array.isArray(stockList)) { stockList = []; }
    
    var count = stockList.length;
    var emoji = (cat.emoji_id) ? "<tg-emoji emoji-id='" + cat.emoji_id + "'>🔹</tg-emoji>" : "🔹";
    
    stockText += emoji + " <b>" + (cat.name || slug).toUpperCase() + ":</b> <code>" + count + " Items In Stock</code>\n";
  }

  stockText += "━━━━━━━━━━━━━━━━━━━━━━━━━━\n🎯 <i>Stock operations adjust karne ke liye physical dashboard console parameters use karein.</i>";

  Api.sendMessage({
    chat_id: targetChatId,
    text: stockText,
    parse_mode: "HTML"
  });

} catch(e) {
  var backupId = (user && user.telegramid) ? user.telegramid : "7088682169";
  Api.sendMessage({ chat_id: backupId, text: "⚠️ System Runtime Error: " + e.message });
}