/**#command
name: /onPreCheckoutQuery
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// ⭐ Handles Telegram's pre_checkout_query event (Stars payments).
// MUST answer within 10 seconds or the payment is auto-cancelled by Telegram.
// ⚠️ PLATFORM NOTE: This file assumes Bots.Business routes incoming
// pre_checkout_query updates to a command named "/onPreCheckoutQuery" or
// exposes it via `request.pre_checkout_query`. If this event isn't reaching
// this file in testing, the same handling logic is duplicated as a fallback
// inside _start.js (which appears to be the platform's general message router).
// =========================================================

try {
  var pcq = (request && request.pre_checkout_query) ? request.pre_checkout_query : null;
  if (!pcq) { return; }

  // ✅ Always approve — our payloads are self-validated at successful_payment time.
  // (If you later want to reject e.g. out-of-stock items, check pcq.invoice_payload here first.)
  HTTP.post({
    url: "https://api.telegram.org/bot" + bot.token + "/answerPreCheckoutQuery",
    body: {
      pre_checkout_query_id: pcq.id,
      ok: true
    }
  });

} catch (err) {
  try {
    Bot.sendMessage("⚠️ PreCheckout Error: " + err.message);
  } catch (e2) {}
}