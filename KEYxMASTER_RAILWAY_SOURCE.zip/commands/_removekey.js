/**#command
name: /removekey
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169"; // Aapki Admin ID
  if (String(chat.chatid) !== adminId) return;

  if (!params) {
    Bot.sendMessage("❌ <b>Usage:</b>\n<code>/removekey PRODUCT NAME | DAYS</code>\n\n<i>Example: DRIP CLIENT | 1_Day</i>", { parse_mode: "HTML" });
    return;
  }

  var args = params.split("|");
  if (args.length < 2) {
    Bot.sendMessage("❌ <b>Format Error!</b> Use Pipe symbol:\n<code>/removekey PRODUCT NAME | DAYS</code>", { parse_mode: "HTML" });
    return;
  }

  var prodName = args[0].trim();
  var planDays = args[1].trim();
  var cleanPlanDays = planDays.includes("_Day") ? planDays : planDays + "_Day";

  var stockKeyText = "stock_" + prodName + "_" + cleanPlanDays;
  var keyStock = Bot.getProperty(stockKeyText) || [];

  if (keyStock.length === 0) {
    Bot.sendMessage("❌ Product: <b>" + prodName + " (" + cleanPlanDays + ")</b> ka stock already empty hai!", { parse_mode: "HTML" });
    return;
  }

  var inlineButtons = [];
  
  // Har ek key ke liye ek individual delete button banana
  for (var i = 0; i < keyStock.length; i++) {
    var fullKey = keyStock[i];
    // Display ke liye key ka chota part dikhana taaki button bada na ho
    var shortKey = fullKey.length > 15 ? fullKey.substring(0, 12) + "..." : fullKey; 
    
    inlineButtons.push([
      {
        text: "🗑️ Key " + (i + 1) + " [" + shortKey + "]",
        // Callback me parameters pass karna: index_number | prodName | planDays
        callback_data: "/deletekey_now " + i + "|" + prodName + "|" + cleanPlanDays
      }
    ]);
  }

  var menuText = "<blockquote><b>🗑️ SELECT KEY TO REMOVE</b>\n\n" +
                 "• <b>Product:</b> <code>" + prodName + "</code>\n" +
                 "• <b>Plan:</b> <code>" + cleanPlanDays + "</code>\n" +
                 "• <b>Total Keys:</b> <code>" + keyStock.length + "</code>\n\n" +
                 "<i>Niche diye gaye buttons me se jis key ko remove karna hai, uspar click karein:</i></blockquote>";

  Bot.sendMessage(menuText, {
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: inlineButtons })
  });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}