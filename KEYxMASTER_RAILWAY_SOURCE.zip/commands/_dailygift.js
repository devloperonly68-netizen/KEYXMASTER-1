/**#command
name: /dailygift
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🎁 DAILY GIFT — Fixed ₹1 reward, once every 24 hours per user.
// Same cooldown pattern as /ludospin, but fixed amount (not random).
// =========================================================

try {
  var userId = user.telegramid;
  var chatId = chat.chatid;

  var DAILY_GIFT_AMOUNT = Number(Bot.getProperty("daily_gift_amount")); // Admin-configurable
  if (isNaN(DAILY_GIFT_AMOUNT) || DAILY_GIFT_AMOUNT <= 0) DAILY_GIFT_AMOUNT = 1; // fallback ₹1

  // 🕒 24-HOUR COOLDOWN SYSTEM CORE
  var lastGiftTime = User.getProperty("last_daily_gift_time");
  var currentTime = new Date().getTime();
  var cooldownMs = 24 * 60 * 60 * 1000;

  if (lastGiftTime) {
    var timePassed = currentTime - Number(lastGiftTime);

    if (timePassed < cooldownMs) {
      var timeLeftMs = cooldownMs - timePassed;
      var totalSeconds = Math.floor(timeLeftMs / 1000);
      var hours = Math.floor(totalSeconds / 3600);
      var minutes = Math.floor((totalSeconds % 3600) / 60);
      var seconds = totalSeconds % 60;

      var cooldownText = "<blockquote>" +
                         "<tg-emoji emoji-id='5893163582194978381'>❌</tg-emoji> <b>ALREADY CLAIMED!</b>\n" +
                         "━━━━━━━━━━━━━━━━━━━━━\n\n" +
                         "👋 Hello <b>" + user.first_name + "</b>, aap aaj ka Daily Gift pehle hi claim kar chuke hain!\n\n" +
                         "<tg-emoji emoji-id='5260450573768990626'>➡️</tg-emoji> <b>Next Gift Available In:</b>\n" +
                         "<code>" + hours + " Hours, " + minutes + " Minutes, " + seconds + " Seconds</code>\n\n" +
                         "━━━━━━━━━━━━━━━━━━━━━\n" +
                         "<tg-emoji emoji-id='6194911182499881916'>🗣</tg-emoji> <i>Har user ko 24 ghante me sirf 1 Daily Gift milta hai.</i>" +
                         "</blockquote>";

      var cooldownButtons = [[
        { text: "Back to Menu", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
      ]];

      if (request && request.message && request.message.message_id) {
        Api.editMessageText({
          chat_id: String(chatId),
          message_id: Number(request.message.message_id),
          text: cooldownText,
          parse_mode: "HTML",
          reply_markup: JSON.stringify({ inline_keyboard: cooldownButtons })
        });
      } else {
        Api.sendMessage({
          chat_id: String(chatId),
          text: cooldownText,
          parse_mode: "HTML",
          reply_markup: JSON.stringify({ inline_keyboard: cooldownButtons })
        });
      }

      var qid0 = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
      if (qid0) { try { Api.answerCallbackQuery({ callback_query_id: String(qid0) }); } catch (e) {} }

      return; // Execution stops here
    }
  }

  // 💰 CREDIT FIXED REWARD TO USER WALLET
  Libs.ResourcesLib.userRes("balance").add(DAILY_GIFT_AMOUNT);

  // 💾 SAVE CURRENT TIME TO PREVENT NEXT CLAIM BEFORE 24H
  User.setProperty("last_daily_gift_time", currentTime, "number");

  var updatedBal = Libs.ResourcesLib.userRes("balance").value().toFixed(2);

  var giftText = "<blockquote>" +
                 "<tg-emoji emoji-id='6194922667242429131'>🎁</tg-emoji> <b>DAILY GIFT CLAIMED!</b>\n" +
                 "━━━━━━━━━━━━━━━━━━━━━\n\n" +
                 "<tg-emoji emoji-id='6102856637343600044'>🎉</tg-emoji> <b>Congratulations " + user.first_name + "!</b>\n" +
                 "<tg-emoji emoji-id='6064514463564831610'>💟</tg-emoji> <b>You Received:</b> <code>₹" + DAILY_GIFT_AMOUNT.toFixed(2) + "</code>\n\n" +
                 "━━━━━ <tg-emoji emoji-id='5346024644635804737'>🔰</tg-emoji> <b>WALLET UPDATE</b> ━━━━━\n" +
                 "<tg-emoji emoji-id='6064138396228392033'>💵</tg-emoji> <b>New Wallet Balance:</b> ₹" + updatedBal + "\n\n" +
                 "<tg-emoji emoji-id='6194911182499881916'>🗣</tg-emoji> <i>Come back after 24 hours for your next gift!</i>" +
                 "</blockquote>";

  var giftButtons = [[
    { text: "Back to Menu", callback_data: "/back", style: "success", icon_custom_emoji_id: "5893163582194978381" }
  ]];

  if (request && request.message && request.message.message_id) {
    Api.editMessageText({
      chat_id: String(chatId),
      message_id: Number(request.message.message_id),
      text: giftText,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: giftButtons })
    });
  } else {
    Api.sendMessage({
      chat_id: String(chatId),
      text: giftText,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: giftButtons })
    });
  }

  var qid1 = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (qid1) { try { Api.answerCallbackQuery({ callback_query_id: String(qid1) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ <b>Daily Gift System Error:</b> <code>" + err.message + "</code>", { parse_mode: "HTML" });
}
