/**#command
name: /resellerprice_id
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169";
  if (!chat || String(chat.chatid) !== adminId) return;

  // 🔥 CLEAR SPINNER IMMEDIATELY
  if (typeof request !== "undefined" && request) {
    let queryId = request.id || (request.callback_query && request.callback_query.id);
    if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: queryId }); } catch(qErr){} }
  }

  var rawInput = (typeof message !== "undefined" && message) ? message.trim() : "";
  if (!rawInput && typeof params !== "undefined" && params) { rawInput = String(params).trim(); }

  if (rawInput.indexOf("/resellerprice_id") === 0) {
    rawInput = rawInput.replace("/resellerprice_id", "").trim();
  }

  // 🛡️ NO REPLY CRASH FIX: Display interactive instruction if text missing
  if (!rawInput) {
    Api.sendMessage({
      chat_id: adminId,
      text: "✍️ <b>Set Reseller Price Node Matrix:</b>\n\nKripya is text ko copy karein, edit karein aur reply mein bhejiye:\n\n<code>/resellerprice_id [Category Name] [Price]</code>\n\n<b>Example:</b>\n<code>/resellerprice_id Facebook Id 120</code>",
      parse_mode: "HTML"
    });
    return;
  }

  var parts = rawInput.split(" ");
  if (parts.length < 2) {
    Api.sendMessage({
      chat_id: adminId,
      text: "⚠️ <b>Format Galat Hai!</b>\nSahi tarika: <code>Category_Name Price</code>\nExample: <code>Facebook Id 120</code>",
      parse_mode: "HTML"
    });
    return;
  }

  var price = parts[parts.length - 1].trim();
  var catName = parts.slice(0, -1).join(" ").trim();

  if (isNaN(price)) {
    Api.sendMessage({ chat_id: adminId, text: "⚠️ <b>Price ek valid number hona chahiye!</b>" });
    return;
  }

  var catSlug = catName.toLowerCase().replace(/[^a-z0-9]/g, "");
  var categories = Bot.getProperty("ff_categories") || {};

  if (!categories[catSlug]) {
    Api.sendMessage({ chat_id: adminId, text: "❌ <b>Category [ " + catName + " ] system records mein nahi mili!</b>" });
    return;
  }

  categories[catSlug].reseller_price = parseFloat(price);
  Bot.setProperty("ff_categories", categories, "json");

  Api.sendMessage({
    chat_id: adminId,
    text: "✅ <b>Reseller Price Updated Successfully!</b>\n\n• <b>Category:</b> <code>" + categories[catSlug].name + "</code>\n• <b>New Reseller Price:</b> <code>₹" + price + "</code>",
    parse_mode: "HTML"
  });

} catch(e) {
  Bot.sendMessage("Error in Set Reseller Price: " + e.message);
}