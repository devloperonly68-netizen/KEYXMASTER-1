/**#command
name: /onQRExpire
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var opts = (typeof options !== "undefined" && options) ? options : {};
  var userId = opts.userId || (typeof user !== "undefined" && user ? user.telegramid : null);
  var chatId = opts.chatId || (typeof chat !== "undefined" && chat ? chat.chatid : null);

  if (!userId || !chatId) { return; }

  var activeOrder = Bot.getProperty("qr_order_id_" + userId) || User.getProperty("qr_order_id_" + userId);
  var watchOrder = Bot.getProperty("qr_watch_order_" + userId) || User.getProperty("qr_watch_order_" + userId);
  var qrMsgId = Bot.getProperty("qr_msg_id_" + userId) || User.getProperty("qr_msg_id_" + userId);

  // ✅ Agar order already paid/cancelled ho chuka hai (activeOrder null ya watchOrder se alag), kuch mat karo
  if (!activeOrder || !watchOrder || String(activeOrder) !== String(watchOrder)) {
    return;
  }

  // ✅ UPDATED: ab koi "Order Expired" message nahi bheja jaata — QR bas
  // chupchaap vanish (delete) ho jaata hai jaise request kiya gaya tha.
  if (qrMsgId) {
    try { Api.deleteMessage({ chat_id: chatId, message_id: Number(qrMsgId) }); } catch (delErr) {}
  }

  // 🧹 Cleanup — order ab dead hai
  Bot.setProperty("qr_order_id_" + userId, null, "string");
  User.setProperty("qr_order_id_" + userId, null, "string");
  Bot.setProperty("qr_watch_order_" + userId, null, "string");
  User.setProperty("qr_watch_order_" + userId, null, "string");
  User.setProperty("pending_order_id", null);
  Bot.setProperty("verifying_lock_" + userId, false, "boolean");
  User.setProperty("verifying_lock_" + userId, false, "boolean");

} catch (err) {
  Bot.sendMessage("⚠️ Expiry Watcher Error: " + err.message);
}