/**#command
name: /balance
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
    // Current user ka balance nikalna
    let userBalance = Libs.ResourcesLib.userRes("balance").value();

    // Premium Emojis ke saath text (Quote Style me)
    let text = "<blockquote>" +
        "<tg-emoji emoji-id='6057881002540274780'>💀</tg-emoji> Your Balance: " + userBalance + " \n" +
        "<tg-emoji emoji-id='6192842983948162969'>ℹ️</tg-emoji> Account Status: Active\n" +
        "<tg-emoji emoji-id='6194729398009075708'>✨</tg-emoji> Keep Shopping!" +
        "</blockquote>";

    // Inline Keyboard layout jisme Colored (Primary) Button aur Nayi Custom Emoji ID set hai
    let keyboard = {
        inline_keyboard: [
            [
                {
                    text: "Back To Menu",
                    callback_data: "/back", 
                    style: "primary",      // Blue (Primary) Button Color
                    icon_custom_emoji_id: "5893163582194978381" // Nayi Custom Emoji ID button ke liye
                }
            ]
        ]
    };

    // Direct Telegram API Call
    HTTP.post({
        url: "https://api.telegram.org/bot" + bot.token + "/sendMessage",
        body: {
            chat_id: chat.chatid,
            text: text,
            parse_mode: "HTML",
            reply_markup: JSON.stringify(keyboard)
        }
    });

} catch (err) {
    Bot.sendMessage("⚠️ *Error:* " + err.message, { parse_mode: "Markdown" });
}