/**#command
name: /addbal
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// ✅ FIXED (v3): pehle admin_id hardcoded tha ("7088682169"), jabki baaki bot
// (start menu, /admin, ownership transfer) sab dynamic "owner_id" property use
// karte hain. Agar kabhi ownership transfer hua ya co-admin ne button dabaya,
// ye command silently "not authorized" de deta tha — isiliye "Add Bal" button
// theek se kaam nahi kar raha tha. Ab yahan bhi wahi dynamic check hai.
let admin_id = Bot.getProperty("owner_id") || "7088682169";
let requesterId = String(user.telegramid);
let isCoAdmin = Bot.getProperty("co_admin_" + requesterId);

if (requesterId === admin_id || isCoAdmin) {

    // ✅ FIXED: button dabate hi Telegram ka loading-spinner turant hata do,
    // taaki click "fast/responsive" mehsoos ho (pehle koi answerCallbackQuery
    // nahi tha, isliye button dabane par kuch second tak kuch nahi hota tha).
    if (request && request.id) {
        try {
            HTTP.post({
                url: "https://api.telegram.org/bot" + bot.token + "/answerCallbackQuery",
                body: { callback_query_id: request.id }
            });
        } catch (ackErr) {}
    }

    let params = (typeof message !== "undefined" && message) ? message.split(" ") : [];
    let data = params[1];

    // ✅ FIXED: pehle "Add Bal" admin-panel button dabane par ye seedha "Wrong
    // Format" error de deta tha (kyunki button koi text argument nahi bhejta),
    // aur admin ko turant type karna padta tha "/addbal id|amount" khud se.
    // Ab button dabane par ek proper prompt aata hai aur agla text message
    // auto-capture ho jaata hai (see _start.js "MODULE 5").
    if (!data || !data.includes("|")) {
        User.setProperty("addbal_step", "waiting_input", "string");
        Bot.sendMessage(
            "<tg-emoji emoji-id='5409048419211682843'>💵</tg-emoji> <b>Add Balance</b>\n\n" +
            "<i>User ID aur amount is format me reply karein:</i>\n<code>user_id|amount</code>\n\n" +
            "<i>Example:</i> <code>7088682169|100</code>",
            {parse_mode: "HTML"}
        );
        return;
    }

    let splitData = data.split("|");
    let targetUserId = splitData[0].trim();
    let amountToAdd = parseFloat(splitData[1].trim());

    if (!targetUserId || isNaN(amountToAdd) || amountToAdd <= 0) {
        Bot.sendMessage("❌ *Invalid Format! Use:* `user_id|amount`", {parse_mode: "Markdown"});
        return;
    }

    try {
        // Balance add karna
        let targetUserBalance = Libs.ResourcesLib.anotherUserRes("balance", targetUserId);
        targetUserBalance.add(amountToAdd);

        // Admin notification — turant confirm karo ki balance credit ho gaya
        Bot.sendMessage("✅ Success! Added " + amountToAdd + " to user " + targetUserId, {parse_mode: "HTML"});

        // All 4 Premium Emojis in Quote Style
        let notificationText =
            "<blockquote>" +
            "<tg-emoji emoji-id='6192822213486321961'>🗣</tg-emoji> Admin Added: " + amountToAdd + "\n" +
            "<tg-emoji emoji-id='6266967801580231067'>💎</tg-emoji> Balance Credited!\n" +
            "<tg-emoji emoji-id='6267068789146260253'>💰</tg-emoji> Wallet Updated\n" +
            "<tg-emoji emoji-id='5866053971960929280'>🛒</tg-emoji> /start TO SHOP NOW" +
            "</blockquote>";

        // ✅ FIXED: raw HTTP.post ki jagah bot ka built-in Api.sendMessage use kiya —
        // yahi wrapper baaki poore bot me reliably use ho raha hai, isliye user-side
        // notification bhi consistently aur fast deliver hota hai.
        try {
            Api.sendMessage({
                chat_id: targetUserId,
                text: notificationText,
                parse_mode: "HTML"
            });
        } catch (notifyErr) {}

    } catch (err) {
        Bot.sendMessage("⚠️ *Error:* " + err.message, {parse_mode: "Markdown"});
    }

} else {
    Bot.sendMessage("❌ You are not authorized to use this command.");
}
