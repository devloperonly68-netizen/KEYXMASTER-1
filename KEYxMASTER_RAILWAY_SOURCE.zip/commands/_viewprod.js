/**#command
name: /viewprod
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 📦 Shows a product's plans (Step 2 of the buy flow)
// ✅ CRITICAL BUG FIX: pehle "<tg-emoji emoji-id='X'></tg-emoji>" ek EMPTY
// tag tha (koi fallback character nahi) — Telegram ka HTML parser aise
// malformed tg-emoji tag par POORA MESSAGE hi reject kar deta hai. Isi
// wajah se product par click karne par plan-list screen kabhi aati hi nahi
// thi — poora buy flow yahi pe tootta tha!
// ✅ Photo-message-edit bug bhi fix, aur missing else-branch (fresh send)
// bhi add kiya.
// =========================================================

try {
  var productList = Bot.getProperty("stored_products") || [];
  var callbackId = request ? request.id : null;
  var chatId = chat.chatid;
  var messageId = request && request.message ? request.message.message_id : (request ? request.message_id : null);
  var isPhotoMsg = !!(request && request.message && request.message.photo);

  var userId = user.telegramid;
  var isReseller = Bot.getProperty("is_reseller_" + userId) === true;

  var productIndex = params ? params.trim() : "";
  if (productIndex === "") {
    var cbData = request && request.callback_query ? request.callback_query.data : "";
    productIndex = cbData.replace("/viewprod ", "").replace("viewprod ", "");
  }

  var selectedProduct = productList[Number(productIndex)];

  if (!selectedProduct) {
    if (callbackId) {
      try { Api.answerCallbackQuery({ callback_query_id: String(callbackId), text: "⚠️ Product not found!", show_alert: true }); } catch (e) {}
    }
    return;
  }

  var planButtons = [];
  var plans = selectedProduct.plans || [];

  if (plans.length === 0) {
    plans = [
      { days: "1", normal_price: "79", reseller_price: "65" },
      { days: "7", normal_price: "350", reseller_price: "300" }
    ];
  }

  for (var j = 0; j < plans.length; j++) {
    var plan = plans[j];
    var planUnit = plan.unit || "day";

    var cleanProdName = selectedProduct.name.trim().toUpperCase();
    var cleanPlanDays = String(plan.days).replace(/[^0-9.]/g, "").trim();

    var priceKeySuffix = (planUnit === "day") ? cleanPlanDays : (cleanPlanDays + "_" + planUnit);
    var normalKey = "price_normal_" + cleanProdName + "_" + priceKeySuffix;
    var resellerKey = "price_reseller_" + cleanProdName + "_" + priceKeySuffix;

    var adminNormalPrice = Bot.getProperty(normalKey);
    var adminResellerPrice = Bot.getProperty(resellerKey);

    var currentNormal = (adminNormalPrice !== undefined && adminNormalPrice !== null) ? adminNormalPrice : plan.normal_price;
    var currentReseller = (adminResellerPrice !== undefined && adminResellerPrice !== null) ? adminResellerPrice : plan.reseller_price;

    var displayPrice = isReseller ? currentReseller : currentNormal;
    var unitLabelWord = (planUnit === "hour") ? (Number(cleanPlanDays) === 1 ? "Hour" : "Hours") :
                         (planUnit === "minute") ? (Number(cleanPlanDays) === 1 ? "Minute" : "Minutes") :
                         (Number(cleanPlanDays) === 1 ? "Day" : "Days");
    var dayLabel = plan.durationDisplay || (cleanPlanDays + " " + unitLabelWord);

    // 🎉 Discount badge preview (auto-discount only, coupon shown later on confirm screen)
    var discPreviewKey1 = "auto_discount_" + cleanProdName + "_" + cleanPlanDays + "_" + planUnit.toUpperCase();
    var discPreviewKey2 = "auto_discount_" + cleanProdName + "_ALL";
    var discPreview = Bot.getProperty(discPreviewKey1) || Bot.getProperty(discPreviewKey2) || Bot.getProperty("auto_discount_global") || 0;
    var badgeText = discPreview > 0 ? " 🎉-" + discPreview + "%" : "";

    planButtons.push([
      {
        text: dayLabel + " — ₹" + displayPrice + badgeText,
        callback_data: "/buyitem " + productIndex + " " + j,
        style: "primary",
        icon_custom_emoji_id: "6100657257605763582"
      }
    ]);
  }

  // ✅ NEW: Back button ab is product ki category wali list par le jaata hai
  // (Android Root / Android Non Root), generic /buy_hack (category-select) par nahi.
  var backCategory = selectedProduct.category ? String(selectedProduct.category).toLowerCase() : "both";
  var backCallback = (backCategory === "root") ? "/buy_hack_cat root" : (backCategory === "iphone") ? "/buy_hack_cat iphone" : "/buy_hack_cat nonroot";

  planButtons.push([
    {
      text: "Back to Shop",
      callback_data: backCallback,
      style: "danger",
      icon_custom_emoji_id: "5893163582194978381"
    }
  ]);

  // ✅ FIX: empty tg-emoji tag hata diya — ab sirf plain product emoji text hai
  var planText =
    "<blockquote><tg-emoji emoji-id='6102856637343600044'>👑</tg-emoji> <b>PRODUCT: " + selectedProduct.name.toUpperCase() + "</b></blockquote>\n\n" +
    "<tg-emoji emoji-id='6093677128295914531'>✏️</tg-emoji> <b>CHOOSE YOUR PLAN</b> <tg-emoji emoji-id='6093677128295914531'>✏️</tg-emoji>\n\n" +
    "<blockquote><tg-emoji emoji-id='6093854128193152827'>🎉</tg-emoji> Select your validity plan below to proceed with the secure order <tg-emoji emoji-id='6091571559233755994'>👉</tg-emoji></blockquote>";

  var replyMarkupStr = JSON.stringify({ inline_keyboard: planButtons });

  if (messageId) {
    if (isPhotoMsg) {
      try { Api.deleteMessage({ chat_id: chatId, message_id: messageId }); } catch (e) {}
      Api.sendMessage({ chat_id: chatId, text: planText, parse_mode: "HTML", reply_markup: replyMarkupStr });
    } else {
      Api.editMessageText({
        chat_id: chatId,
        message_id: Number(messageId),
        text: planText,
        parse_mode: "HTML",
        reply_markup: replyMarkupStr
      });
    }
  } else {
    // ✅ FIX: pehle is case me kuch bhejta hi nahi tha
    Api.sendMessage({ chat_id: chatId, text: planText, parse_mode: "HTML", reply_markup: replyMarkupStr });
  }

  if (callbackId) {
    try { Api.answerCallbackQuery({ callback_query_id: String(callbackId) }); } catch (e) {}
  }

} catch (err) {
  Bot.sendMessage("⚠️ View Product Error: " + err.message, { parse_mode: "HTML" });
}