/**#command
name: /set_update_link
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🔧 ADMIN — Configure the "Download Updates" redirect link
// Usage: /set_update_link https://t.me/YourUpdateChannel
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin0 = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  if (!params || params.trim() === "") {
    var currentLink = Bot.getProperty("update_channel_link") || "Not set";
    Bot.sendMessage(
      "⚠️ <b>Format:</b> <code>/set_update_link https://t.me/YourChannel</code>\n\n" +
      "<b>Current link:</b> " + currentLink,
      { parse_mode: "HTML" }
    );
    return;
  }

  var link = params.trim();
  if (link.indexOf("http") !== 0) {
    Bot.sendMessage("❌ Link http:// ya https:// se shuru honi chahiye!");
    return;
  }

  Bot.setProperty("update_channel_link", link, "string");
  Bot.sendMessage("✅ <b>Update channel link set ho gaya:</b>\n" + link, { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}