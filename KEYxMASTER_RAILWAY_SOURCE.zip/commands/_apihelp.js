/**#command
name: /apihelp
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var ownerId=String(Bot.getProperty("owner_id")||"7088682169"), uid=String(chat.chatid), co=Bot.getProperty("co_admin_"+uid);
  if(uid!==ownerId && !co) return;
  Bot.sendMessage(
    "<b>🔌 MULTI API SYSTEM</b>\n\n"+
    "<code>/apiadd ID | NAME | URL | API_KEY | MASTER_KEY | MODE | ANDROID_REQUIRED</code>\n"+
    "<code>/apiupdate ID | FIELD | VALUE</code>\n"+
    "<code>/apilist</code>\n"+
    "<code>/apiset API_ID</code>\n"+
    "<code>/apidelete API_ID</code>\n\n"+
    "<b>Supported fields:</b> name, url, api_key, master_key, mode, android_required, enabled\n\n"+
    "Purchase flow automatically reads the active API configuration. Android ID is taken from the saved user value when the selected API requires it.",
    {parse_mode:"HTML"}
  );
} catch(e){Bot.sendMessage("⚠️ API Help Error: "+e.message);}
