/**#command
name: /set_refer_earn_btn
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🎁 ADMIN PANEL BUTTON — "Set Refer & Earn Amount"
// Pressing this button prompts the admin to send both bonus amounts as
// "topup|buy" text; _start.js (MODULE 5) auto-captures that reply and
// forwards it to /set_refer_earn internally.
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var currentChatId = String(chat.chatid);
  var isCoAdmin = Bot.getProperty("co_admin_" + currentChatId);

  if (currentChatId !== adminId && !isCoAdmin) {
    Bot.sendMessage("❌ You are not authorized to use this.");
    return;
  }

  var topupAmt = Bot.getProperty("refer_earn_topup_amount");
  if (topupAmt === undefined || topupAmt === null) topupAmt = "2 (default)";
  var buyAmt = Bot.getProperty("refer_earn_buy_amount");
  if (buyAmt === undefined || buyAmt === null) buyAmt = "2 (default)";

  User.setProperty("set_refer_earn_step", "waiting_input", "string");

  var promptText =
    "<blockquote><b>Set Refer & Earn Amounts</b></blockquote>\n\n" +
    "<i>Is format me reply karein:</i>\n<code>topup_bonus|buy_bonus</code>\n\n" +
    "<i>Example:</i> <code>2|2</code>\n\n" +
    "• <b>topup_bonus:</b> referrer ko milta hai jab uska referred friend pehli baar balance add kare\n" +
    "• <b>buy_bonus:</b> referrer ko milta hai jab uska referred friend pehli baar purchase kare\n\n" +
    "<b>Current:</b> Topup ₹<code>" + topupAmt + "</code> | Buy ₹<code>" + buyAmt + "</code>";

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;

  if (request && request.message && request.message.message_id) {
    try {
      Api.editMessageText({
        chat_id: String(chat.chatid),
        message_id: Number(request.message.message_id),
        text: promptText,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "Cancel", callback_data: "/admin", style: "danger" }]] })
      });
    } catch (e) {
      Api.sendMessage({ chat_id: chat.chatid, text: promptText, parse_mode: "HTML" });
    }
  } else {
    Bot.sendMessage(promptText, { parse_mode: "HTML" });
  }

  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
