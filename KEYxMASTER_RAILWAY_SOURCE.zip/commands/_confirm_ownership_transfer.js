/**#command
name: /confirm_ownership_transfer
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var ownerId = Bot.getProperty("owner_id") || "7088682169";
  var currentChatId = String(chat.chatid);

  if (currentChatId !== ownerId) {
    Bot.sendMessage("❌ Restricted!");
    return;
  }

  var newOwnerId = User.getProperty("pending_ownership_transfer_to");
  if (!newOwnerId) {
    Bot.sendMessage("❌ Koi pending transfer nahi mila. /transfer_ownership USERID phir se try karein.");
    return;
  }

  Bot.setProperty("owner_id", newOwnerId, "string");
  User.setProperty("pending_ownership_transfer_to", null, "string");

  Api.sendMessage({
    chat_id: chat.chatid,
    text: "<blockquote>✅ <b>OWNERSHIP TRANSFERRED!</b></blockquote>\n\nNaya Owner: <code>" + newOwnerId + "</code>",
    parse_mode: "HTML"
  });

  try {
    Api.sendMessage({
      chat_id: newOwnerId,
      text: "<blockquote>👑 <b>YOU ARE NOW THE OWNER OF THIS STORE!</b></blockquote>\n\n<i>Full admin panel access ke liye /admin command use karein.</i>",
      parse_mode: "HTML"
    });
  } catch (e) {}

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}