/**#command
name: /check_users
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 👥 COMMAND: /check_users
// STATUS: 100% OPERATIONAL & ANTI-CRASH CHUNK SYSTEM
// =========================================================

try {
  var adminId = "7088682169"; // Aapki Admin ID

  // Strict Admin Validation
  if (String(chat.chatid) !== adminId) {
    Bot.sendMessage("❌ Access Denied: Sirf Owner hi user database dekh sakta hai.");
    return;
  }

  // Fetch users array safely
  var userList = Bot.getProperty("all_users_list") || [];
  if (!Array.isArray(userList)) { userList = []; }

  if (userList.length === 0) {
    Bot.sendMessage("⚠️ <b>Database Empty:</b> Bot mein abhi tak koi bhi user register nahi hua hai.", { parse_mode: "HTML" });
    return;
  }

  var header = "<blockquote><b>👥 TOTAL REGISTERED USERS LIST</b>\n\n" +
               "📊 <b>Total Growth Node:</b> <code>" + userList.length + " Active Users</code></blockquote>\n" +
               "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";

  var bodyText = "";
  
  // Loop through all users and format
  for (var i = 0; i < userList.length; i++) {
    var userLine = "<b>[" + (i + 1) + "]</b> ID: <code>" + userList[i] + "</code>\n";
    
    // Memory and boundary protection: Split messages if character count exceeds 3500
    if ((header + bodyText + userLine).length > 3500) {
      Bot.sendMessage(header + bodyText, { parse_mode: "HTML" });
      header = ""; // Clear header for subsequent chunks
      bodyText = ""; // Reset temporary storage buffer
    }
    bodyText += userLine;
  }

  // Print final remaining chunk safely
  if (bodyText.trim() !== "") {
    Bot.sendMessage(header + bodyText + "\n━━━━━━━━━━━━━━━━━━━━━━━━━━", { parse_mode: "HTML" });
  }

} catch (err) {
  Bot.sendMessage("🛑 <b>User Audit Error:</b> <code>" + err.message + "</code>", { parse_mode: "HTML" });
}