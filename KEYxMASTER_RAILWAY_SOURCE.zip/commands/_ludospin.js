/**#command
name: /ludospin
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var userId = user.telegramid;
  var chatId = chat.chatid;
  
  // 🕒 24-HOUR COOLDOWN SYSTEM CORE
  var lastSpinTime = User.getProperty("last_ludo_spin_time"); 
  var currentTime = new Date().getTime(); 
  var cooldownMs = 24 * 60 * 60 * 1000; 

  if (lastSpinTime) {
    var timePassed = currentTime - Number(lastSpinTime);
    
    if (timePassed < cooldownMs) {
      // Kitna time bacha hai calculate karein
      var timeLeftMs = cooldownMs - timePassed;
      var totalSeconds = Math.floor(timeLeftMs / 1000);
      var hours = Math.floor(totalSeconds / 3600);
      var minutes = Math.floor((totalSeconds % 3600) / 60);
      var seconds = totalSeconds % 60;

      // 🛑 COOLDOWN ALERT WITH YOUR NEW PREMIUM EMOJIS
      var cooldownText = "<blockquote>" +
                         "<tg-emoji emoji-id='5893163582194978381'>❌</tg-emoji> <b>ACCESS DENIED!</b>\n" +
                         "━━━━━━━━━━━━━━━━━━━━━\n\n" +
                         "👋 Hello <b>" + user.first_name + "</b>, aap aaj ka spin pehle hi use kar chuke hain!\n\n" +
                         "<tg-emoji emoji-id='5260450573768990626'>➡️</tg-emoji> <b>Next Spin Available In:</b>\n" +
                         "<code>" + hours + " Hours, " + minutes + " Minutes, " + seconds + " Seconds</code>\n\n" +
                         "━━━━━━━━━━━━━━━━━━━━━\n" +
                         "<tg-emoji emoji-id='6194911182499881916'>🗣</tg-emoji> <i>Har user ko 24 ghante me sirf 1 spin milta hai.</i>" +
                         "</blockquote>";

      var cooldownButtons = [[
        { text: "Back to Menu", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
      ]];

      if (request && request.message && request.message.message_id) {
        Api.editMessageText({
          chat_id: String(chatId),
          message_id: Number(request.message.message_id),
          text: cooldownText,
          parse_mode: "HTML",
          reply_markup: JSON.stringify({ inline_keyboard: cooldownButtons })
        });
      } else {
        Api.sendMessage({
          chat_id: String(chatId),
          text: cooldownText,
          parse_mode: "HTML",
          reply_markup: JSON.stringify({ inline_keyboard: cooldownButtons })
        });
      }
      return; // Execution stops here
    }
  }

  // 🎲 RANDOM REWARD GENERATOR (0.1 se 0.6)
  var randomReward = (Math.random() * (0.6 - 0.1) + 0.1).toFixed(2);
  var rewardAmount = Number(randomReward);

  // 💰 ADD REWARD TO USER WALLET
  Libs.ResourcesLib.userRes("balance").add(rewardAmount);
  
  // 💾 SAVE CURRENT TIME TO PREVENT NEXT SPIN
  User.setProperty("last_ludo_spin_time", currentTime, "number");
  
  // New balance state check
  var updatedBal = Libs.ResourcesLib.userRes("balance").value().toFixed(2);

  // 💎 MULTI-PREMIUM INTERFACE LAYOUT (Success Screen)
  var spinText = "<blockquote>" +
                 "<tg-emoji emoji-id='6192822213486321961'>🎲</tg-emoji> <b>LUDO SPIN RESULTS</b>\n" +
                 "━━━━━━━━━━━━━━━━━━━━━\n\n" +
                 "<tg-emoji emoji-id='6298298582982199311'>🎰</tg-emoji> <i>The dice is rolling... and stopped!</i>\n\n" +
                 "<tg-emoji emoji-id='6194922667242429131'>🎉</tg-emoji> <b>Congratulations " + user.first_name + "!</b>\n" +
                 "<tg-emoji emoji-id='6064514463564831610'>💟</tg-emoji> <b>You Won:</b> <code>Ref. ₹" + rewardAmount.toFixed(2) + "</code>\n\n" +
                 "━━━━━ <tg-emoji emoji-id='5346024644635804737'>🔰</tg-emoji> <b>WALLET UPDATE</b> ━━━━━\n" +
                 "<tg-emoji emoji-id='6064138396228392033'>💵</tg-emoji> <b>New Wallet Balance:</b> ₹" + updatedBal + "\n\n" +
                 "<tg-emoji emoji-id='6194911182499881916'>🗣</tg-emoji> <i>Come back again to test your luck!</i>\n" +
                 "<tg-emoji emoji-id='6143299028655280273'>☠</tg-emoji> <tg-emoji emoji-id='6039605143601680423'>📞</tg-emoji> <b>Support Available 24/7</b>" +
                 "</blockquote>";

  var inlineButtons = [[
    { text: "Back to Menu", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
  ]];

  // Spin feedback send/edit handler
  if (request && request.message && request.message.message_id) {
    Api.editMessageText({
      chat_id: String(chatId),
      message_id: Number(request.message.message_id),
      text: spinText,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: inlineButtons })
    });
  } else {
    Api.sendMessage({
      chat_id: String(chatId),
      text: spinText,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: inlineButtons })
    });
  }

} catch (err) {
  Bot.sendMessage("⚠️ <b>Spin System Error:</b> <code>" + err.message + "</code>", { parse_mode: "HTML" });
}