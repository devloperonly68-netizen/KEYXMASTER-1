/**#command
name: /setresellerprice
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 💰 COMMAND = /setresellerprice
// STATUS: 100% ACCURATE KEY MATCHING FIX
// =========================================================

var input = message.replace("/setresellerprice", "").trim(); 
var parts = input.split("|");

if (parts.length === 3) {
  // 1️⃣ PRODUCT NAME: UpperCase + Trim (Jaise main buyitem script me hai)
  var pName = parts[0].trim().toUpperCase(); 
  
  // 2️⃣ PLAN DAYS: Sirf number nikalenge (Jaise "7_Day" ya "7 Days" se "7" bachega)
  var pPlan = String(parts[1]).replace(/[^0-9]/g, "").trim(); 
  
  // 3️⃣ PRICE: Force Floating/Integer Number parsing
  var pPrice = parseFloat(parts[2].trim());

  if (isNaN(pPrice)) {
    Bot.sendMessage("❌ Price ek number hona chahiye!");
    return;
  }

  // 🔥 MAIN MATCHING KEY FIX: direct buyitem loop database properties alignment
  var targetDatabaseKey = "price_reseller_" + pName + "_" + pPlan;

  // Real number me save karenge taaki exact math response aaye
  Bot.setProperty(targetDatabaseKey, pPrice, "number");
  
  Bot.sendMessage("✅ <b>Reseller Price Updated Successfully!</b>\n\n" +
                  "📦 <b>Product:</b> <code>" + pName + "</code>\n" +
                  "⏱️ <b>Plan:</b> <code>" + pPlan + " Days</code>\n" +
                  "💵 <b>New Price:</b> ₹" + pPrice, { parse_mode: "HTML" });

} else {
  Bot.sendMessage("⚠️ <b>Galat Format!</b>\n\n" +
                  "📝 <b>Format:</b>\n<code>/setresellerprice PRODUCT NAME | DAYS | PRICE</code>\n\n" +
                  "💡 <b>Example:</b>\n<code>/setresellerprice PRIME HOOK | 7 | 64</code>", { parse_mode: "HTML" });
}