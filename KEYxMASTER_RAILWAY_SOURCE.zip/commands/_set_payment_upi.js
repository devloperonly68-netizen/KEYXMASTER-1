/**#command
name: /set_payment_upi
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🔧 ADMIN — Configure the UPI ID used for all payment QR codes
// Usage: /set_payment_upi yourid@fam
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin0 = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  if (!params || params.trim() === "") {
    var currentUpi0 = Bot.getProperty("payment_upi_id") || "galureang@fam (default)";
    var currentKey0 = Bot.getProperty("payment_api_key");
    var currentKeyDisplay0 = currentKey0 ? (currentKey0.substring(0, 10) + "••••••••") : "FAM_b47c7d••••• (default)";
    Bot.sendMessage(
      "⚠️ <b>Format:</b> <code>/set_payment_upi yourid@fam|FAM_xxxx</code>\n" +
      "<i>(sirf UPI change karna ho to:</i> <code>/set_payment_upi yourid@fam</code><i>)</i>\n\n" +
      "<b>Current UPI ID:</b> <code>" + currentUpi0 + "</code>\n" +
      "<b>Current API Key:</b> <code>" + currentKeyDisplay0 + "</code>",
      { parse_mode: "HTML" }
    );
    return;
  }

  var rawInput = params.trim();
  var inputParts = rawInput.split("|");
  var newUpi = inputParts[0].trim();
  var newApiKey = (inputParts.length > 1) ? inputParts[1].trim() : null;

  if (newUpi.indexOf("@") === -1 || newUpi.indexOf(" ") !== -1) {
    Bot.sendMessage("❌ Invalid UPI ID! Format jaisa hona chahiye: <code>name@bank</code>", { parse_mode: "HTML" });
    return;
  }
  if (newApiKey !== null && (newApiKey === "" || newApiKey.indexOf(" ") !== -1)) {
    Bot.sendMessage("❌ Invalid API Key! Space allowed nahi hai.", { parse_mode: "HTML" });
    return;
  }

  Bot.setProperty("payment_upi_id", newUpi, "string");
  var confirmMsg = "✅ <b>Payment config update ho gaya:</b>\n• UPI ID: <code>" + newUpi + "</code>";

  if (newApiKey) {
    Bot.setProperty("payment_api_key", newApiKey, "string");
    confirmMsg += "\n• Fam Pay API Key: <code>" + newApiKey.substring(0, 10) + "••••••••</code>";
  }

  confirmMsg += "\n\n<i>Ab saare QR generate + payment verify isi UPI/API se honge, koi bhi purana flow break nahi hoga.</i>";
  Bot.sendMessage(confirmMsg, { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
