/**#command
name: /setproductapi
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var ownerId=String(Bot.getProperty("owner_id")||"7088682169"), uid=String(chat.chatid), co=Bot.getProperty("co_admin_"+uid);
  if(uid!==ownerId && !co) return;
  var p=(params?String(params).trim():"").split("|").map(function(x){return x.trim();});
  if(p.length<2){Bot.sendMessage("❌ Format: <code>/setproductapi PRODUCT_INDEX | API_ID</code>",{parse_mode:"HTML"});return;}
  var idx=Number(p[0]), apiId=p[1], products=Bot.getProperty("stored_products")||[], reg=Bot.getProperty("api_registry")||{};
  if(!products[idx]){Bot.sendMessage("❌ Product index not found.");return;}
  if(!reg[apiId]){Bot.sendMessage("❌ API ID not found. Use /apilist");return;}
  products[idx].api_id=apiId;
  Bot.setProperty("stored_products",products,"json");
  Bot.sendMessage("✅ <b>Product API Updated</b>\nProduct: <code>"+String(products[idx].name)+"</code>\nAPI: <code>"+apiId+"</code>",{parse_mode:"HTML"});
} catch(e){Bot.sendMessage("⚠️ Product API Error: "+e.message);}
