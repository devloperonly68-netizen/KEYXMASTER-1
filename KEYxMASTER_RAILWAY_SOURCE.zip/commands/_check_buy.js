/**#command
name: /check_buy
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var orderId = User.getProperty("buy_pending_order_id");
  var apiKey = Bot.getProperty("payment_api_key") || process.env.PAYMENT_API_KEY || "";

  if (!orderId) {
    Api.answerCallbackQuery({
      callback_query_id: String(request.id),
      text: "⚠️ No active order found!",
      show_alert: true
    });
    return;
  }

  Api.editMessageCaption({
    chat_id: chat.chatid,
    message_id: request.message.message_id,
    caption: "⏳ <tg-emoji emoji-id='6192822213486321961'>🔄</tg-emoji> <b>Payment verify ho raha hai, kripya wait karein...</b>",
    parse_mode: "HTML"
  });

  var verifyUrl = "https://fampay.anujbots.xyz/verify.php?order_id=" + encodeURIComponent(orderId) + "&api_key=" + encodeURIComponent(apiKey);

  HTTP.get({
    url: verifyUrl,
    success: "/onBuyCheck",
    error: "/onBuyCheck"
  });

} catch (err) {
  Bot.sendMessage("⚠️ <b>Error:</b> " + err.message, { parse_mode: "HTML" });
}