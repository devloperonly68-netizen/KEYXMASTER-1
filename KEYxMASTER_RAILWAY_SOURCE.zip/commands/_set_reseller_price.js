/**#command
name: /set_reseller_price
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 👑 ADMIN/CO-ADMIN — Set Reseller Upgrade Price
// Usage: /set_reseller_price 500
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "7088682169";
  var currentChatId = String(chat.chatid);
  var isCoAdmin = Bot.getProperty("co_admin_" + currentChatId);

  if (currentChatId !== ownerId && !isCoAdmin) {
    Bot.sendMessage("❌ Restricted command!");
    return;
  }

  if (!params || params.trim() === "") {
    var current = Bot.getProperty("reseller_upgrade_price") || "Not set";
    Bot.sendMessage("⚠️ <b>Format:</b> <code>/set_reseller_price 500</code>\n\n<b>Current price:</b> ₹" + current, { parse_mode: "HTML" });
    return;
  }

  var price = parseFloat(params.trim());
  if (isNaN(price) || price <= 0) {
    Bot.sendMessage("❌ Valid price chahiye (number)!");
    return;
  }

  Bot.setProperty("reseller_upgrade_price", price, "number");
  Bot.sendMessage("✅ <b>Reseller Upgrade Price set:</b> ₹" + price.toFixed(2), { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}