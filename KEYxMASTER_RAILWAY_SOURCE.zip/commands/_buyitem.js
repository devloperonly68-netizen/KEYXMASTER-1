/**#command
name: /buyitem
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🚀 PLAN CLICK HANDLER — Premium "Payment Method" confirmation screen
// (Pay from Wallet / Pay via UPI / Apply Coupon / Back to Shop)
// ✅ Supports Hour / Minute / Day duration units
// ✅ Supports coupon discounts (global or product-specific)
// =========================================================

try {
  var productList = Bot.getProperty("stored_products") || [];
  var callbackId = (request && request.id) ? request.id : ((request && request.callback_query && request.callback_query.id) || null);
  var chatId = chat.chatid;
  var userId = user.telegramid;

  var parts = params ? params.split(" ") : [];
  if (parts.length < 2) {
    var cbData = (request && request.callback_query) ? request.callback_query.data : "";
    parts = cbData.replace("buyitem ", "").split(" ");
  }

  var prodIdx = Number(parts[0]);
  var planIdx = Number(parts[1]);

  var product = productList[prodIdx];
  if (!product || !product.plans || !product.plans[planIdx]) {
    Bot.sendMessage("❌ Product or Plan configuration missing!");
    return;
  }

  var plan = product.plans[planIdx];
  var planUnit = plan.unit || "day";
  var cleanPlanDays = String(plan.days).replace(/[^0-9.]/g, "").trim();
  var unitLabelWord = (planUnit === "hour") ? (Number(cleanPlanDays) === 1 ? "Hour" : "Hours") :
                       (planUnit === "minute") ? (Number(cleanPlanDays) === 1 ? "Minute" : "Minutes") :
                       (Number(cleanPlanDays) === 1 ? "Day" : "Days");
  var durationDisplay = plan.durationDisplay || (cleanPlanDays + " " + unitLabelWord);

  var unifiedBal = (function () {
    var resBal = 0;
    try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
    var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
    return resBal + bonusBal;
  })();

  var isReseller = Bot.getProperty("is_reseller_" + userId) === true;
  var cleanProdName = product.name.trim().toUpperCase();

  // ✅ Unit-aware price key (Day plans keep the old key format for backward-compat)
  var priceKeySuffix = (planUnit === "day") ? cleanPlanDays : (cleanPlanDays + "_" + planUnit);
  var normalKey = "price_normal_" + cleanProdName + "_" + priceKeySuffix;
  var resellerKey = "price_reseller_" + cleanProdName + "_" + priceKeySuffix;

  var adminNormalPrice = Bot.getProperty(normalKey);
  var adminResellerPrice = Bot.getProperty(resellerKey);

  var currentNormal = (adminNormalPrice !== undefined && adminNormalPrice !== null) ? adminNormalPrice : plan.normal_price;
  var currentReseller = (adminResellerPrice !== undefined && adminResellerPrice !== null) ? adminResellerPrice : plan.reseller_price;

  var originalPrice = isReseller ? Number(currentReseller) : Number(currentNormal);
  var price = originalPrice;

  // 💸 Auto-discount (admin-set, no coupon code needed) — plan-specific > product-wide > global
  var planSpecificDiscKey = "auto_discount_" + cleanProdName + "_" + cleanPlanDays + "_" + planUnit.toUpperCase();
  var productWideDiscKey = "auto_discount_" + cleanProdName + "_ALL";
  var autoDiscountPercent = Bot.getProperty(planSpecificDiscKey) || Bot.getProperty(productWideDiscKey) || Bot.getProperty("auto_discount_global") || 0;

  // 🎟 Coupon check (if user applied one for this exact prod/plan) — coupon overrides auto-discount
  var appliedCouponCode = User.getProperty("applied_coupon_" + prodIdx + "_" + planIdx);
  var couponDiscountPercent = 0;
  if (appliedCouponCode) {
    var couponRec = Bot.getProperty("coupon_" + appliedCouponCode);
    if (couponRec && couponRec.discountPercent) {
      couponDiscountPercent = couponRec.discountPercent;
      price = Number((originalPrice * (1 - couponDiscountPercent / 100)).toFixed(2));
    }
  } else if (autoDiscountPercent > 0) {
    couponDiscountPercent = autoDiscountPercent; // reuse the same display variable
    price = Number((originalPrice * (1 - autoDiscountPercent / 100)).toFixed(2));
  }

  // 💎 PREMIUM EMOJI SET (verified valid custom-emoji IDs from your reference bot)
  var e_diamond = "<tg-emoji emoji-id='6266967801580231067'>💎</tg-emoji>";
  var e_pack   = "<tg-emoji emoji-id='6147767796097884213'>📦</tg-emoji>";
  var e_hour   = "<tg-emoji emoji-id='6147936236125298267'>⏳</tg-emoji>";
  var e_tag    = "<tg-emoji emoji-id='6080214566191505147'>🏷</tg-emoji>";
  var e_wallet = "<tg-emoji emoji-id='5348392971207194994'>💳</tg-emoji>";
  var e_check  = "<tg-emoji emoji-id='6100657257605763582'>✔️</tg-emoji>";
  var e_offer  = "<tg-emoji emoji-id='6102856637343600044'>🎉</tg-emoji>";
  var e_lock   = "<tg-emoji emoji-id='6215386799133433653'>🔒</tg-emoji>";
  var e_coupon = "<tg-emoji emoji-id='6093677128295914531'>🎫</tg-emoji>";
  var e_back   = "<tg-emoji emoji-id='5893163582194978381'>⬅️</tg-emoji>";

  var priceLine = couponDiscountPercent > 0
    ? e_tag + " <b>Price:</b> <s>₹" + originalPrice.toFixed(2) + "</s> ➜ <b>₹" + price.toFixed(2) + "</b>  " + e_offer + " <b>-" + couponDiscountPercent + "%</b>"
    : e_tag + " <b>Price:</b> ₹<code>" + price.toFixed(2) + "</code>";

  // =====================================================
  // 💎 PREMIUM CHECKOUT SCREEN — always shown on plan click
  // =====================================================
  var confirmText =
    "<blockquote>" + e_diamond + " <b>CONFIRM YOUR ORDER</b> " + e_diamond + "</blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    e_pack + " <b>Product:</b> " + product.name + "\n" +
    e_hour + " <b>Duration:</b> " + durationDisplay + "\n" +
    priceLine + "\n" +
    e_wallet + " <b>Wallet Balance:</b> ₹<code>" + unifiedBal.toFixed(2) + "</code>\n\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n" +
    e_lock + " <i>Secure checkout — choose a payment method below</i> " + e_check;

  var confirmButtons = [];

  if (unifiedBal >= price) {
    confirmButtons.push([
      { text: "Pay ₹" + price.toFixed(2) + " from Wallet", callback_data: "/confirm_buyitem " + prodIdx + " " + planIdx, style: "success", icon_custom_emoji_id: "6100657257605763582" }
    ]);
  } else {
    var needToPayPreview = (price - unifiedBal).toFixed(2);
    confirmButtons.push([
      { text: "Pay ₹" + needToPayPreview + " via UPI", callback_data: "/pay_upi " + prodIdx + " " + planIdx, style: "success", icon_custom_emoji_id: "5348392971207194994" }
    ]);
  }

  confirmButtons.push([
    { text: "Apply Coupon Code", callback_data: "/apply_coupon " + prodIdx + " " + planIdx, style: "primary", icon_custom_emoji_id: "6093677128295914531" }
  ]);
  confirmButtons.push([
    { text: "Back to Shop", callback_data: "/buy_hack", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
  ]);

  if (request && request.message) {
    Api.editMessageText({
      chat_id: String(chatId),
      message_id: Number(request.message.message_id),
      text: confirmText,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: confirmButtons })
    });
  } else {
    Api.sendMessage({
      chat_id: String(chatId),
      text: confirmText,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: confirmButtons })
    });
  }

  if (callbackId) {
    Api.answerCallbackQuery({ callback_query_id: String(callbackId) });
  }

} catch (e) {
  var errChatId = (typeof chat !== "undefined" && chat && chat.chatid) ? chat.chatid : null;
  if (errChatId) {
    try { Api.sendMessage({ chat_id: errChatId, text: "❌ <b>Error:</b> <code>" + e.message + "</code>", parse_mode: "HTML" }); } catch (fatal) {}
  }
}