/**#command
name: /addproduct
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

var adminId = Bot.getProperty("owner_id") || "7088682169";
var isCoAdmin0 = Bot.getProperty("co_admin_" + String(chat.chatid));

if (chat.chatid == adminId || isCoAdmin0) {
  // Format: /addproduct Name | EmojiID | PID | Category(root/nonroot/both)
  if (!params || params.trim() === "") {
    Bot.sendMessage(
      "⚠️ <b>Galat Format!</b>\n\n" +
      "Kripya is tarah bhejien:\n" +
      "<code>/addproduct Name | EmojiID | PID | Category</code>\n\n" +
      "<b>Category</b> me likhein: <code>root</code>, <code>nonroot</code>, <code>iphone</code> ya <code>both</code>\n\n" +
      "<b>Example:</b>\n<code>/addproduct Drip Client | 61160843705 | 91 | root</code>\n" +
      "<code>/addproduct Drip Client | 61160843705 | 92 | nonroot</code>\n" +
      "<code>/addproduct Panther Spoofer | 61160843705 | 93 | iphone</code>",
      { parse_mode: "HTML" }
    );
    return;
  }

  var parts = params.split("|");
  if (parts.length < 3) {
    Bot.sendMessage("⚠️ Sabhi details (Name, Emoji ID, PID) '|' lagakar bhejein!", { parse_mode: "HTML" });
    return;
  }

  var prodName = parts[0].trim();
  var prodEmoji = parts[1].trim();
  var prodId = parts[2].trim();

  // ✅ NEW: 4th field = category (root / nonroot / iphone / both). Agar admin nahi bhejta
  // toh default "both" — taaki purana /addproduct format (3 fields) bhi chalta rahe.
  var rawCategory = parts.length >= 4 ? parts[3].trim().toLowerCase() : "both";
  var prodCategory = "both";
  if (rawCategory === "root" || rawCategory === "android root" || rawCategory === "androidroot") {
    prodCategory = "root";
  } else if (rawCategory === "nonroot" || rawCategory === "non root" || rawCategory === "android non root" || rawCategory === "androidnonroot") {
    prodCategory = "nonroot";
  } else if (rawCategory === "iphone" || rawCategory === "ios" || rawCategory === "i phone" || rawCategory === "apple") {
    prodCategory = "iphone";
  } else {
    prodCategory = "both";
  }

  // Safe database fetch
  var productList = Bot.getProperty("stored_products");
  if (!Array.isArray(productList)) {
    productList = [];
  }

  // ✅ BUG FIX: pehle har /addproduct call ek NAYA duplicate entry bana deta tha,
  // chahe wahi product naam se pehle se maujood ho — isse shop me same product
  // do baar dikhta tha aur plans purani wali entry se hi attached rehte the.
  // Ab existing product (case-insensitive match) ho to usi ko UPDATE karta hai,
  // uske plans (agar honge) safe rehte hain.
  var existingIdx = -1;
  for (var pi = 0; pi < productList.length; pi++) {
    if (productList[pi].name && productList[pi].name.trim().toLowerCase() === prodName.toLowerCase()) {
      existingIdx = pi;
      break;
    }
  }

  var isUpdate = existingIdx > -1;

  if (isUpdate) {
    productList[existingIdx].name = prodName;
    productList[existingIdx].emoji = prodEmoji;
    productList[existingIdx].id = prodId;
    productList[existingIdx].category = prodCategory;
    if (!Array.isArray(productList[existingIdx].plans)) { productList[existingIdx].plans = []; }
  } else {
    productList.push({
      name: prodName,
      emoji: prodEmoji,
      id: prodId,
      category: prodCategory,
      plans: []
    });
  }

  // Save karo
  Bot.setProperty("stored_products", productList, "json");

  Bot.sendMessage(
    "<blockquote>✅ <b>Product " + (isUpdate ? "Updated" : "Successfully Added") + "!</b></blockquote>\n\n" +
    "📦 <b>Name:</b> " + prodName + "\n" +
    "💎 <b>Emoji:</b> <code>" + prodEmoji + "</code>\n" +
    "🔑 <b>PID:</b> <code>" + prodId + "</code>\n" +
    "📂 <b>Category:</b> <code>" + (prodCategory === "root" ? "ANDROID ROOT" : prodCategory === "nonroot" ? "ANDROID NON ROOT" : prodCategory === "iphone" ? "iPHONE" : "BOTH") + "</code>\n\n" +
    "<i>" + (isUpdate ? "Existing plans safe rakhe gaye hain." : "Ab yeh product store me sabhi ko dikhega! Use /addplan to add pricing plans.") + "</i>",
    { parse_mode: "HTML" }
  );

} else {
  Bot.sendMessage("❌ You are not the admin!");
}