/**#command
name: /removeplan
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  // Apni Admin Telegram ID yahan dalein
  var adminId = "7088682169";

  if (String(chat.chatid) !== adminId) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  // Format validation verification
  if (!params) {
    Bot.sendMessage("⚠️ Format: `/removeplan PRODUCT NAME | DAYS`\n\n*Example:* `/removeplan FreeFire Hack | 1`", { parse_mode: "Markdown" });
    return;
  }

  var data = params.split("|");
  if (data.length < 2) {
    Bot.sendMessage("⚠️ Galat Format! Product Name aur Days '|' se alag honi chahiye.");
    return;
  }

  var pName = data[0].trim().toLowerCase();
  var pDays = data[1].trim();

  // Database se existing products list nikalna
  var productList = Bot.getProperty("stored_products") || [];
  var productIndex = -1;

  // 1. Pehle product find karein
  for (var i = 0; i < productList.length; i++) {
    if (productList[i].name.toLowerCase() === pName) {
      productIndex = i;
      break;
    }
  }

  if (productIndex === -1) {
    Bot.sendMessage("❌ Product **" + data[0].trim() + "** database me nahi mila!", { parse_mode: "Markdown" });
    return;
  }

  var product = productList[productIndex];
  var plans = product.plans || [];
  var planIndex = -1;

  // 2. Us product ke andar targeted plan find karein
  for (var j = 0; j < plans.length; j++) {
    if (String(plans[j].days) === pDays) {
      planIndex = j;
      break;
    }
  }

  if (planIndex === -1) {
    Bot.sendMessage("❌ Product me **" + pDays + " Days** wala koi plan nahi mila!", { parse_mode: "Markdown" });
    return;
  }

  // 3. Plan ko array se remove (delete) karna
  plans.splice(planIndex, 1);

  var feedbackMsg = "";
  
  // 4. Verification Check: Agar saare plans delete ho chuke hain, toh product hi remove kar do
  if (plans.length === 0) {
    productList.splice(productIndex, 1);
    feedbackMsg = "🗑️ Product **" + product.name + "** ka aakhri plan thha, isliye poora product list se remove ho gaya!";
  } else {
    productList[productIndex].plans = plans;
    feedbackMsg = "✅ Product **" + product.name + "** se **" + pDays + " Days** wala plan successfully remove ho gaya!";
  }

  // 5. Updated list database me save karna
  Bot.setProperty("stored_products", productList, "json");
  Bot.sendMessage(feedbackMsg, { parse_mode: "Markdown" });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}