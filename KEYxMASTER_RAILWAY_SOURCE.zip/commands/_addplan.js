/**#command
name: /addplan
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Apni Admin Telegram ID yahan dalein
var adminId = Bot.getProperty("owner_id") || "7088682169";
var isCoAdmin0 = Bot.getProperty("co_admin_" + String(chat.chatid));

if (chat.chatid != adminId && !isCoAdmin0) {
  Bot.sendMessage("❌ You are not the admin!");
  return;
}

// ✅ FIXED: Ab sirf "Days" nahi — Hour / Minute bhi support karta hai!
// Format: /addplan PRODUCT NAME | DURATION | NORMAL PRICE | RESELLER PRICE
// DURATION examples: "7" ya "7d" ya "7days" = 7 Days | "1h" ya "1hour" = 1 Hour | "30m" ya "30min" = 30 Minutes
if (!params) {
  Bot.sendMessage(
    "⚠️ Format: `/addplan PRODUCT NAME | DURATION | NORMAL PRICE | RESELLER PRICE`\n\n" +
    "*Examples:*\n" +
    "`/addplan FreeFire Hack | 7d | 91 | 64`  (7 Days)\n`/addplan FreeFire Hack | 1 Hours | 91 | 64`  (Exact API duration: 1 Hours)\n" +
    "`/addplan FreeFire Hack | 1h | 10 | 8`  (1 Hour)\n" +
    "`/addplan FreeFire Hack | 30m | 5 | 4`  (30 Minutes)",
    { parse_mode: "Markdown" }
  );
  return;
}

var data = params.split("|");
if (data.length < 4) {
  Bot.sendMessage("⚠️ Galat Format! Charo cheezein '|' se alag honi chahiye.");
  return;
}

var pName = data[0].trim();
var rawDuration = data[1].trim();
var pNormal = parseFloat(data[2].trim());
var pReseller = parseFloat(data[3].trim());

if (isNaN(pNormal) || isNaN(pReseller)) {
  Bot.sendMessage("❌ Price numeric (number) honi chahiye!");
  return;
}

// 🕒 DURATION PARSER — exact API/website labels are preserved verbatim.
// Supports labels such as:
// 1 DaYS NONROOT, House, 1 DaYs, 15 DaYs All Colours Mix,
// 30 DaYs PRO, 1 DaYs Basic, 1 Year Ios Esign Gbox Certificate,
// 1 DaYs Root + Nonroot, 7 DaYS PC AIMKILL, 30 Day Pc Modmenu x86,
// 3 DaYs SAFE, 3 DaYs BRUTAL, etc.
var durationText = rawDuration.replace(/\s+/g, " ").trim();
var durMatch = durationText.toLowerCase().match(/^([0-9]+(?:\.[0-9]+)?)\s*(d|day|days|h|hr|hrs|hour|hours|m|min|mins|minute|minutes)(?:\s+(.+))?$/);
var numericOnly = durationText.match(/^([0-9]+(?:\.[0-9]+)?)/);
var pValue = durMatch ? durMatch[1] : (numericOnly ? numericOnly[1] : "0");
var unitRaw = durMatch ? durMatch[2] : "d";
var customSuffix = durMatch && durMatch[3] ? durMatch[3].trim() : "";
var pUnit = "day";
if (/^h/.test(unitRaw)) { pUnit = "hour"; }
else if (/^m/.test(unitRaw)) { pUnit = "minute"; }

// A non-numeric label (for example "House") is valid as an exact API duration name.
if (!durationText) {
  Bot.sendMessage("❌ Duration/API name empty hai!");
  return;
}

var pDays = String(pValue); // legacy field; exact API label is stored separately below.

// 🟢 Dynamic Global Price Keys — unit-aware (Day plans purane format me hi rehte hain,
// taaki pehle se set kiye hue Day-prices na tootein; Hour/Minute plans naye suffix format me)
var cleanProdName = pName.toUpperCase();
var priceKeySuffix = (pUnit === "day") ? pDays : (pDays + "_" + pUnit);
var normalKey = "price_normal_" + cleanProdName + "_" + priceKeySuffix;
var resellerKey = "price_reseller_" + cleanProdName + "_" + priceKeySuffix;

Bot.setProperty(normalKey, pNormal, "number");
Bot.setProperty(resellerKey, pReseller, "number");

// Database se existing products list nikalna
var productList = Bot.getProperty("stored_products") || [];

// Check karna ki kya yeh product pehle se list me hai?
var productIndex = -1;
for (var i = 0; i < productList.length; i++) {
  if (productList[i].name.toLowerCase() === pName.toLowerCase()) {
    productIndex = i;
    break;
  }
}

// 🕒 Human-readable duration label
var unitLabelWord = (pUnit === "hour") ? (Number(pDays) === 1 ? "Hour" : "Hours") :
                     (pUnit === "minute") ? (Number(pDays) === 1 ? "Minute" : "Minutes") :
                     (Number(pDays) === 1 ? "Day" : "Days");
var durationDisplay = durationText;

// 🪄 EXACT WEBSITE/API DURATION LABEL
// Never rewrite casing, pluralisation, suffixes, or custom names.
// This fixes labels such as "1 DaYs NONROOT" and "1 Year Ios Esign Gbox Certificate".
var autoWebsiteName = durationText;

// Setup complete plan object with dynamic fallback name + unit info
var newPlan = {
  days: pDays,                 // ab ye numeric "value" hai (backward-compat naam)
  unit: pUnit,                 // "day" | "hour" | "minute"  ✅ NEW
  durationDisplay: durationDisplay, // ✅ NEW — human readable, jaise "1 Hour", "30 Minutes", "7 Days"
  normal_price: pNormal,
  reseller_price: pReseller,
  name_on_website: autoWebsiteName,
  api_duration: autoWebsiteName
};

if (productIndex !== -1) {
  if (!productList[productIndex].plans) { productList[productIndex].plans = []; }
  
  var planUpdated = false;
  for (var p = 0; p < productList[productIndex].plans.length; p++) {
    var existingUnit = productList[productIndex].plans[p].unit || "day";
    if (String(productList[productIndex].plans[p].days) === pDays && existingUnit === pUnit) {
      productList[productIndex].plans[p] = newPlan;
      planUpdated = true;
      break;
    }
  }
  
  if (!planUpdated) {
    productList[productIndex].plans.push(newPlan);
  }
  Bot.sendMessage("✅ Product <b>" + pName + "</b> me <code>" + durationDisplay + "</code> ka plan ₹" + pNormal + " (Reseller: ₹" + pReseller + ") par set ho gaya!\nℹ️ <i>API Target Format: " + autoWebsiteName + "</i>", { parse_mode: "HTML" });
} else {
  var defaultEmoji = "5226656353744862682"; 
  productList.push({
    name: pName,
    emoji: defaultEmoji,
    plans: [newPlan]
  });
  Bot.sendMessage("✅ Naya Product <b>" + pName + "</b> successfully register ho gaya!\nℹ️ <i>API Target Format: " + autoWebsiteName + "</i>", { parse_mode: "HTML" });
}

// Database array update execution
Bot.setProperty("stored_products", productList, "json");