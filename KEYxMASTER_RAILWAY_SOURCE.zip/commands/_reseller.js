/**#command
name: /reseller
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
    if (request && request.id) {
        HTTP.post({
            url: "https://api.telegram.org/bot" + bot.token + "/answerCallbackQuery",
            body: { callback_query_id: request.id }
        });
    }

    // ⚡ DYNAMIC PRICE FETCH: Agar koi price set nahi hai toh default 450 dikhega
    let price = Bot.getProperty("reseller_price") || 70;

    let text = "━━━━━━━━━━━━━━━━━━━━\n" +
        "<tg-emoji emoji-id='6195245249351129913'>👑</tg-emoji> <b>UPGRADE TO RESELLER</b>\n" +
        "━━━━━━━━━━━━━━━━━━━━\n\n" +
        "<blockquote>" +
        "<tg-emoji emoji-id='6193006377389005214'>🎉</tg-emoji> <b>Benefits:</b>\n" +
        "• Special reseller prices on ALL products\n" +
        "• Priority support\n" +
        "• Balance tracking dashboard\n\n" +
        "<tg-emoji emoji-id='6195222374355311655'>✔</tg-emoji> <b>One-time Investment:</b> ₹" + price + "\n\n" +
        "<tg-emoji emoji-id='6194966974125055544'>⚠️</tg-emoji> <b>Terms:</b>\n" +
        "• Generate at least 1 license every 30 days\n" +
        "• Inactive for 30+ days → automatic downgrade\n" +
        "• You can re-upgrade anytime by paying again\n\n" +
        "Ready to upgrade? <tg-emoji emoji-id='6194922667242429131'>👈</tg-emoji>" +
        "</blockquote>";

    let keyboard = {
        inline_keyboard: [
            [
                {
                    text: "Upgrade Now",
                    callback_data: "/process_buy",
                    style: "success", 
                    icon_custom_emoji_id: "6195245249351129913"
                },
                {
                    text: "Back",
                    callback_data: "/back", 
                    style: "danger", 
                    icon_custom_emoji_id: "5893163582194978381"
                }
            ]
        ]
    };

    let endpoint = (request && request.message) ? "editMessageText" : "sendMessage";
    let requestBody = {
        chat_id: chat.chatid,
        text: text,
        parse_mode: "HTML",
        reply_markup: JSON.stringify(keyboard)
    };

    if (endpoint === "editMessageText") requestBody.message_id = request.message.message_id;

    HTTP.post({
        url: "https://api.telegram.org/bot" + bot.token + "/" + endpoint,
        body: requestBody
    });

} catch (err) {}