/**#command
name: /start
answer: 
keyboard: 
parse_mode: markdown
aliases: /START,/Start,/STArt,/stARt
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try { 
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var userId = String(user.telegramid);

  // ⭐ TELEGRAM STARS — fallback event detection (payment events may route here
  // generically depending on the platform, so we check and delegate explicitly)
  if (request && request.pre_checkout_query) {
    Bot.run({ command: "/onPreCheckoutQuery" });
    return;
  }
  if (request && request.message && request.message.successful_payment) {
    Bot.run({ command: "/onSuccessfulPayment" });
    return;
  }
  
  // Safe variable fallbacks for BJS environment
  var msgText = (typeof message !== 'undefined' && message) ? message.trim() : "";
  // ✅ FIXED: pehle "data" naam ka ek undefined global variable padha ja raha tha, jo hamesha
  // empty rehta tha — isliye koi bhi callback button jo "/start" call karta tha (jaise "Back to
  // Menu"), silently fail ho jaata tha aur user ko koi response hi nahi milta tha.
  var callbackData = (request && request.callback_query && request.callback_query.data) ? request.callback_query.data : "";

  // =====================================================
  // 🛠 MAINTENANCE MODE GATE (✅ NEW)
  // Owner/Co-Admins hamesha through jaate hain; baaki sabko premium screen dikhta hai.
  // =====================================================
  var isMaintenanceOn = Bot.getProperty("maintenance_mode") || false;
  var isOwnerOrCoAdmin = (userId === adminId) || Bot.getProperty("co_admin_" + userId);

  if (isMaintenanceOn && !isOwnerOrCoAdmin) {
    Bot.sendMessage(
      "<blockquote><tg-emoji emoji-id='6100657257605763582'>🛠</tg-emoji> <b>BOT UNDER MAINTENANCE</b></blockquote>\n\n" +
      "<i>Hum kuch premium improvements kar rahe hain! Kripya thodi der baad wapas try karein.</i>\n\n" +
      "<tg-emoji emoji-id='6100170496077204999'>👑</tg-emoji> <i>Dhanyawad for your patience!</i>",
      { parse_mode: "HTML" }
    );
    return;
  }

  // ✅ NEW: Maintenance abhi-abhi hata hai — is user ko ek baar premium "We're Back!" welcome do
  var maintenanceRemovedAt = Bot.getProperty("maintenance_removed_at");
  var userSeenMaintenanceRemoved = User.getProperty("seen_maintenance_removed_at");
  if (!isMaintenanceOn && maintenanceRemovedAt && userSeenMaintenanceRemoved !== maintenanceRemovedAt) {
    User.setProperty("seen_maintenance_removed_at", maintenanceRemovedAt, "number");
    Api.sendMessage({
      chat_id: chat.chatid,
      text: "<blockquote><tg-emoji emoji-id='6102856637343600044'>✅</tg-emoji> <b>MAINTENANCE REMOVED — WE'RE BACK!</b></blockquote>\n\n" +
            "<tg-emoji emoji-id='6091571559233755994'>🚀</tg-emoji> <i>Bot fully automated system ke saath phir se live hai!</i>\n" +
            "<i>Tap /start to continue, or Buy Now to grab your keys instantly.</i>",
      parse_mode: "HTML",
      reply_markup: JSON.stringify({
        inline_keyboard: [[
          { text: "Buy Now", callback_data: "/buy_hack", style: "success", icon_custom_emoji_id: "6312263493051489212" }
        ]]
      })
    });
  }
  
  var currentStep = User.getProperty("add_product_step");
  var isAwaitingBroadcast = User.getProperty("awaiting_broadcast_data");

  // 🎨 PREMIUM CUSTOM EMOJIS DEFINITION (Fixed with escaped double quotes)
  var EMJ_VERIFIED_CHECK = "<tg-emoji emoji-id=\"5875465628285931233\">✔️</tg-emoji>";
  var EMJ_CROWN          = "<tg-emoji emoji-id=\"6311975081702597046\">👑</tg-emoji>";
  var EMJ_DROP           = "<tg-emoji emoji-id=\"6080228009439141516\">💧</tg-emoji>";
  var EMJ_CHECK          = "<tg-emoji emoji-id=\"6080214566191505147\">✅</tg-emoji>";
  var EMJ_ROCKET         = "<tg-emoji emoji-id=\"6091571559233755994\">🚀</tg-emoji>";
  var EMJ_RADAR          = "<tg-emoji emoji-id=\"6093591495237967001\">📡</tg-emoji>";
  var EMJ_STAR           = "<tg-emoji emoji-id=\"6093677128295914531\">✨</tg-emoji>";
  var EMJ_RED_DOT        = "<tg-emoji emoji-id=\"6093854128193152827\">🔴</tg-emoji>";
  
  // Access Granted ke liye aapka requested special premium custom emoji
  var EMJ_NEW_ACCESS     = "<tg-emoji emoji-id=\"5875465628285931233\">✔️</tg-emoji>";

  // ==========================================
  // 🏠 HELPER: DIRECTLY SEND MAIN SHOP MENU
  // (Bot.runCommand("/menu") is unreliable in BJS -> inline it instead)
  // ==========================================
  function sendMainMenu() {
    try {
      // ✅ FIXED: ab same wallet store se read hoga jo purchase flows use karte hain
      // (Libs.ResourcesLib "balance" resource + admin bonus balance), taaki balance sab jagah same dikhe.
      var userBal = (function() {
        var resBal = 0;
        try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
        var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
        return (resBal + bonusBal).toFixed(2);
      })();

      var EMJ_HEADER_ROCKET = "<tg-emoji emoji-id='5217822164362739968'>🚀</tg-emoji>";
      var EMJ_HEADER_NEW    = "<tg-emoji emoji-id='6082603117763894396'>✨</tg-emoji>";
      var EMJ_HEADER_SHIELD = "<tg-emoji emoji-id='6113743082358841933'>🔰</tg-emoji>";

      var MSG_EMJ_STORE     = "<tg-emoji emoji-id='5866053971960929280'>🛒</tg-emoji>";
      var MSG_EMJ_FFID      = "<tg-emoji emoji-id='5334890573281114250'>🎮</tg-emoji>";
      var MSG_EMJ_PROFILE   = "<tg-emoji emoji-id='5260399854500191689'>🔰</tg-emoji>";
      var MSG_EMJ_ADDBAL    = "<tg-emoji emoji-id='6147815702163102310'>✨</tg-emoji>";
      var MSG_EMJ_HISTORY   = "<tg-emoji emoji-id='6113743082358841933'>🔰</tg-emoji>";
      var MSG_EMJ_LUDO      = "<tg-emoji emoji-id='5371043439020353782'>🎲</tg-emoji>";
      var MSG_EMJ_TUTORIAL  = "<tg-emoji emoji-id='5258077307985207053'>📹</tg-emoji>";
      var MSG_EMJ_PROOF     = "<tg-emoji emoji-id='5330237710655306682'>✅</tg-emoji>";
      var MSG_EMJ_SUPPORT   = "<tg-emoji emoji-id='5436113877181941026'>🔰</tg-emoji>";

      var EMJ_PREMIUM_MENU  = "<tg-emoji emoji-id='5406745015365943482'>✨</tg-emoji>";
      var EMJ_YOUR_BALANCE  = "<tg-emoji emoji-id='5231200819986047254'>💰</tg-emoji>";
      var EMJ_GET_STARTED   = "<tg-emoji emoji-id='6057415823222379852'>👇</tg-emoji>";

      var welcomeMessage =
        "<tg-emoji emoji-id=\"6266967801580231067\">💎</tg-emoji> <tg-emoji emoji-id=\"5866053971960929280\">🏪</tg-emoji> <b>— KEYxMASTER —</b> <tg-emoji emoji-id=\"5866053971960929280\">🏪</tg-emoji> <tg-emoji emoji-id=\"6266967801580231067\">💎</tg-emoji>\n\n" +
        "<tg-emoji emoji-id=\"6102856637343600044\">🎉</tg-emoji> <b>Hello, " + ((user && user.first_name) ? user.first_name.toUpperCase() : "RESELLER") + "!</b>\n\n" +
        "<tg-emoji emoji-id=\"6080228009439141516\">💧</tg-emoji> <b>Genuine, limited-stock books. Instant delivery.</b>\n\n" +
        "<tg-emoji emoji-id=\"6147767796097884213\">📦</tg-emoji> Wide product catalog\n" +
        "<tg-emoji emoji-id=\"6215386799133433653\">🔒</tg-emoji> Instant delivery on payment\n" +
        "<tg-emoji emoji-id=\"6267068789146260253\">💰</tg-emoji> Multiple payment gateways\n" +
        "<tg-emoji emoji-id=\"6100170496077204999\">👑</tg-emoji> 24/7 admin support\n\n" +
        "<i>" + EMJ_YOUR_BALANCE + " Balance: ₹" + userBal + "</i>\n\n" +
        "<i>Tap any button below to begin:</i> " + EMJ_GET_STARTED;

      var multiColorKeyboard = [
        [{ text: "Shop Now", callback_data: "/buy_hack", style: "primary", icon_custom_emoji_id: "5866053971960929280" }],
        [
          { text: "Profile", callback_data: "/profile", style: "primary", icon_custom_emoji_id: "6145572393499762737" },
          { text: "Add Balance", callback_data: "/addfund", style: "success", icon_custom_emoji_id: "5409048419211682843" }
        ],
        [
          { text: "My Keys", callback_data: "/mykey", style: "primary", icon_custom_emoji_id: "6215386799133433653" },
          { text: "How to use", callback_data: "/how", style: "danger", icon_custom_emoji_id: "6192842983948162969" }
        ],
        [
          { text: "Download Files", callback_data: "/download_updates", style: "primary", icon_custom_emoji_id: "5208790878931415568" },
          { text: "Daily Gift", callback_data: "/dailygift", style: "success", icon_custom_emoji_id: "6194922667242429131" }
        ],
        [
          { text: "Refer & Earn", callback_data: "/refer", style: "success", icon_custom_emoji_id: "5823654080584618403" },
          { text: "Support", callback_data: "/support", style: "danger", icon_custom_emoji_id: "6267129592998270736" }
        ],
        [{ text: "Payment Proofs", url: (Bot.getProperty("payment_proof_link") || "https://t.me/GaluModz_Proof"), style: "success", icon_custom_emoji_id: "5330237710655306682" }]
      ];

      if (Bot.getProperty("reseller_system_enabled") && !Bot.getProperty("is_reseller_" + userId)) {
        multiColorKeyboard.push([
          { text: "Reseller Upgrade", callback_data: "/reseller_upgrade", style: "success", icon_custom_emoji_id: "6102856637343600044" }
        ]);
      }

      Api.sendMessage({
        chat_id: chat.chatid,
        text: welcomeMessage,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: multiColorKeyboard })
      });
    } catch (menuErr) {
      Bot.sendMessage("🛑 <b>Menu Send Error:</b> <code>" + menuErr.message + "</code>", { parse_mode: "HTML" });
    }
  }

  // [Auto-Track User] List me user track karne ke liye
  var trackedUsers = Bot.getProperty("all_users_list") || [];
  if (!trackedUsers.includes(userId)) {
    trackedUsers.push(userId);
    Bot.setProperty("all_users_list", trackedUsers, "json");

    // ==========================================
    // 🎁 REFER & EARN — capture referral on this user's very first /start
    // Deep link format: https://t.me/<bot>?start=ref<referrerTelegramId>
    // ==========================================
    try {
      var refParam = (typeof params !== "undefined" && params) ? String(params).trim() : "";
      if (refParam.toLowerCase().indexOf("ref") === 0) {
        var referrerId = refParam.substring(3).replace(/[^0-9]/g, "");
        if (referrerId && referrerId !== userId && !User.getProperty("referred_by")) {
          User.setProperty("referred_by", referrerId, "string");

          var refList = Bot.getProperty("referrals_of_" + referrerId) || [];
          if (refList.indexOf(userId) === -1) {
            refList.push(userId);
            Bot.setProperty("referrals_of_" + referrerId, refList, "json");
          }

          try {
            Api.sendMessage({
              chat_id: referrerId,
              text: "<blockquote><tg-emoji emoji-id='6102856637343600044'>🎉</tg-emoji> <b>New Referral!</b>\n\n" +
                    "<tg-emoji emoji-id='5260399854500191689'>👤</tg-emoji> " + (user && user.first_name ? user.first_name : "A user") +
                    " ne aapke link se bot join kiya hai.\n<i>Jab wo balance add ya purchase karega, aapko bonus milega!</i></blockquote>",
              parse_mode: "HTML"
            });
          } catch (e) {}
        }
      }
    } catch (e) {}
  }

  // 🛡️ [ANTI-DUPLICATE CHECK] Agar user already verified hai toh seedhe menu par bhejein
  // ✅ FIXED: pehle sirf exact "msgText === '/start'" ya "callbackData === '/trigger_contact_popup'"
  // match hone par hi menu bhejta tha. Kisi bhi button jo callback_data "/start" call karta tha
  // (jaise cancel-order ke baad "Back to Menu"), us case me match fail ho jaata tha aur user ko
  // koi response nahi milta tha. Ab ye check robust hai — jab tak ye genuinely ek contact-share
  // event nahi hai ya admin ek mid-flow step me nahi hai, verified user ko hamesha menu milega.
  var couponGenStep = User.getProperty("coupon_gen_step");
  var awaitingCouponFor = User.getProperty("awaiting_coupon_for");
  var isAlreadyVerified = Bot.getProperty("verified_" + userId);
  var isContactShareEvent = !!(request && request.contact && request.contact.user_id);
  var isAdminMidFlow = (userId === adminId && (currentStep || isAwaitingBroadcast || couponGenStep ||
    User.getProperty("addbal_step") || User.getProperty("addbalall_step") || User.getProperty("rembal_step") || User.getProperty("checkbal_step") ||
    User.getProperty("set_download_link_step") || User.getProperty("set_payment_upi_step") ||
    User.getProperty("set_payment_binance_step") ||
    User.getProperty("set_dailygift_price_step") || User.getProperty("set_refer_earn_step") ||
    User.getProperty("set_how_link_step") || User.getProperty("set_proof_link_step") || User.getProperty("set_support_link_step")));
  var binanceUtrStep = User.getProperty("binance_utr_step");
  var isUserMidFlow = !!awaitingCouponFor || !!binanceUtrStep;

  // ✅ NEW: User ne jo bhi "/start"/"/START"/"/Start" type kiya, menu aane ke
  // baad us typed command-message ko vanish (delete) kar do — chat clean rahe.
  if (msgText.toLowerCase() === "/start" && request && request.message_id) {
    try { Api.deleteMessage({ chat_id: chat.chatid, message_id: request.message_id }); } catch (delStartErr) {}
  }

  if (isAlreadyVerified && !isContactShareEvent && !isAdminMidFlow && !isUserMidFlow) {
    sendMainMenu();
    return;
  }

  // ==========================================
  // ⚡ MODULE: LIVE CONTACT RECEIVER & VERIFIER
  // ==========================================
  if (request && request.contact && request.contact.user_id) {
    if (String(request.contact.user_id) === userId) {
      
      var phoneNumber = request.contact.phone_number;
      var fullName = ((user.first_name || "") + " " + (user.last_name || "")).trim() || "No Name";
      var username = user.username ? "@" + user.username : "No Username";

      // Permanently mark user as verified globally
      Bot.setProperty("verified_" + userId, true, "boolean");
      Bot.setProperty("phone_" + userId, phoneNumber, "string");
      // ✅ NEW: Joined date save karo (Profile section me dikhane ke liye)
      if (!Bot.getProperty("joined_date_" + userId)) {
        Bot.setProperty("joined_date_" + userId, new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }), "string");
      }
      
      // 1. USER DETAILS TO ADMIN
      var adminNotification = 
        "<blockquote><b>" + EMJ_CROWN + " NEW USER VERIFIED " + EMJ_VERIFIED_CHECK + "</b></blockquote>\n" +
        "<b>━━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n" +
        "<b>👤 Name:</b> " + fullName + "\n" +
        "<b>🆔 User ID:</b> <code>" + userId + "</code>\n" +
        "<b>🌐 Username:</b> " + username + "\n" +
        "<b>📞 Number:</b> <code>" + phoneNumber + "</code>\n" +
        "<b>━━━━━━━━━━━━━━━━━━━━━━━━━━</b>";

      Api.sendMessage({
        chat_id: adminId,
        text: adminNotification,
        parse_mode: "HTML"
      });

      // 2. USER SUCCESS MESSAGE (With your exact requested custom emojis)
      var successMessage = 
        "<blockquote><b>" + EMJ_NEW_ACCESS + " ACCESS GRANTED " + EMJ_NEW_ACCESS + "</b></blockquote>\n" +
        "<b>" + EMJ_VERIFIED_CHECK + " Verification Successful!</b>\n" +
        "<b>━━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n" +
        "<b>Welcome to KEYxMASTER PANEL </b>\n" +
        "<b>Your profile is now securely fully verified.</b>\n\n" +
        "<b>" + EMJ_ROCKET + " Store Loaded Successfully Use Now! " + EMJ_CROWN + "</b>";

      Api.sendMessage({
        chat_id: chat.chatid,
        text: successMessage,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ remove_keyboard: true }) 
      });

      // ✅ FIX: Direct inline menu instead of unreliable Bot.runCommand("/menu")
      sendMainMenu();
      return; 
    } else {
      Bot.sendMessage("❌ <b>Verification Failed!</b> Please share your own contact number only.", { parse_mode: "HTML" });
      return;
    }
  }

  // ==========================================
  // 📱 MODULE 0: VERIFICATION CALLBACK HANDLER
  // ==========================================
  if (msgText.toLowerCase() === "/start" || callbackData === "/trigger_contact_popup") {
    
    var verifyMessage = 
      "<blockquote><b>" + EMJ_ROCKET + " KEYxMASTER " + EMJ_RADAR + "</b></blockquote>\n" +
      "<b>" + EMJ_STAR + " Welcome, " + (user.first_name || "User") + " " + EMJ_DROP + "</b>\n" +
      "<b>━━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n" +
      "<b>" + EMJ_RED_DOT + " VERIFICATION REQUIRED " + EMJ_CHECK + "</b>\n" +
      "<b>━━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n" +
      "<b>" + EMJ_RADAR + " To start shopping, please verify your phone number.</b>\n\n" +
      "<b>" + EMJ_ROCKET + " Why we need this:</b>\n" +
      "<b>  • Secure your purchases " + EMJ_CHECK + "</b>\n" +
      "<b>  • Deliver your books to you " + EMJ_DROP + "</b>\n" +
      "<b>  • Protect your account " + EMJ_STAR + "</b>\n\n" +
      "<b>" + EMJ_RED_DOT + " Tap the blue button below to verify your account:</b>";

    // Standard native reply keyboard because contact sharing works securely here
    var nativeKeyboard = {
      keyboard: [
        [{ text: "✅ Verify Account", request_contact: true }]
      ],
      resize_keyboard: true,
      one_time_keyboard: true
    };

    Api.sendMessage({
      chat_id: chat.chatid,
      text: verifyMessage,
      parse_mode: "HTML",
      reply_markup: JSON.stringify(nativeKeyboard)
    });
    return; 
  }

  // ==========================================
  // 📦 MODULE 1: STEP-BY-STEP PRODUCT CREATION (UPDATED FOR WEBSITE API ID)
  // ==========================================
  if (userId === adminId && currentStep) {
    if (currentStep === "waiting_for_name") {
      if (!msgText) {
        Bot.sendMessage("⚠️ Invalid name. Please type a valid Product Name:");
        return;
      }
      User.setProperty("temp_product_name", msgText, "string");
      User.setProperty("add_product_step", "waiting_for_emoji", "string");
      Bot.sendMessage("💎 Great! Now send the <b>Premium Emoji ID</b> for this product:", { parse_mode: "HTML" });
      return; 
    }
    
    if (currentStep === "waiting_for_emoji") {
      if (!msgText) {
        Bot.sendMessage("⚠️ Invalid Emoji ID. Please send a valid Telegram Premium Emoji ID:");
        return;
      }
      User.setProperty("temp_product_emoji", msgText, "string");
      User.setProperty("add_product_step", "waiting_for_pid", "string");
      Bot.sendMessage("🔑 Nice! Now please enter the <b>Website API Product ID (PID)</b> for this item:", { parse_mode: "HTML" });
      return;
    }

    if (currentStep === "waiting_for_pid") {
      if (!msgText) {
        Bot.sendMessage("⚠️ Invalid Product ID. Please type a valid Website PID:");
        return;
      }

      var savedName = User.getProperty("temp_product_name");
      var savedEmoji = User.getProperty("temp_product_emoji");
      var savedPid = msgText; // User ne jo PID abhi bheja

      var productList = Bot.getProperty("stored_products") || [];
      if (!Array.isArray(productList)) { productList = []; }
      
      // Saving Name, Emoji and Website API ID (id) inside database object
      productList.push({ 
        name: savedName, 
        emoji: savedEmoji, 
        id: savedPid, 
        plans: [] 
      });

      Bot.setProperty("stored_products", productList, "json");
      
      // Cleanup temporary states
      User.setProperty("add_product_step", null, "string");
      User.setProperty("temp_product_name", null, "string");
      User.setProperty("temp_product_emoji", null, "string");
      
      var successMsg = "✅ <b>Product Added Successfully!</b>\n\n" +
                       "📦 <b>Name:</b> " + savedName + "\n" +
                       "💎 <b>Emoji ID:</b> <code>" + savedEmoji + "</code>\n" +
                       "🔑 <b>API Product ID (PID):</b> <code>" + savedPid + "</code>\n\n" +
                       "<i>Aap is product ke andar plans baad me configure kar sakte hain. Automatically website se integration ho gaya hai!</i>";
                       
      Bot.sendMessage(successMsg, { parse_mode: "HTML" });
      return; 
    }
  }

  // ==========================================
  // 🟡 MODULE 4b: ADMIN — BINANCE PAYMENT CONFIG WIZARD
  // Step 1: QR (photo OR image URL — whichever the admin sends, both work).
  // Step 2: Binance Pay ID. Step 3: USDT Address. Step 4: USD rate.
  // ==========================================
  if (userId === adminId) {
    var setPaymentBinanceStep = User.getProperty("set_payment_binance_step");

    // ✅ ROBUST photo detection — different update shapes have shown up in this
    // environment, so we check every place Telegram (or this platform) might
    // put the photo array before giving up.
    var incomingPhotoArr = null;
    try {
      if (request) {
        if (request.message && request.message.photo && request.message.photo.length) {
          incomingPhotoArr = request.message.photo;
        } else if (request.photo && request.photo.length) {
          incomingPhotoArr = request.photo;
        } else if (request.update && request.update.message && request.update.message.photo && request.update.message.photo.length) {
          incomingPhotoArr = request.update.message.photo;
        }
      }
    } catch (photoDetectErr) {}

    if (setPaymentBinanceStep === "waiting_qr") {
      var savedQr = false;

      if (incomingPhotoArr) {
        var largestPhoto = incomingPhotoArr[incomingPhotoArr.length - 1];
        var qrFileId = largestPhoto.file_id;
        Bot.setProperty("binance_qr_file_id", qrFileId, "string");
        Bot.setProperty("binance_qr_url", null, "string");
        savedQr = true;
      } else if (msgText && (msgText.trim().indexOf("http://") === 0 || msgText.trim().indexOf("https://") === 0)) {
        Bot.setProperty("binance_qr_url", msgText.trim(), "string");
        Bot.setProperty("binance_qr_file_id", null, "string");
        savedQr = true;
      }

      if (savedQr) {
        User.setProperty("set_payment_binance_step", "waiting_binance_id", "string");
        Bot.sendMessage(
          "✅ <b>QR Saved!</b>\n\n" +
          "<i>Step 2/4 —</i> Ab apna <b>Binance Pay ID</b> bhejein (jaise: <code>839548203</code>):",
          { parse_mode: "HTML" }
        );
        return;
      }

      // ❌ Neither a photo nor a URL was recognised — don't silently drop it.
      Bot.sendMessage(
        "⚠️ QR receive nahi hua. Kripya QR ko ya toh <b>photo/image</b> ke roop me bhejein, ya QR image ka <b>direct URL link</b> (https://...) paste karein.",
        { parse_mode: "HTML" }
      );
      return;
    }

    if (setPaymentBinanceStep === "waiting_binance_id" && msgText) {
      Bot.setProperty("binance_pay_id", msgText.trim(), "string");
      User.setProperty("set_payment_binance_step", "waiting_usdt_address", "string");
      Bot.sendMessage(
        "✅ <b>Binance Pay ID Saved!</b>\n\n" +
        "<i>Step 3/4 —</i> Ab apna <b>USDT Address</b> bhejein (jaise: <code>TNvySU5Wk2mBAJNpBLGwvLk9pk4EgkeLXt</code>):",
        { parse_mode: "HTML" }
      );
      return;
    }

    if (setPaymentBinanceStep === "waiting_usdt_address" && msgText) {
      Bot.setProperty("binance_usdt_address", msgText.trim(), "string");
      User.setProperty("set_payment_binance_step", "waiting_usd_rate", "string");
      var rateNow = Bot.getProperty("usd_rate") || 91;
      Bot.sendMessage(
        "✅ <b>USDT Address Saved!</b>\n\n" +
        "<i>Step 4/4 —</i> Ab USD conversion rate bhejein (₹ kitne ka $1, jaise <code>91</code>).\n" +
        "<i>Current:</i> <code>₹" + rateNow + " = $1</code>\n" +
        "<i>Same rakhna ho to bhi number type karke bhej dein.</i>",
        { parse_mode: "HTML" }
      );
      return;
    }

    if (setPaymentBinanceStep === "waiting_usd_rate" && msgText) {
      var finalRate = parseFloat(msgText.trim());
      if (isNaN(finalRate) || finalRate <= 0) {
        Bot.sendMessage("❌ Invalid rate! Ek valid positive number bhejein, jaise 91.", { parse_mode: "HTML" });
        return;
      }
      Bot.setProperty("usd_rate", finalRate, "string");
      User.setProperty("set_payment_binance_step", null, "string");

      var qrStatusMsg = Bot.getProperty("binance_qr_file_id") || Bot.getProperty("binance_qr_url") ? "✅ Set" : "❌ Not set";
      Bot.sendMessage(
        "<blockquote>🟡 <b>BINANCE PAY CONFIG COMPLETE!</b></blockquote>\n\n" +
        "🖼 <b>QR:</b> " + qrStatusMsg + "\n" +
        "🆔 <b>Binance Pay ID:</b> <code>" + Bot.getProperty("binance_pay_id") + "</code>\n" +
        "💳 <b>USDT Address:</b> <code>" + Bot.getProperty("binance_usdt_address") + "</code>\n" +
        "💱 <b>USD Rate:</b> <code>₹" + finalRate + " = $1</code>\n\n" +
        "<i>Binance Pay ab live hai!</i>",
        { parse_mode: "HTML" }
      );
      return;
    }
  }

  // ==========================================
  // 🟡 MODULE 4c: USER — BINANCE PROOF SUBMISSION (screenshot only)
  // ==========================================
  if (binanceUtrStep === "awaiting_screenshot") {
    var ssPhotoArr = null;
    try {
      if (request) {
        if (request.message && request.message.photo && request.message.photo.length) {
          ssPhotoArr = request.message.photo;
        } else if (request.photo && request.photo.length) {
          ssPhotoArr = request.photo;
        } else if (request.update && request.update.message && request.update.message.photo && request.update.message.photo.length) {
          ssPhotoArr = request.update.message.photo;
        }
      }
    } catch (ssPhotoDetectErr) {}

    if (!ssPhotoArr) {
      Bot.sendMessage("⚠️ Kripya payment screenshot ek <b>image/photo</b> ke roop me bhejein.", { parse_mode: "HTML" });
      return;
    }

    var ssLargest = ssPhotoArr[ssPhotoArr.length - 1];
    var ssFileId = ssLargest.file_id;

    var subInr = User.getProperty("binance_pending_amount_inr");
    var subUsd = User.getProperty("binance_pending_amount_usd");
    var adminSupportId = Bot.getProperty("owner_id") || "7088682169";

    var fullNameSub = ((user.first_name || "") + " " + (user.last_name || "")).trim() || "No Name";
    var usernameSub = user.username ? "@" + user.username : "No Username";

    var adminCaption =
      "<blockquote><tg-emoji emoji-id='6312263493051489212'>🟡</tg-emoji> <b>NEW BINANCE PAY SUBMISSION</b></blockquote>\n" +
      "👤 <b>User:</b> <a href='tg://user?id=" + userId + "'>" + fullNameSub + "</a> (<code>" + userId + "</code>)\n" +
      "🌐 <b>Username:</b> " + usernameSub + "\n" +
      "💰 <b>Amount:</b> $<code>" + subUsd + "</code> <i>(₹" + subInr + ")</i>\n\n" +
      "<i>Verify the screenshot, then credit balance with the button below or:</i>\n<code>/addbal " + userId + "|" + subInr + "</code>";

    try {
      Api.sendPhoto({
        chat_id: adminSupportId,
        photo: ssFileId,
        caption: adminCaption,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({
          inline_keyboard: [[
            { text: "✅ Approve & Credit ₹" + subInr, callback_data: "/addbal_binance_approve " + userId + " " + subInr, style: "success" }
          ]]
        })
      });
    } catch (notifyAdminErr) {}

    User.setProperty("binance_utr_step", null, "string");
    User.setProperty("binance_pending_amount_inr", null, "string");
    User.setProperty("binance_pending_amount_usd", null, "string");

    Bot.sendMessage(
      "<blockquote><tg-emoji emoji-id='6147936236125298267'>⏳</tg-emoji> <b>WAIT FOR ADMIN CHECK</b></blockquote>\n\n" +
      "<i>Aapka payment screenshot admin ko bhej diya gaya hai. Admin manually verify karke aapka balance add karega — thodi der wait karein!</i>",
      {
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "Back to Menu", callback_data: "/back", style: "primary" }]] })
      }
    );
    return;
  }

  // ==========================================
  // 💵 MODULE 5: ADMIN BALANCE TOOLS (Add Bal / Remove Bal / Check Bal
  // button-click continuation — fixes buttons that previously just
  // showed a "Wrong Format" error with no way to actually complete it)
  // ==========================================
  if (userId === adminId) {
    var addbalStep = User.getProperty("addbal_step");
    var addbalAllStep = User.getProperty("addbalall_step");
    var rembalStep = User.getProperty("rembal_step");
    var checkbalStep = User.getProperty("checkbal_step");

    if (addbalStep === "waiting_input" && msgText) {
      User.setProperty("addbal_step", null, "string");

      // ✅ FIXED: pehle sirf Bot.run(...) se /addbal ko dobara call kiya jaata tha —
      // agar us re-run me "message" text sahi se forward nahi hota tha (jo wildcard
      // "*" -> /start delegation ke through hone par silently fail ho sakta tha),
      // toh balance kabhi credit hi nahi hota tha aur admin ko koi error bhi nahi
      // dikhta tha. Ab balance yahin, isi jagah, seedha add hota hai — kisi doosre
      // command re-run par depend nahi karta. Bot.run wala call sirf backup ke
      // taur par neeche rakha hai.
      var addbalData = msgText.trim();

      if (addbalData.indexOf("|") === -1) {
        Bot.sendMessage("❌ *Invalid Format! Use:* `user_id|amount`", { parse_mode: "Markdown" });
        return;
      }

      var addbalParts = addbalData.split("|");
      var addbalTargetId = addbalParts[0].trim();
      var addbalAmount = parseFloat(addbalParts[1].trim());

      if (!addbalTargetId || isNaN(addbalAmount) || addbalAmount <= 0) {
        Bot.sendMessage("❌ *Invalid Format! Use:* `user_id|amount`", { parse_mode: "Markdown" });
        return;
      }

      try {
        // Primary wallet resource (same store the rest of the bot reads for purchases)
        try {
          Libs.ResourcesLib.anotherUserRes("balance", addbalTargetId).add(addbalAmount);
        } catch (resErr) {}

        // ✅ Bonus-balance property — this is the SAME property /menu reads and adds
        // on top of the resource balance. Writing it here too guarantees the credited
        // amount always shows up for the user even if the resource write above fails
        // silently for a user who never triggered it before.
        var prevBonus = Number(Bot.getProperty("balance" + addbalTargetId) || 0);
        Bot.setProperty("balance" + addbalTargetId, (prevBonus + addbalAmount).toFixed(2), "string");

        Bot.sendMessage("✅ Success! Added " + addbalAmount + " to user " + addbalTargetId, { parse_mode: "HTML" });

        try {
          Api.sendMessage({
            chat_id: addbalTargetId,
            text: "<blockquote>" +
              "<tg-emoji emoji-id='6192822213486321961'>🗣</tg-emoji> Admin Added: " + addbalAmount + "\n" +
              "<tg-emoji emoji-id='6266967801580231067'>💎</tg-emoji> Balance Credited!\n" +
              "<tg-emoji emoji-id='6267068789146260253'>💰</tg-emoji> Wallet Updated\n" +
              "<tg-emoji emoji-id='5866053971960929280'>🛒</tg-emoji> /start TO SHOP NOW" +
              "</blockquote>",
            parse_mode: "HTML"
          });
        } catch (notifyErr) {}
      } catch (addbalErr) {
        Bot.sendMessage("⚠️ *Error:* " + addbalErr.message, { parse_mode: "Markdown" });
      }
      return;
    }
    if (addbalAllStep === "waiting_input" && msgText) {
      User.setProperty("addbalall_step", null, "string");
      Bot.run({ command: "/addbal_all", options: { message: "/addbal_all " + msgText.trim() } });
      return;
    }
    if (rembalStep === "waiting_input" && msgText) {
      User.setProperty("rembal_step", null, "string");
      Bot.run({ command: "/rembal", options: { message: "/rembal " + msgText.trim() } });
      return;
    }
    if (checkbalStep === "waiting_input" && msgText) {
      User.setProperty("checkbal_step", null, "string");
      Bot.run({ command: "/checkbal", options: { params: msgText.trim() } });
      return;
    }

    var setDownloadLinkStep = User.getProperty("set_download_link_step");
    if (setDownloadLinkStep === "waiting_input" && msgText) {
      User.setProperty("set_download_link_step", null, "string");
      Bot.run({ command: "/set_update_link", options: { params: msgText.trim() } });
      return;
    }

    var setPaymentUpiStep = User.getProperty("set_payment_upi_step");
    if (setPaymentUpiStep === "waiting_input" && msgText) {
      User.setProperty("set_payment_upi_step", null, "string");
      Bot.run({ command: "/set_payment_upi", options: { params: msgText.trim() } });
      return;
    }

    var setDailyGiftPriceStep = User.getProperty("set_dailygift_price_step");
    if (setDailyGiftPriceStep === "waiting_input" && msgText) {
      User.setProperty("set_dailygift_price_step", null, "string");
      Bot.run({ command: "/set_dailygift_price", options: { params: msgText.trim() } });
      return;
    }

    var setReferEarnStep = User.getProperty("set_refer_earn_step");
    if (setReferEarnStep === "waiting_input" && msgText) {
      User.setProperty("set_refer_earn_step", null, "string");
      Bot.run({ command: "/set_refer_earn", options: { params: msgText.trim() } });
      return;
    }

    var setHowLinkStep = User.getProperty("set_how_link_step");
    if (setHowLinkStep === "waiting_input" && msgText) {
      User.setProperty("set_how_link_step", null, "string");
      Bot.run({ command: "/set_how_link", options: { params: msgText.trim() } });
      return;
    }

    var setProofLinkStep = User.getProperty("set_proof_link_step");
    if (setProofLinkStep === "waiting_input" && msgText) {
      User.setProperty("set_proof_link_step", null, "string");
      Bot.run({ command: "/set_proof_link", options: { params: msgText.trim() } });
      return;
    }

    var setSupportLinkStep = User.getProperty("set_support_link_step");
    if (setSupportLinkStep === "waiting_input" && msgText) {
      User.setProperty("set_support_link_step", null, "string");
      Bot.run({ command: "/set_support_link", options: { params: msgText.trim() } });
      return;
    }
  }

  // ==========================================
  // 🎟 MODULE 3: ADMIN COUPON GENERATOR (step-by-step wizard)
  // ==========================================
  if (userId === adminId && couponGenStep) {

    if (couponGenStep === "code") {
      if (!msgText) { Bot.sendMessage("⚠️ Kripya ek valid coupon code bhejein."); return; }
      var couponCodeUpper = msgText.trim().toUpperCase();
      if (Bot.getProperty("coupon_" + couponCodeUpper)) {
        Bot.sendMessage("❌ Ye coupon code pehle se exist karta hai! Doosra naam try karein.");
        return;
      }
      User.setProperty("coupon_gen_code", couponCodeUpper, "string");
      User.setProperty("coupon_gen_step", "maxclaims", "string");
      Bot.sendMessage("<tg-emoji emoji-id='6091571559233755994'>👥</tg-emoji> <b>Kitne users ye coupon use (claim) kar sakte hain?</b>\n<i>Sirf number bhejein, jaise: 50</i>", { parse_mode: "HTML" });
      return;
    }

    if (couponGenStep === "maxclaims") {
      var maxClaimsVal = parseInt(msgText.trim());
      if (isNaN(maxClaimsVal) || maxClaimsVal <= 0) { Bot.sendMessage("❌ Kripya ek valid number bhejein (jaise 50)."); return; }
      User.setProperty("coupon_gen_maxclaims", maxClaimsVal, "number");
      User.setProperty("coupon_gen_step", "discount", "string");
      Bot.sendMessage("<tg-emoji emoji-id='6093591495237967001'>💸</tg-emoji> <b>Kitne % discount dena hai?</b>\n<i>Sirf number bhejein (1-100), jaise: 10</i>", { parse_mode: "HTML" });
      return;
    }

    if (couponGenStep === "discount") {
      var discountVal = parseFloat(msgText.trim());
      if (isNaN(discountVal) || discountVal <= 0 || discountVal > 100) { Bot.sendMessage("❌ Discount 1 se 100 ke beech honi chahiye."); return; }
      User.setProperty("coupon_gen_discount", discountVal, "number");
      User.setProperty("coupon_gen_step", "scope", "string");
      Bot.sendMessage(
        "<tg-emoji emoji-id='6093677128295914531'>🎯</tg-emoji> <b>Scope batayein:</b>\n\n" +
        "• Sabhi products/plans ke liye: <code>global</code> likh kar bhejein\n" +
        "• Sirf ek specific product+plan ke liye: <code>Product Name | Duration</code>\n" +
        "  <i>Example:</i> <code>Atomic Habits (Book) | 1d</code>",
        { parse_mode: "HTML" }
      );
      return;
    }

    if (couponGenStep === "scope") {
      var scopeInput = msgText.trim();
      var couponData = {
        code: User.getProperty("coupon_gen_code"),
        maxClaims: User.getProperty("coupon_gen_maxclaims"),
        discountPercent: User.getProperty("coupon_gen_discount"),
        claimedBy: [],
        isPaused: false,
        createdAt: new Date().toLocaleDateString()
      };

      if (scopeInput.toLowerCase() === "global") {
        couponData.scope = "global";
      } else if (scopeInput.indexOf("|") > -1) {
        var scopeParts = scopeInput.split("|");
        couponData.scope = "specific";
        couponData.productName = scopeParts[0].trim();
        couponData.duration = scopeParts[1].trim();
      } else {
        Bot.sendMessage("❌ Galat format! 'global' likhein ya 'Product Name | Duration' format me bhejein.");
        return;
      }

      Bot.setProperty("coupon_" + couponData.code, couponData, "json");

      // ✅ NEW: master list me bhi add karo, taaki /coupons admin command sabko list kar sake
      var couponList = Bot.getProperty("coupon_list") || [];
      if (couponList.indexOf(couponData.code) === -1) {
        couponList.push(couponData.code);
        Bot.setProperty("coupon_list", couponList, "json");
      }

      // Cleanup wizard state
      User.setProperty("coupon_gen_step", null, "string");
      User.setProperty("coupon_gen_code", null, "string");
      User.setProperty("coupon_gen_maxclaims", null, "number");
      User.setProperty("coupon_gen_discount", null, "number");

      Bot.sendMessage(
        "<blockquote>🎟 <b>COUPON CREATED SUCCESSFULLY!</b></blockquote>\n\n" +
        "🏷 <b>Code:</b> <code>" + couponData.code + "</code>\n" +
        "👥 <b>Max Claims:</b> " + couponData.maxClaims + "\n" +
        "💸 <b>Discount:</b> " + couponData.discountPercent + "%\n" +
        "🎯 <b>Scope:</b> " + (couponData.scope === "global" ? "🌍 Global (All Plans)" : "📦 " + couponData.productName + " (" + couponData.duration + ")"),
        { parse_mode: "HTML" }
      );
      return;
    }
  }

  // ==========================================
  // 🎟 MODULE 4: USER — APPLY COUPON CODE TEXT ENTRY
  // ==========================================
  if (awaitingCouponFor) {
    var enteredCode = msgText.trim().toUpperCase();
    var couponRec = Bot.getProperty("coupon_" + enteredCode);

    User.setProperty("awaiting_coupon_for", null, "string");

    if (!couponRec) {
      Bot.sendMessage("❌ <b>Invalid Coupon Code!</b>", { parse_mode: "HTML" });
      return;
    }
    if (couponRec.isPaused) {
      Bot.sendMessage("⏸ Ye coupon abhi paused hai, thodi der baad try karein.", { parse_mode: "HTML" });
      return;
    }
    if (!Array.isArray(couponRec.claimedBy)) { couponRec.claimedBy = []; }
    if (couponRec.claimedBy.indexOf(userId) > -1) {
      Bot.sendMessage("⚠️ Aapne ye coupon already use kar liya hai!", { parse_mode: "HTML" });
      return;
    }
    if (couponRec.claimedBy.length >= couponRec.maxClaims) {
      Bot.sendMessage("❌ Is coupon ki claim limit khatam ho gayi hai!", { parse_mode: "HTML" });
      return;
    }

    var couponTargetParts = awaitingCouponFor.split(" ");
    var cTargetProdIdx = couponTargetParts[0];
    var cTargetPlanIdx = couponTargetParts[1];

    if (couponRec.scope === "specific") {
      var cProductList = Bot.getProperty("stored_products") || [];
      var cProduct = cProductList[Number(cTargetProdIdx)];
      var cPlan = cProduct ? cProduct.plans[Number(cTargetPlanIdx)] : null;
      var cDurationDisplay = cPlan ? (cPlan.durationDisplay || (cPlan.days + " Days")) : "";
      var matchesProduct = cProduct && cProduct.name.trim().toLowerCase() === couponRec.productName.trim().toLowerCase();
      var matchesDuration = cDurationDisplay.toLowerCase().indexOf(String(couponRec.duration).toLowerCase().replace(/[^a-z0-9]/g, "")) > -1 ||
                             String(couponRec.duration).replace(/[^0-9]/g, "") === String(cPlan ? cPlan.days : "");
      if (!matchesProduct) {
        Bot.sendMessage("❌ Ye coupon is product ke liye valid nahi hai!", { parse_mode: "HTML" });
        return;
      }
    }

    // ✅ Valid — apply and mark claimed
    couponRec.claimedBy.push(userId);
    Bot.setProperty("coupon_" + enteredCode, couponRec, "json");
    User.setProperty("applied_coupon_" + cTargetProdIdx + "_" + cTargetPlanIdx, enteredCode, "string");

    Bot.sendMessage("🎉 <b>Coupon Applied!</b> -" + couponRec.discountPercent + "% discount added.", { parse_mode: "HTML" });

    Bot.run({
      command: "buyitem",
      options: { params: cTargetProdIdx + " " + cTargetPlanIdx }
    });
    return;
  }

  // ==========================================
  // 📢 MODULE 2: PREMIUM BROADCAST SYSTEM
  // ==========================================
  if (userId === adminId && isAwaitingBroadcast) {
    User.setProperty("awaiting_broadcast_data", false, "boolean");
    var userList = Bot.getProperty("all_users_list") || [];

    if (userList.length === 0) {
      Bot.sendMessage("❌ Bot mein abhi tak koi bhi user registered nahi hai.");
      return;
    }

    var targetMessageId = null;
    if (request) {
      if (request.message_id) { targetMessageId = request.message_id; }
      else if (request.message && request.message.message_id) { targetMessageId = request.message.message_id; }
    }

    if (!targetMessageId) {
      Bot.sendMessage("❌ Unable to fetch message ID for broadcast.");
      return;
    }

    Bot.sendMessage("⏳ Sending premium broadcast to " + userList.length + " users... Please wait.");

    // ✅ FIXED: pehle ek bhi blocked/invalid user Api.copyMessage() ko throw karwa deta
    // tha, jo bahar wale catch() tak chala jaata tha — isse loop beech me hi ruk jaata
    // tha (baaki users ko broadcast nahi jaata tha) aur admin ko scary "Error in handling"
    // dikhta tha, jabki zyada tar users ko message mil chuka hota tha. Ab har send apne
    // try/catch me hai, aur end me accurate success/fail count milega.
    var sentCount = 0;
    var failedCount = 0;
    for (var i = 0; i < userList.length; i++) {
      try {
        Api.copyMessage({
          chat_id: String(userList[i]),
          from_chat_id: adminId,
          message_id: Number(targetMessageId)
        });
        sentCount++;
      } catch (perUserErr) {
        failedCount++;
      }
    }
    Bot.sendMessage(
      "✅ <b>Broadcast Complete!</b>\n" +
      "📤 <b>Sent:</b> " + sentCount + " users\n" +
      (failedCount > 0 ? "⚠️ <b>Failed/Blocked:</b> " + failedCount + " users" : "🎉 <b>No failures!</b>"),
      { parse_mode: "HTML" }
    );
  }

} catch (err) {
  Bot.sendMessage("Error in handling: " + err.message);
}