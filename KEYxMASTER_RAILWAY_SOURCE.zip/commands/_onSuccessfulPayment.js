/**#command
name: /onSuccessfulPayment
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// ⭐ Handles Telegram's successful_payment event (Stars payment completed).
// Two payload types:
//   "deposit:<userId>:<amount>"        -> credit Stars wallet balance
//   "buy:<userId>:<prodIdx>:<planIdx>" -> deliver key directly (manual-first, then API)
// ⚠️ PLATFORM NOTE: same routing caveat as _onPreCheckoutQuery.js — this is
// also duplicated as a fallback inside _start.js.
// =========================================================

try {
  var sp = (request && request.message && request.message.successful_payment)
    ? request.message.successful_payment
    : (request && request.successful_payment ? request.successful_payment : null);

  if (!sp) { return; }

  var chatId = chat.chatid;
  var payload = sp.invoice_payload || "";
  var starsPaid = Number(sp.total_amount || 0); // XTR amount = Stars count (no decimals)
  var telegramChargeId = sp.telegram_payment_charge_id || "N/A";

  var parts = payload.split(":");
  var mode = parts[0];

  // 📒 Log every Stars transaction for admin visibility
  function logStarsTransaction(entry) {
    var log = Bot.getProperty("stars_transactions") || [];
    log.push(entry);
    if (log.length > 500) { log = log.slice(log.length - 500); } // keep it bounded
    Bot.setProperty("stars_transactions", log, "json");
  }

  if (mode === "deposit") {
    var depUserId = parts[1];
    var depAmount = Number(parts[2]);

    var current = Number(Bot.getProperty("stars_balance_" + depUserId) || 0);
    var newBal = current + starsPaid;
    Bot.setProperty("stars_balance_" + depUserId, newBal, "number");

    logStarsTransaction({
      type: "deposit",
      userId: depUserId,
      stars: starsPaid,
      chargeId: telegramChargeId,
      date: new Date().toLocaleString()
    });

    Api.sendMessage({
      chat_id: chatId,
      text: "<blockquote>⭐ <b>STARS DEPOSIT SUCCESSFUL!</b></blockquote>\n\n" +
            "⭐ <b>Added:</b> " + starsPaid + " Stars\n" +
            "💫 <b>New Stars Balance:</b> " + newBal + "\n" +
            "🧾 <b>Transaction ID:</b> <code>" + telegramChargeId + "</code>\n\n" +
            "<i>Aapke Stars wallet me add ho gaye!</i>",
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "Back to Menu", callback_data: "/back", style: "primary", icon_custom_emoji_id: "5893163582194978381" }]] })
    });

    var ownerId = Bot.getProperty("owner_id") || "7088682169";
    try {
      Api.sendMessage({
        chat_id: ownerId,
        text: "<blockquote>⭐ <b>NEW STARS DEPOSIT</b></blockquote>\n👤 <b>User:</b> <code>" + depUserId + "</code>\n⭐ <b>Amount:</b> " + starsPaid + " Stars\n🧾 <b>Charge ID:</b> <code>" + telegramChargeId + "</code>",
        parse_mode: "HTML"
      });
    } catch (e) {}

  } else if (mode === "buy") {
    var buyUserId = parts[1];
    var prodIdx = Number(parts[2]);
    var planIdx = Number(parts[3]);

    var productList = Bot.getProperty("stored_products") || [];
    var product = productList[prodIdx];
    var plan = product ? product.plans[planIdx] : null;

    if (!product || !plan) {
      Api.sendMessage({ chat_id: chatId, text: "⚠️ Payment received but product config changed. Contact support with charge ID: " + telegramChargeId, parse_mode: "HTML" });
      return;
    }

    var planUnit = plan.unit || "day";
    var cleanPlanDays = String(plan.days).replace(/[^0-9.]/g, "").trim();
    var durationDisplay = plan.durationDisplay || (cleanPlanDays + " " + (planUnit === "hour" ? "Hour(s)" : planUnit === "minute" ? "Minute(s)" : "Day(s)"));
    var cleanProdName = product.name.trim().toUpperCase();

    // 🔑 MANUAL STOCK FIRST (same rule as the UPI flow — never waste a paid API call if manual stock exists)
    var scopeSuffix = (planUnit === "day") ? cleanPlanDays : (cleanPlanDays + "_" + planUnit);
    var manualKeysStorageKey = "manual_keys_" + cleanProdName + "_" + cleanPlanDays;
    var backupStockKey = "stock_" + product.name.trim() + "_" + cleanPlanDays + "_Day";
    var manualStock = Bot.getProperty(manualKeysStorageKey);
    var isBackupUsed = false;
    if (!manualStock || (Array.isArray(manualStock) && manualStock.length === 0)) {
      manualStock = Bot.getProperty(backupStockKey);
      isBackupUsed = true;
    }
    if (typeof manualStock === "string" && manualStock.trim() !== "") {
      try { manualStock = JSON.parse(manualStock); } catch (e) { manualStock = manualStock.split("\n").map(function (k) { return k.trim(); }).filter(Boolean); }
    }

    var generatedKey = null;
    if (Array.isArray(manualStock) && manualStock.length > 0) {
      generatedKey = manualStock.shift();
      if (isBackupUsed) { Bot.setProperty(backupStockKey, manualStock, "json"); }
      else { Bot.setProperty(manualKeysStorageKey, manualStock, "json"); }
    }

    logStarsTransaction({
      type: "purchase",
      userId: buyUserId,
      product: product.name,
      plan: durationDisplay,
      stars: starsPaid,
      chargeId: telegramChargeId,
      date: new Date().toLocaleString()
    });

    if (generatedKey) {
      // ✅ Manual delivery
      var purchaseHistory = User.getProperty("my_purchased_keys") || [];
      purchaseHistory.push({
        productName: product.name,
        days: durationDisplay,
        key: generatedKey,
        cost: starsPaid + " ⭐",
        date: new Date().toLocaleDateString()
      });
      User.setProperty("my_purchased_keys", purchaseHistory, "json");

      Api.sendMessage({
        chat_id: chatId,
        text: "<blockquote>⭐ <b>PAYMENT SUCCESSFUL — KEY DELIVERED!</b></blockquote>\n\n" +
              "📦 <b>Product:</b> " + product.name + "\n" +
              "⏳ <b>Duration:</b> " + durationDisplay + "\n" +
              "⭐ <b>Paid:</b> " + starsPaid + " Stars\n" +
              "🔑 <b>Your Key:</b> <code>" + generatedKey + "</code>\n\n" +
              "<i>Enjoy your purchase! 🎉</i>",
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "📋 Copy Key", copy_text: { text: generatedKey } }], [{ text: "Back to Menu", callback_data: "/back", style: "primary", icon_custom_emoji_id: "5893163582194978381" }]] })
      });
    } else {
      // No manual stock — flag for admin to deliver via existing API/manual process
      Api.sendMessage({
        chat_id: chatId,
        text: "<blockquote>⭐ <b>PAYMENT RECEIVED!</b></blockquote>\n\n" +
              "<i>Manual stock khaali hai — aapki key jald hi deliver ki jaayegi. Agar API-based delivery configured hai, wo bhi automatically try hogi.</i>\n\n" +
              "🧾 <b>Charge ID:</b> <code>" + telegramChargeId + "</code>",
        parse_mode: "HTML"
      });
    }

    var ownerId2 = Bot.getProperty("owner_id") || "7088682169";
    try {
      Api.sendMessage({
        chat_id: ownerId2,
        text: "<blockquote>⭐ <b>NEW STARS PURCHASE</b></blockquote>\n👤 <b>User:</b> <code>" + buyUserId + "</code>\n📦 <b>Product:</b> " + product.name + " (" + durationDisplay + ")\n⭐ <b>Paid:</b> " + starsPaid + " Stars\n🔑 <b>Delivery:</b> " + (generatedKey ? "Manual Stock ✅" : "PENDING ⚠️") + "\n🧾 <b>Charge ID:</b> <code>" + telegramChargeId + "</code>",
        parse_mode: "HTML"
      });
    } catch (e) {}
  }

} catch (err) {
  try { Bot.sendMessage("⚠️ Successful Payment Handler Error: " + err.message, { parse_mode: "HTML" }); } catch (e2) {}
}