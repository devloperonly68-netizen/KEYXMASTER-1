/**#command
name: /confirm_buyitem
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

function resolveApiDuration(plan, cleanPlanDays, planUnit) {
  var raw = String((plan && (plan.api_duration || plan.name_on_website || plan.durationDisplay || plan.name || plan.title)) || "").replace(/\s+/g, " ").trim();
  var canonical = ["1 DaYS NONROOT","House","1 DaYs","15 DaYs All Colours Mix","30 DaYs PRO","1 DaYs Basic","1 Year Ios Esign Gbox Certificate","1 DaYs Root + Nonroot","7 DaYS PC AIMKILL","30 Day Pc Modmenu x86","3 DaYs SAFE","3 DaYs BRUTAL"];
  for (var i=0;i<canonical.length;i++) if (raw.toLowerCase() === canonical[i].toLowerCase()) return canonical[i];
  var gd=raw.match(/^([0-9]+(?:\.[0-9]+)?)\s*(day|days)$/i);
  if(gd) return Number(gd[1])===1 ? "1 DaYs" : gd[1]+" Days";
  // HOURS: preserve the exact duration entered by admin/API.
  // Examples: "1 Hours", "2 Hours", "12 Hours" all remain unchanged.
  var gh=raw.match(/^([0-9]+(?:\.[0-9]+)?)\s*(hour|hours)$/i);
  if(gh) return raw;
  var gm=raw.match(/^([0-9]+(?:\.[0-9]+)?)\s*(minute|minutes)$/i);
  if(gm) return gm[1]+(Number(gm[1])===1?" Minute":" Minutes");
  return raw || (Number(cleanPlanDays||"1")===1 ? "1 DaYs" : String(cleanPlanDays)+" Days");
}


// =========================================================
// ✅ ACTUAL PURCHASE EXECUTION — runs after user taps "Confirm" on the
// premium confirmation screen, OR automatically right after a shortfall
// QR payment is verified (see _onCheck.js), so key delivery is fully automatic.
// =========================================================

try {
  var productList = Bot.getProperty("stored_products") || [];
  var chatId = chat.chatid;
  var userId = user.telegramid;

  var parts = params ? String(params).trim().split(" ") : [];
  var prodIdx = Number(parts[0]);
  var planIdx = Number(parts[1]);

  var product = productList[prodIdx];
  if (!product || !product.plans || !product.plans[planIdx]) {
    Api.sendMessage({ chat_id: chatId, text: "❌ Product or Plan configuration missing!" });
    return;
  }

  var plan = product.plans[planIdx];
  var planUnit = plan.unit || "day";
  var isReseller = Bot.getProperty("is_reseller_" + userId) === true;

  var cleanProdName = product.name.trim().toUpperCase();
  var cleanPlanDays = String(plan.days).replace(/[^0-9.]/g, "").trim();
  var unitLabelWord = (planUnit === "hour") ? (Number(cleanPlanDays) === 1 ? "Hour" : "Hours") :
                       (planUnit === "minute") ? (Number(cleanPlanDays) === 1 ? "Minute" : "Minutes") :
                       (Number(cleanPlanDays) === 1 ? "Day" : "Days");
  var durationDisplay = plan.durationDisplay || (cleanPlanDays + " " + unitLabelWord);

  var priceKeySuffix = (planUnit === "day") ? cleanPlanDays : (cleanPlanDays + "_" + planUnit);
  var normalKey = "price_normal_" + cleanProdName + "_" + priceKeySuffix;
  var resellerKey = "price_reseller_" + cleanProdName + "_" + priceKeySuffix;

  var adminNormalPrice = Bot.getProperty(normalKey);
  var adminResellerPrice = Bot.getProperty(resellerKey);

  var currentNormal = (adminNormalPrice !== undefined && adminNormalPrice !== null) ? adminNormalPrice : plan.normal_price;
  var currentReseller = (adminResellerPrice !== undefined && adminResellerPrice !== null) ? adminResellerPrice : plan.reseller_price;

  var originalPrice = isReseller ? Number(currentReseller) : Number(currentNormal);
  var price = originalPrice;

  var planSpecificDiscKey = "auto_discount_" + cleanProdName + "_" + cleanPlanDays + "_" + planUnit.toUpperCase();
  var productWideDiscKey = "auto_discount_" + cleanProdName + "_ALL";
  var autoDiscountPercent = Bot.getProperty(planSpecificDiscKey) || Bot.getProperty(productWideDiscKey) || Bot.getProperty("auto_discount_global") || 0;

  // 🎟 Apply coupon discount (if any was applied for this exact prod/plan) — coupon overrides auto-discount
  var appliedCouponCode = User.getProperty("applied_coupon_" + prodIdx + "_" + planIdx);
  var couponDiscountPercent = 0;
  if (appliedCouponCode) {
    var couponRec0 = Bot.getProperty("coupon_" + appliedCouponCode);
    if (couponRec0 && couponRec0.discountPercent) {
      couponDiscountPercent = couponRec0.discountPercent;
      price = Number((originalPrice * (1 - couponDiscountPercent / 100)).toFixed(2));
    }
    User.setProperty("applied_coupon_" + prodIdx + "_" + planIdx, null, "string");
  } else if (autoDiscountPercent > 0) {
    couponDiscountPercent = autoDiscountPercent;
    price = Number((originalPrice * (1 - autoDiscountPercent / 100)).toFixed(2));
  }

  // 🛡️ Safety re-check: balance abhi bhi sufficient hai ya nahi (race-condition guard)
  var unifiedBal = (function () {
    var resBal = 0;
    try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
    var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
    return resBal + bonusBal;
  })();

  if (unifiedBal < price) {
    Api.sendMessage({
      chat_id: chatId,
      text: "⚠️ <b>Balance abhi kam hai.</b> Kripya phir se try karein.",
      parse_mode: "HTML"
    });
    return;
  }

  // =====================================================
  // 🔑 STEP 0 — MANUAL STOCK FIRST CHECK (✅ NEW)
  // Agar admin ne manually koi key already daal rakhi hai, to wahi seedha
  // deliver karo aur PAID EXTERNAL API ko bilkul call hi mat karo — taaki
  // "1 available key ke liye 2 keys spend" (1 manual + 1 wasted API buy)
  // wala bug kabhi na ho. API sirf tabhi call hoga jab manual stock khaali ho.
  // =====================================================
  var pDaysNumOnly = cleanPlanDays;
  var manualKeysStorageKey = "manual_keys_" + cleanProdName + "_" + pDaysNumOnly;
  var backupStockKey = "stock_" + product.name.trim() + "_" + pDaysNumOnly + "_Day";
  var isBackupUsed = false;

  var manualStock = Bot.getProperty(manualKeysStorageKey);
  if (!manualStock || (Array.isArray(manualStock) && manualStock.length === 0)) {
    manualStock = Bot.getProperty(backupStockKey);
    isBackupUsed = true;
  }
  if (typeof manualStock === "string" && manualStock.trim() !== "") {
    try {
      manualStock = JSON.parse(manualStock);
    } catch (err) {
      manualStock = manualStock.split("\n").map(function (k) { return k.trim(); }).filter(Boolean);
    }
  }

  if (Array.isArray(manualStock) && manualStock.length > 0) {
    var generatedKey = manualStock.shift();

    if (isBackupUsed) {
      Bot.setProperty(backupStockKey, manualStock, "json");
      var mainStock = Bot.getProperty(manualKeysStorageKey) || [];
      if (typeof mainStock === "string") { mainStock = mainStock.split("\n").map(function (k) { return k.trim(); }).filter(Boolean); }
      if (Array.isArray(mainStock)) {
        var idx1 = mainStock.indexOf(generatedKey);
        if (idx1 > -1) { mainStock.splice(idx1, 1); }
        Bot.setProperty(manualKeysStorageKey, mainStock, "json");
      }
    } else {
      Bot.setProperty(manualKeysStorageKey, manualStock, "json");
      var backupStock2 = Bot.getProperty(backupStockKey) || [];
      if (typeof backupStock2 === "string") { backupStock2 = backupStock2.split("\n").map(function (k) { return k.trim(); }).filter(Boolean); }
      if (Array.isArray(backupStock2)) {
        var idx2 = backupStock2.indexOf(generatedKey);
        if (idx2 > -1) { backupStock2.splice(idx2, 1); }
        Bot.setProperty(backupStockKey, backupStock2, "json");
      }
    }

    // 💰 Deduct balance + record purchase (same accounting as API path)
    Libs.ResourcesLib.userRes("balance").add(-price);
    var pastSpent2 = Bot.getProperty("total_spent_by_" + userId) || 0;
    Bot.setProperty("total_spent_by_" + userId, Number(pastSpent2) + price, "number");

    // 🎁 REFER & EARN — referrer bonus jab referred friend PEHLI baar purchase kare
    try {
      var referredByBuy2 = User.getProperty("referred_by");
      if (referredByBuy2 && !User.getProperty("ref_buy_bonus_given")) {
        var refBonusBuy2 = Number(Bot.getProperty("refer_earn_buy_amount"));
        if (isNaN(refBonusBuy2)) refBonusBuy2 = 2;
        if (refBonusBuy2 > 0) {
          Libs.ResourcesLib.anotherUserRes("balance", referredByBuy2).add(refBonusBuy2);
          var pastEarnBuy2 = Number(Bot.getProperty("refer_earnings_" + referredByBuy2) || 0);
          Bot.setProperty("refer_earnings_" + referredByBuy2, pastEarnBuy2 + refBonusBuy2, "number");
          try {
            Api.sendMessage({
              chat_id: referredByBuy2,
              text: "<blockquote>💸 <b>Referral Bonus!</b>\n\nAapke referred friend ne pehli purchase ki — aapko ₹" + refBonusBuy2.toFixed(2) + " mile hain!</blockquote>",
              parse_mode: "HTML"
            });
          } catch (e) {}
        }
        User.setProperty("ref_buy_bonus_given", true, "boolean");
      }
    } catch (e) {}

    var keysHistory2 = User.getProperty("my_purchased_keys") || [];
    keysHistory2.push({
      product: String(product.name).trim(),
      product_id: product.id || null,
      days: pDaysNumOnly,
      price: price,
      key: generatedKey,
      date: new Date().toLocaleDateString()
    });
    User.setProperty("my_purchased_keys", keysHistory2, "json");

    var remainingBal2 = Libs.ResourcesLib.userRes("balance").value().toFixed(2);

    // ✅ NEW: Key ke saath automatic "Join Updates" button attach hota hai (agar admin ne link set kiya ho)
    var updateLinkForKey = Bot.getProperty("update_channel_link");
    var keyDeliveryButtons = [[{ text: "📋 Copy Key", copy_text: { text: generatedKey } }]];
    if (updateLinkForKey) {
      keyDeliveryButtons.push([{ text: "📥 Join Updates", url: updateLinkForKey, style: "primary", icon_custom_emoji_id: "6091571559233755994" }]);
    }
    keyDeliveryButtons.push([{ text: "Back to Menu", callback_data: "/back", style: "primary", icon_custom_emoji_id: "5893163582194978381" }]);
    var keyDeliveryMarkup = JSON.stringify({ inline_keyboard: keyDeliveryButtons });

    var deliverText2 = "<blockquote>" +
      "<tg-emoji emoji-id='5350447674971660988'>✅</tg-emoji> <b>PURCHASE SUCCESSFUL!</b>\n\n" +
      "<tg-emoji emoji-id='6147767796097884213'>📦</tg-emoji> <b>Product:</b> <code>" + String(product.name).trim() + "</code>\n" +
      "<tg-emoji emoji-id='6284816251143331422'>🗝</tg-emoji> <b>Validity:</b> <code>" + durationDisplay + "</code>\n" +
      "<tg-emoji emoji-id='5352825278672412291'>👆</tg-emoji> <b>Your Key:</b> <code>" + generatedKey + "</code>\n\n" +
      "━━━━━ <tg-emoji emoji-id='6147934084346682063'>#⃣</tg-emoji> <b>BALANCE DETAILS</b> ━━━━━\n" +
      "<tg-emoji emoji-id='6195037488898121775'>✨</tg-emoji> <b>Total Invest:</b> ₹" + price.toFixed(2) + "\n" +
      "<tg-emoji emoji-id='5409048419211682843'>💵</tg-emoji> <b>New Wallet Balance:</b> ₹" + remainingBal2 + "\n\n" +
      "<i>Enjoy your purchase. <tg-emoji emoji-id='6057881002540274780'>🥳</tg-emoji></i>" +
      "</blockquote>";

    if (request && request.message) {
      try {
        Api.editMessageText({
          chat_id: String(chatId),
          message_id: Number(request.message.message_id),
          text: deliverText2,
          parse_mode: "HTML",
          reply_markup: keyDeliveryMarkup
        });
      } catch (e) {
        Api.sendMessage({ chat_id: chatId, text: deliverText2, parse_mode: "HTML", reply_markup: keyDeliveryMarkup });
      }
    } else {
      Api.sendMessage({ chat_id: chatId, text: deliverText2, parse_mode: "HTML", reply_markup: keyDeliveryMarkup });
    }

    var adminId3 = "7088682169";
    Api.sendMessage({
      chat_id: adminId3,
      text: "🔔 <b>NEW PURCHASE DELIVERED (MANUAL STOCK)</b> ✔️\n\n" +
            "👤 <b>Buyer:</b> " + (user.first_name || "User") + " (<code>" + userId + "</code>)\n" +
            "📦 <b>Product:</b> " + String(product.name).trim() + "\n" +
            "⏳ <b>Plan:</b> " + durationDisplay + "\n" +
            "💸 <b>Price Deducted:</b> ₹" + price.toFixed(2) + "\n" +
            "💳 <b>User Remaining Bal:</b> ₹" + remainingBal2 + "\n" +
            "🔑 <b>Key:</b> <code>" + generatedKey + "</code>\n\n" +
            "<i>✅ Manual stock se deliver hui — external paid API call SKIP ki gayi.</i>",
      parse_mode: "HTML"
    });

    var qId0 = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
    if (qId0) {
      try { Api.answerCallbackQuery({ callback_query_id: String(qId0), text: "✅ Key Delivered!", show_alert: false }); } catch (e) {}
    }

    return; // 🚫 STOP — external API bilkul call nahi hui
  }

  var webProductId = String(product.id || "PID_ID").trim();
  var prodNameLower = String(product.name).toLowerCase();

  var durationParam = resolveApiDuration(plan, cleanPlanDays, planUnit);

  // =====================================================
  // 🔌 MULTI-API SYSTEM
  // Admin can add/update/select multiple reseller APIs.
  // The active API is used for external purchases.
  // =====================================================
  var apiRegistry = Bot.getProperty("api_registry") || {};
  var activeApiId = Bot.getProperty("active_reseller_api");
  var selectedApi = activeApiId ? apiRegistry[activeApiId] : null;

  // Backward-compatible bootstrap from the existing API configuration.
  if (!selectedApi) {
    selectedApi = {
      id: "default",
      name: "Default Reseller API",
      url: "https://xyzcheats.com/api/reseller_v1.php",
      api_key: process.env.RESELLER_API_KEY || "",
      master_key: process.env.RESELLER_MASTER_KEY || "",
      mode: "reseller_v1",
      android_required: false,
      enabled: true
    };
    apiRegistry.default = selectedApi;
    Bot.setProperty("api_registry", apiRegistry, "json");
    Bot.setProperty("active_reseller_api", "default", "string");
  }

  if (selectedApi.enabled === false) {
    Api.sendMessage({chat_id: chatId, text: "❌ Selected API is disabled. Admin ko /apiset se another API select karna hoga."});
    return;
  }

  var webProductId = String(product.id || "PID_ID").trim();
  var prodNameLower = String(product.name).toLowerCase();

  var durationParam = resolveApiDuration(plan, cleanPlanDays, planUnit);

  // Product-level API override is supported: product.api_id.
  var productApiId = product.api_id ? String(product.api_id).trim() : "";
  if (productApiId && apiRegistry[productApiId] && apiRegistry[productApiId].enabled !== false) {
    selectedApi = apiRegistry[productApiId];
    activeApiId = productApiId;
  }

  var postFields = {
    api_key: selectedApi.api_key || "",
    action: "buy",
    product_id: webProductId,
    duration: durationParam
  };

  // Device-bound APIs can require android_id. The value may be saved by
  // your existing product/user flow as android_id_<USER_ID>.
  var savedAndroidId = User.getProperty("android_id") || User.getProperty("android_id_" + userId) ||
                       Bot.getProperty("android_id_" + userId) || "";
  if (selectedApi.android_required) {
    if (!savedAndroidId) {
      Api.sendMessage({
        chat_id: chatId,
        text: "⚠️ <b>Android ID required</b>\nIs API/product ke liye Android ID zaroori hai. Pehle user ka Android ID save karein.",
        parse_mode: "HTML"
      });
      return;
    }
    postFields.android_id = String(savedAndroidId);
  } else if (savedAndroidId) {
    // Optional APIs may also accept it.
    postFields.android_id = String(savedAndroidId);
  }

  var apiHeaders = {
    "Content-Type": "application/x-www-form-urlencoded"
  };
  if (selectedApi.master_key) apiHeaders["x-master-key"] = selectedApi.master_key;

  var postFieldsString = Object.keys(postFields).map(function(k) {
    return encodeURIComponent(k) + "=" + encodeURIComponent(postFields[k]);
  }).join("&");

  User.setProperty("last_pending_price", Number(price), "number");
  User.setProperty("last_pending_prod_id", webProductId, "string");
  User.setProperty("last_pending_prod_name", String(product.name).trim(), "string");
  User.setProperty("last_pending_plan_days", cleanPlanDays, "string");
  User.setProperty("last_pending_plan_unit", planUnit, "string");
  User.setProperty("last_pending_api_id", String(selectedApi.id || activeApiId || ""), "string");

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;

  var processingText = "<tg-emoji emoji-id='6147936236125298267'>⏳</tg-emoji> <b>Processing your order... please wait!</b>";
  if (request && request.message) {
    try {
      Api.editMessageText({
        chat_id: String(chatId),
        message_id: Number(request.message.message_id),
        text: processingText,
        parse_mode: "HTML"
      });
      Bot.setProperty("gen_msg_id_" + userId, request.message.message_id, "string");
      User.setProperty("gen_msg_id_" + userId, request.message.message_id, "string");
    } catch (e) {
      var pm1 = Api.sendMessage({ chat_id: chatId, text: processingText, parse_mode: "HTML" });
      try {
        var pmid1 = (pm1 && pm1.result && pm1.result.message_id) ? pm1.result.message_id : (pm1 && pm1.message_id ? pm1.message_id : null);
        if (pmid1) { Bot.setProperty("gen_msg_id_" + userId, pmid1, "string"); User.setProperty("gen_msg_id_" + userId, pmid1, "string"); }
      } catch (e2) {}
    }
  } else {
    var pm2 = Api.sendMessage({ chat_id: chatId, text: processingText, parse_mode: "HTML" });
    try {
      var pmid2 = (pm2 && pm2.result && pm2.result.message_id) ? pm2.result.message_id : (pm2 && pm2.message_id ? pm2.message_id : null);
      if (pmid2) { Bot.setProperty("gen_msg_id_" + userId, pmid2, "string"); User.setProperty("gen_msg_id_" + userId, pmid2, "string"); }
    } catch (e2) {}
  }

  HTTP.post({
    url: selectedApi.url,
    body: postFieldsString,
    headers: apiHeaders,
    success: "/onWebKeyReceive",
    error: "/onWebKeyError"
  });

  if (queryId) {
    try {
      Api.answerCallbackQuery({
        callback_query_id: String(queryId),
        text: "⏳ Processing your order... Please wait!",
        show_alert: false
      });
    } catch (e) {}
  }

} catch (e) {
  var errChatId = (typeof chat !== "undefined" && chat && chat.chatid) ? chat.chatid : null;
  if (errChatId) {
    try { Api.sendMessage({ chat_id: errChatId, text: "❌ <b>Error:</b> <code>" + e.message + "</code>", parse_mode: "HTML" }); } catch (fatal) {}
  }
}