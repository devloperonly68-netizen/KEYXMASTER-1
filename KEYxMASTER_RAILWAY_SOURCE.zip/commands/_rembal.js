/**#command
name: /rembal
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// ✅ FIXED (v3): dynamic owner_id + co-admin check (same fix as /addbal).
let admin_id = Bot.getProperty("owner_id") || "7088682169";
let requesterId = String(user.telegramid);
let isCoAdmin = Bot.getProperty("co_admin_" + requesterId);

if (requesterId === admin_id || isCoAdmin) {

    // ✅ FIXED: instantly ack the button press so it doesn't feel stuck/slow.
    if (request && request.id) {
        try {
            HTTP.post({
                url: "https://api.telegram.org/bot" + bot.token + "/answerCallbackQuery",
                body: { callback_query_id: request.id }
            });
        } catch (ackErr) {}
    }

    let params = (typeof message !== "undefined" && message) ? message.split(" ") : [];
    let data = params[1];

    // ✅ FIXED: same button-click bug as /addbal — ab prompt aata hai.
    if (!data || !data.includes("|")) {
        User.setProperty("rembal_step", "waiting_input", "string");
        Bot.sendMessage(
            "<tg-emoji emoji-id='5409048419211682843'>💵</tg-emoji> <b>Remove Balance</b>\n\n" +
            "<i>User ID aur amount is format me reply karein:</i>\n<code>user_id|amount</code>\n\n" +
            "<i>Example:</i> <code>7088682169|50</code>",
            {parse_mode: "HTML"}
        );
        return;
    }

    let splitData = data.split("|");
    let targetUserId = splitData[0].trim();
    let amountToRemove = parseFloat(splitData[1].trim());

    if (!targetUserId || isNaN(amountToRemove) || amountToRemove <= 0) {
        Bot.sendMessage("❌ *Invalid Format! Use:* `user_id|amount`", {parse_mode: "Markdown"});
        return;
    }

    try {
        // Balance remove/deduct karna
        let targetUserBalance = Libs.ResourcesLib.anotherUserRes("balance", targetUserId);
        targetUserBalance.remove(amountToRemove);

        // Admin notification
        Bot.sendMessage("✅ Success! Removed " + amountToRemove + " from user " + targetUserId, {parse_mode: "HTML"});

        // New 3 Premium Emojis in Quote Style
        let notificationText =
            "<blockquote>" +
            "<tg-emoji emoji-id='5893163582194978381'>❌</tg-emoji> Admin Remove: " + amountToRemove + "\n" +
            "<tg-emoji emoji-id='6071272104978814192'>😞</tg-emoji> Check your balance now\n" +
            "<tg-emoji emoji-id='5257963315258204021'>ℹ️</tg-emoji> Use /balance To Check" +
            "</blockquote>";

        // ✅ FIXED: raw HTTP.post ki jagah Api.sendMessage — zyada reliable delivery.
        try {
            Api.sendMessage({
                chat_id: targetUserId,
                text: notificationText,
                parse_mode: "HTML"
            });
        } catch (notifyErr) {}

    } catch (err) {
        Bot.sendMessage("⚠️ *Error:* " + err.message, {parse_mode: "Markdown"});
    }

} else {
    Bot.sendMessage("❌ You are not authorized to use this command.");
}
