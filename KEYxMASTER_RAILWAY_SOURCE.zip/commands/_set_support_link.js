/**#command
name: /set_support_link
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🔧 ADMIN — Configure the "Support" section's admin contact link
// Usage: /set_support_link @your_username
//     or /set_support_link https://t.me/your_username
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin0 = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  if (!params || params.trim() === "") {
    var currentLink = Bot.getProperty("support_link") || "https://t.me/Galu_Modz_Owner (default)";
    Bot.sendMessage(
      "⚠️ <b>Format:</b> <code>/set_support_link @your_username</code>\n" +
      "<i>ya poora link bhi bhej sakte hain:</i> <code>/set_support_link https://t.me/your_username</code>\n\n" +
      "<b>Current link:</b> " + currentLink,
      { parse_mode: "HTML" }
    );
    return;
  }

  var input = params.trim();
  var link;

  // ✅ Admin sirf apna @username bhi bhej sakta hai — automatically
  // https://t.me/username link ban jaayegi. Poora link bhi accept hota hai.
  if (input.indexOf("http") === 0) {
    link = input;
  } else {
    var cleanUsername = input.replace(/^@/, "").trim();
    if (!cleanUsername) {
      Bot.sendMessage("❌ Valid username ya link bhejein!");
      return;
    }
    link = "https://t.me/" + cleanUsername;
  }

  Bot.setProperty("support_link", link, "string");
  Bot.sendMessage("✅ <b>Support contact link update ho gaya:</b>\n" + link, { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
