/**#command
name: /addbal_binance
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🟡 "Binance Pay" chosen on Add Balance screen — shows the admin-set
// Binance QR (photo file_id OR image URL, whichever admin configured) with
// the amount converted to USD, plus Binance Pay ID + USDT Address.
// Koi live-verify API nahi hai, isliye "I Paid" ek manual Support flow
// shuru karta hai (UTR + screenshot -> admin ko forward).
// =========================================================

try {
  let userId = user.telegramid;
  let callbackId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;

  let inrAmount = String(parseInt(params ? String(params).trim() : "0"));
  if (!inrAmount || inrAmount === "0" || isNaN(parseInt(inrAmount)) || parseInt(inrAmount) <= 0) {
    Bot.sendMessage("❌ Invalid amount!");
    return;
  }

  let qrFileId = Bot.getProperty("binance_qr_file_id");
  let qrUrl = Bot.getProperty("binance_qr_url");
  let qrSource = qrFileId || qrUrl;

  let binanceId = Bot.getProperty("binance_pay_id");
  let usdtAddress = Bot.getProperty("binance_usdt_address");
  let usdRate = Number(Bot.getProperty("usd_rate") || 91);
  let usdAmount = (parseInt(inrAmount) / usdRate).toFixed(2);

  if (!qrSource || !binanceId || !usdtAddress) {
    if (callbackId) {
      Api.answerCallbackQuery({
        callback_query_id: String(callbackId),
        text: "⚠️ Binance Pay abhi configure nahi hua hai. Kripya Support se contact karein.",
        show_alert: true
      });
    }
    return;
  }

  User.setProperty("binance_pending_amount_inr", inrAmount, "string");
  User.setProperty("binance_pending_amount_usd", usdAmount, "string");

  let e_binance = "<tg-emoji emoji-id='6312263493051489212'>🟡</tg-emoji>";
  let e_check = "<tg-emoji emoji-id='6100657257605763582'>✔️</tg-emoji>";

  let caption =
    "<blockquote>" + e_binance + " <b>BINANCE PAY</b></blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "<tg-emoji emoji-id='6312263493051489212'>💰</tg-emoji> <b>Amount:</b> $<code>" + usdAmount + "</code> <i>(₹" + inrAmount + ")</i>\n\n" +
    "<b>Binance Pay ID</b>\n<code>" + binanceId + "</code>\n\n" +
    "<b>USDT Address</b>\n<code>" + usdtAddress + "</code>\n\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n" +
    "<tg-emoji emoji-id='6100170496077204999'>📋</tg-emoji> <b>Instructions</b>\n" +
    "• Scan the QR in your Binance app, or pay to the ID/Address above.\n" +
    "• Pay the exact amount shown.\n" +
    "• Tap <b>I Paid</b> below and follow the steps to submit proof.\n\n" +
    e_check + " <i>Support team will verify and credit your balance.</i>";

  let inlineButtons = [
    [{ text: "I Paid", callback_data: "/addbal_binance_paid", style: "success", icon_custom_emoji_id: "6100657257605763582" }],
    [{ text: "Cancel", callback_data: "/cancel_topup", style: "danger", icon_custom_emoji_id: "6219547832169273793" }]
  ];

  // Agar purani QR/generating message chat me hai, use hata do
  try {
    let genMsgId = Bot.getProperty("gen_msg_id_" + userId) || User.getProperty("gen_msg_id_" + userId);
    if (genMsgId) {
      try { Api.deleteMessage({ chat_id: chat.chatid, message_id: genMsgId }); } catch (e) {}
      Bot.setProperty("gen_msg_id_" + userId, null, "string");
      User.setProperty("gen_msg_id_" + userId, null, "string");
    }
  } catch (e) {}

  if (request && request.message && !request.message.photo) {
    try { Api.deleteMessage({ chat_id: chat.chatid, message_id: request.message.message_id }); } catch (e) {}
  }

  let sentMsg = Api.sendPhoto({
    chat_id: chat.chatid,
    photo: qrSource,
    caption: caption,
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: inlineButtons })
  });

  try {
    let qrMsgId = (sentMsg && sentMsg.result && sentMsg.result.message_id) ? sentMsg.result.message_id : (sentMsg && sentMsg.message_id ? sentMsg.message_id : null);
    if (qrMsgId) {
      Bot.setProperty("qr_msg_id_" + userId, qrMsgId, "string");
      User.setProperty("qr_msg_id_" + userId, qrMsgId, "string");
    }
  } catch (e) {}

  if (callbackId) {
    Api.answerCallbackQuery({ callback_query_id: String(callbackId) });
  }

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}
