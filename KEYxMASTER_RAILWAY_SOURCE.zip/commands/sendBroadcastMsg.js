/**#command
name: sendBroadcastMsg
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  // Admin ke bhejey hue request data ko access karna
  var mediaRequest = options.msg;

  // Ye har user ko unka message content (Text/Media) clone karke bhej dega
  Bot.sendMessage(mediaRequest); 
  
} catch (err) {
  // 
}