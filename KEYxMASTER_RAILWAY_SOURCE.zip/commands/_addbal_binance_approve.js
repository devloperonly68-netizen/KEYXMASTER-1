/**#command
name: /addbal_binance_approve
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// ✅ ADMIN — "Approve & Credit" button on a Binance submission forward.
// Same crediting logic as /addbal, triggered with one tap instead of typing.
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin0 = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) {
    Bot.sendMessage("❌ You are not authorized to use this.");
    return;
  }

  var callbackId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  var parts = params ? String(params).trim().split(" ") : [];
  var targetId = parts[0];
  var amount = parseFloat(parts[1]);

  if (!targetId || isNaN(amount) || amount <= 0) {
    if (callbackId) {
      Api.answerCallbackQuery({ callback_query_id: String(callbackId), text: "❌ Invalid data.", show_alert: true });
    }
    return;
  }

  try {
    try { Libs.ResourcesLib.anotherUserRes("balance", targetId).add(amount); } catch (resErr) {}

    var prevBonus = Number(Bot.getProperty("balance" + targetId) || 0);
    Bot.setProperty("balance" + targetId, (prevBonus + amount).toFixed(2), "string");

    if (request && request.message && request.message.message_id) {
      try {
        Api.editMessageCaption({
          chat_id: chat.chatid,
          message_id: request.message.message_id,
          caption: (request.message.caption || "") + "\n\n<blockquote>✅ <b>APPROVED & CREDITED</b></blockquote>",
          parse_mode: "HTML"
        });
      } catch (e) {}
    }

    try {
      Api.sendMessage({
        chat_id: targetId,
        text: "<blockquote>" +
          "<tg-emoji emoji-id='6192822213486321961'>🗣</tg-emoji> Admin Approved: ₹" + amount + "\n" +
          "<tg-emoji emoji-id='6266967801580231067'>💎</tg-emoji> Balance Credited!\n" +
          "<tg-emoji emoji-id='5866053971960929280'>🛒</tg-emoji> /start TO SHOP NOW" +
          "</blockquote>",
        parse_mode: "HTML"
      });
    } catch (notifyErr) {}

    if (callbackId) {
      Api.answerCallbackQuery({ callback_query_id: String(callbackId), text: "✅ Credited ₹" + amount + " to " + targetId });
    }
  } catch (addbalErr) {
    Bot.sendMessage("⚠️ Error: " + addbalErr.message);
  }

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}
