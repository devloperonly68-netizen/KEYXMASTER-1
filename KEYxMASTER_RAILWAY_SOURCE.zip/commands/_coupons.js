/**#command
name: /coupons
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🎟 ADMIN/CO-ADMIN — View all coupons with usage stats + Pause/Resume/Delete
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== ownerId && !isCoAdmin) {
    Bot.sendMessage("❌ Restricted command!");
    return;
  }

  var couponList = Bot.getProperty("coupon_list") || [];

  if (couponList.length === 0) {
    Bot.sendMessage("<blockquote>🎟 <b>No coupons created yet.</b>\n<i>Use /gencoupon to create one.</i></blockquote>", { parse_mode: "HTML" });
    return;
  }

  var text = "<blockquote>🎟 <b>ALL COUPONS</b></blockquote>\n━━━━━━━━━━━━━━━━━━━━━\n\n";
  var buttons = [];

  for (var i = 0; i < couponList.length; i++) {
    var code = couponList[i];
    var c = Bot.getProperty("coupon_" + code);
    if (!c) continue;

    var claimedCount = Array.isArray(c.claimedBy) ? c.claimedBy.length : 0;
    var statusLabel = c.isPaused ? "⏸ Paused" : "✅ Active";
    var scopeLabel = c.scope === "global" ? "🌍 Global" : "📦 " + (c.productName || "?") + " (" + (c.duration || "?") + ")";

    text += "🏷 <b>" + code + "</b> — " + statusLabel + "\n" +
            "💸 " + c.discountPercent + "% off | 👥 " + claimedCount + "/" + c.maxClaims + " claimed\n" +
            scopeLabel + "\n\n";

    buttons.push([
      { text: (c.isPaused ? "▶ Resume" : "⏸ Pause") + " " + code, callback_data: "/pause_coupon " + code, style: c.isPaused ? "success" : "primary" },
      { text: "🗑 Delete " + code, callback_data: "/delete_coupon " + code, style: "danger" }
    ]);
  }

  buttons.push([{ text: "Back to Admin Panel", callback_data: "/admin", style: "primary", icon_custom_emoji_id: "5893163582194978381" }]);

  Api.sendMessage({
    chat_id: chat.chatid,
    text: text,
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: buttons })
  });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}