/**#command
name: /support
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  if (request && request.id) {
    HTTP.post({
      url: "https://api.telegram.org/bot" + bot.token + "/answerCallbackQuery",
      body: { callback_query_id: request.id }
    });
  }

  var chatId = chat.chatid;
  var messageId = request && request.message ? request.message.message_id : null;

  var text = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
             "<tg-emoji emoji-id='6039605143601680423'>📞</tg-emoji> <b>CUSTOMER SUPPORT CENTER</b>\n" +
             "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
             "<blockquote>" +
             "Welcome to our support desk. If you are facing any issues regarding keys, payments, or services, feel free to contact us.\n\n" +
             "Click the button below to get the admin contact link." +
             "</blockquote>";

  // ✅ FIXED: ab admin ka contact link Admin Panel se set kiya ja sakta hai
  // ("Set Support Link" button) — Bot.getProperty se dynamically load hota
  // hai, hardcoded username pe fix nahi rehta.
  var supportLink = Bot.getProperty("support_link") || "https://t.me/Galu_Modz_Owner";

  var keyboard = {
    inline_keyboard: [
      [
        {
          text: "Contact Admin",
          url: supportLink, 
          style: "primary", 
          icon_custom_emoji_id: "5346024644635804737" 
        }
      ],
      [
        {
          text: "Back",
          callback_data: "/back",
          style: "danger", 
          icon_custom_emoji_id: "5893163582194978381"
        }
      ]
    ]
  };

  var endpoint = messageId ? "editMessageText" : "sendMessage";
  var requestBody = {
    chat_id: String(chatId),
    text: text,
    parse_mode: "HTML",
    reply_markup: JSON.stringify(keyboard)
  };

  if (messageId) { requestBody.message_id = Number(messageId); }

  HTTP.post({
    url: "https://api.telegram.org/bot" + bot.token + "/" + endpoint,
    body: requestBody
  });

} catch (err) {}