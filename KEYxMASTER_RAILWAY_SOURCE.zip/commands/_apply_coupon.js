/**#command
name: /apply_coupon
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// ⭐ USER — "Apply Coupon Code" button handler
// Prompts the user for a coupon code; _start.js MODULE 4 handles the reply.
// =========================================================

try {
  var parts = params ? String(params).trim().split(" ") : [];
  var prodIdx = parts[0];
  var planIdx = parts[1];

  User.setProperty("awaiting_coupon_for", prodIdx + " " + planIdx, "string");

  var text =
    "<blockquote><tg-emoji emoji-id='6093677128295914531'>🎫</tg-emoji> <b>APPLY COUPON CODE</b></blockquote>\n\n" +
    "<i>Apna coupon code type karke bhejein...</i>";

  if (request && request.message) {
    try {
      Api.editMessageText({
        chat_id: String(chat.chatid),
        message_id: Number(request.message.message_id),
        text: text,
        parse_mode: "HTML"
      });
    } catch (e) {
      Api.sendMessage({ chat_id: chat.chatid, text: text, parse_mode: "HTML" });
    }
  } else {
    Api.sendMessage({ chat_id: chat.chatid, text: text, parse_mode: "HTML" });
  }

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) {
    try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {}
  }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}