/**#command
name: /back
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🚀 PREMIUM STORE MASTER DASHBOARD (UPDATED WITH LUDO SPIN)
// STATUS: 100% PRODUCTION READY WITH LIVE BUTTON STYLES
// =========================================================

try {
  var userId = user.telegramid;

  // 💾 BROADCAST SYSTEM: Safe Loop Core
  var userList = [];
  try {
    userList = Bot.getProperty("all_users_list") || [];
    if (!Array.isArray(userList)) { userList = []; }
  } catch (propErr) {
    userList = [];
  }

  var userExists = false;
  for (var i = 0; i < userList.length; i++) {
    if (String(userList[i]) === String(userId)) {
      userExists = true;
      break;
    }
  }
  if (!userExists) {
    userList.push(String(userId));
    Bot.setProperty("all_users_list", userList, "json");
  }

  // 📊 REAL BALANCE FETCH
  var userBal = "0.00";
  try {
    var res = 0;
    if (Libs && Libs.ResourcesLib) {
      res = Libs.ResourcesLib.userRes("balance").value() || 0;
    }
    var adminBal = Bot.getProperty("balance" + userId) || 0;
    userBal = (Number(res) + Number(adminBal)).toFixed(2);
  } catch (balErr) {
    var fallbackBal = Bot.getProperty("balance" + userId) || 0;
    userBal = Number(fallbackBal).toFixed(2);
  }

  // 💎 WELCOME MESSAGE EMOJIS (Sirf Text Message ke liye)
  var EMJ_HEADER_ROCKET = "<tg-emoji emoji-id='5217822164362739968'>🚀</tg-emoji>";
  var EMJ_HEADER_NEW    = "<tg-emoji emoji-id='6194809138371904539'>✨</tg-emoji>"; 
  var EMJ_HEADER_SHIELD = "<tg-emoji emoji-id='6113743082358841933'>🔰</tg-emoji>";

  // Welcome message ke saare items ke variables:
  var MSG_EMJ_STORE     = "<tg-emoji emoji-id='5866053971960929280'>🛒</tg-emoji>";
  var MSG_EMJ_FFID      = "<tg-emoji emoji-id='5334890573281114250'>🎮</tg-emoji>"; 
  var MSG_EMJ_PROFILE   = "<tg-emoji emoji-id='5260399854500191689'>🔰</tg-emoji>";
  var MSG_EMJ_ADDBAL    = "<tg-emoji emoji-id='6147815702163102310'>✨</tg-emoji>";
  var MSG_EMJ_HISTORY   = "<tg-emoji emoji-id='6113743082358841933'>🔰</tg-emoji>";
  var MSG_EMJ_LUDO      = "<tg-emoji emoji-id='5371043439020353782'>🎲</tg-emoji>"; // Ludo Spin Custom Emoji
  var MSG_EMJ_TUTORIAL  = "<tg-emoji emoji-id='5258077307985207053'>📹</tg-emoji>";
  var MSG_EMJ_PROOF     = "<tg-emoji emoji-id='5330237710655306682'>✅</tg-emoji>"; // Payment Proof Custom Emoji
  var MSG_EMJ_SUPPORT   = "<tg-emoji emoji-id='5436113877181941026'>🔰</tg-emoji>";

  // Naye aur Updated Emojis
  var EMJ_PREMIUM_MENU  = "<tg-emoji emoji-id='5406745015365943482'>✨</tg-emoji>";
  var EMJ_YOUR_BALANCE  = "<tg-emoji emoji-id='5231200819986047254'>💰</tg-emoji>";
  var EMJ_GET_STARTED   = "<tg-emoji emoji-id='6057415823222379852'>👇</tg-emoji>";

  // 📝 FULL WELCOME MESSAGE — synced with /start design (KEYxMASTER PANEL)
  var welcomeMessage =
    "<tg-emoji emoji-id=\"6266967801580231067\">💎</tg-emoji> <tg-emoji emoji-id=\"5866053971960929280\">🏪</tg-emoji> <b>— KEYxMASTER PANEL —</b> <tg-emoji emoji-id=\"5866053971960929280\">🏪</tg-emoji> <tg-emoji emoji-id=\"6266967801580231067\">💎</tg-emoji>\n\n" +
    "<tg-emoji emoji-id=\"6093677128295914531\">🎉</tg-emoji> <b>Hello, " + ((user && user.first_name) ? user.first_name.toUpperCase() : "RESELLER") + "!</b>\n\n" +
    "<tg-emoji emoji-id=\"6080228009439141516\">💧</tg-emoji> <b>Genuine, limited-stock books. Instant delivery.</b>\n\n" +
    "<tg-emoji emoji-id=\"6093591495237967001\">🌐</tg-emoji> Wide product catalog\n" +
    "<tg-emoji emoji-id=\"6215386799133433653\">🔑</tg-emoji> Instant delivery on payment\n" +
    "<tg-emoji emoji-id=\"6312263493051489212\">💰</tg-emoji> Multiple payment gateways\n" +
    "<tg-emoji emoji-id=\"6100170496077204999\">👑</tg-emoji> 24/7 admin support\n\n" +
    "<i>Balance: ₹" + userBal + "</i>\n\n" +
    "<i>Tap any button below to begin:</i> " + EMJ_GET_STARTED;

  // 🎨 KEYBOARD — same layout as /start
  var multiColorKeyboard = [
    [{ text: "Shop Now", callback_data: "/buy_hack", style: "primary", icon_custom_emoji_id: "5866053971960929280" }],
    [
      { text: "Profile", callback_data: "/profile", style: "primary", icon_custom_emoji_id: "5260399854500191689" },
      { text: "Add Balance", callback_data: "/addfund", style: "success", icon_custom_emoji_id: "6147815702163102310" }
    ],
    [
      { text: "My Keys", callback_data: "/mykey", style: "primary", icon_custom_emoji_id: "6113743082358841933" },
      { text: "How to use", callback_data: "/how", style: "danger", icon_custom_emoji_id: "6080214566191505147" }
    ],
    [
      { text: "Download Files", callback_data: "/download_updates", style: "primary", icon_custom_emoji_id: "5208790878931415568" },
      { text: "Daily Gift", callback_data: "/dailygift", style: "success", icon_custom_emoji_id: "6194922667242429131" }
    ],
    [
      { text: "Refer & Earn", callback_data: "/refer", style: "success", icon_custom_emoji_id: "5823654080584618403" },
      { text: "Support", callback_data: "/support", style: "danger", icon_custom_emoji_id: "5436113877181941026" }
    ],
    [{ text: "Payment Proofs", url: (Bot.getProperty("payment_proof_link") || "https://t.me/GaluModz_Proof"), style: "success", icon_custom_emoji_id: "5330237710655306682" }]
  ];

  // 👑 Conditional Reseller Upgrade button
  if (Bot.getProperty("reseller_system_enabled") && !Bot.getProperty("is_reseller_" + userId)) {
    multiColorKeyboard.push([
      { text: "Reseller Upgrade", callback_data: "/reseller_upgrade", style: "success", icon_custom_emoji_id: "6102856637343600044" }
    ]);
  }

  // 🔄 Safe Callback Loading Controller
  var queryId = null;
  if (request) {
    if (request.id) { queryId = request.id; }
    else if (request.callback_query && request.callback_query.id) { queryId = request.callback_query.id; }
  }

  if (queryId) {
    try { Api.answerCallbackQuery({ callback_query_id: queryId }); } catch(qErr){}
  }

  // ⚡ Native Execution Route (Send vs Edit Handler)
  // ✅ BUG FIX: agar previous message ek PHOTO thi (jaise DP-attached Profile),
  // Telegram editMessageText use hi nahi kar sakta uspar — isi wajah se Profile
  // se "Back" click karne par kuch hota hi nahi tha. Ab photo ho to delete karke
  // fresh text message bheja jaata hai.
  if (request && request.message && request.message.message_id) {
    if (request.message.photo) {
      try { Api.deleteMessage({ chat_id: chat.chatid, message_id: request.message.message_id }); } catch (delErr) {}
      Api.sendMessage({
        chat_id: chat.chatid,
        text: welcomeMessage,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: multiColorKeyboard })
      });
    } else {
      Api.editMessageText({
        chat_id: chat.chatid,
        message_id: request.message.message_id,
        text: welcomeMessage,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: multiColorKeyboard })
      });
    }
  } else {
    Api.sendMessage({
      chat_id: chat.chatid,
      text: welcomeMessage,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: multiColorKeyboard })
    });
  }

} catch (globalException) {
  Bot.sendMessage("🛑 <b>Dashboard Debug Error:</b> <code>" + globalException.message + "</code>", { parse_mode: "HTML" });
}