/**#command
name: /set_payment_upi_btn
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 💳 ADMIN PANEL BUTTON — "Set Payment UPI"
// Pressing this button prompts the admin to send the new UPI ID as a
// normal text message next; _start.js (MODULE 5) auto-captures that
// reply and forwards it to /set_payment_upi internally.
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var currentChatId = String(chat.chatid);
  var isCoAdmin = Bot.getProperty("co_admin_" + currentChatId);

  if (currentChatId !== adminId && !isCoAdmin) {
    Bot.sendMessage("❌ You are not authorized to use this.");
    return;
  }

  var currentUpi = Bot.getProperty("payment_upi_id") || "galureang@fam (default)";
  var currentApiKey = Bot.getProperty("payment_api_key");
  var currentApiKeyDisplay = currentApiKey ? (currentApiKey.substring(0, 10) + "••••••••") : "FAM_b47c7d••••• (default)";

  User.setProperty("set_payment_upi_step", "waiting_input", "string");

  var promptText =
    "<blockquote><tg-emoji emoji-id='6312263493051489212'>💳</tg-emoji> <b>Set Payment (Fam Pay) Config</b></blockquote>\n\n" +
    "<i>Is format me reply karein:</i>\n<code>upi_id|api_key</code>\n\n" +
    "<i>Example:</i> <code>yourid@fam|FAM_xxxxxxxxxxxxxxxx</code>\n\n" +
    "<i>Sirf UPI change karna ho to bhi pura format bhejein, api_key ko wahi purana daal dein. Agar sirf ek cheez bhejenge (bina | ke), sirf UPI ID update hogi.</i>\n\n" +
    "<b>Current UPI ID:</b> <code>" + currentUpi + "</code>\n" +
    "<b>Current API Key:</b> <code>" + currentApiKeyDisplay + "</code>";

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;

  if (request && request.message && request.message.message_id) {
    try {
      Api.editMessageText({
        chat_id: String(chat.chatid),
        message_id: Number(request.message.message_id),
        text: promptText,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "Cancel", callback_data: "/admin", style: "danger" }]] })
      });
    } catch (e) {
      Api.sendMessage({ chat_id: chat.chatid, text: promptText, parse_mode: "HTML" });
    }
  } else {
    Bot.sendMessage(promptText, { parse_mode: "HTML" });
  }

  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
