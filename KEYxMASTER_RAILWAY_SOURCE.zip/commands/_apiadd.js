/**#command
name: /apiadd
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var ownerId = String(Bot.getProperty("owner_id") || "7088682169");
  var uid = String(chat.chatid);
  var co = Bot.getProperty("co_admin_" + uid);
  if (uid !== ownerId && !co) return;

  var raw = params ? String(params).trim() : "";
  var p = raw.split("|").map(function(x){ return x.trim(); });
  if (p.length < 5) {
    Bot.sendMessage("❌ Format:\n<code>/apiadd ID | NAME | URL | API_KEY | MASTER_KEY | MODE | ANDROID_REQUIRED</code>\n\nMODE: reseller_v1 / custom\nANDROID_REQUIRED: true / false", {parse_mode:"HTML"});
    return;
  }
  var id=p[0], name=p[1], url=p[2], key=p[3], master=p[4];
  var mode=p[5] || "reseller_v1";
  var androidRequired=String(p[6]||"false").toLowerCase()==="true";

  var reg=Bot.getProperty("api_registry") || {};
  reg[id]={id:id,name:name,url:url,api_key:key,master_key:master,mode:mode,android_required:androidRequired,enabled:true,updated_at:new Date().toISOString()};
  Bot.setProperty("api_registry",reg,"json");
  if (!Bot.getProperty("active_reseller_api")) Bot.setProperty("active_reseller_api",id,"string");

  Bot.sendMessage("✅ <b>API Added</b>\n\nID: <code>"+id+"</code>\nName: <b>"+name+"</b>\nMode: <code>"+mode+"</code>\nAndroid ID: <code>"+(androidRequired?"Required":"Optional")+"</code>",{parse_mode:"HTML"});
} catch(e) { Bot.sendMessage("⚠️ API Add Error: "+e.message); }
