/**#command
name: /reseller_upgrade
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 👑 "Reseller Upgrade" button — premium Join-as-Reseller screen
// =========================================================

try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;

  if (Bot.getProperty("is_reseller_" + userId)) {
    Bot.sendMessage("<blockquote>💎 <b>Aap already ek Reseller hain!</b></blockquote>", { parse_mode: "HTML" });
    return;
  }

  if (!Bot.getProperty("reseller_system_enabled")) {
    Bot.sendMessage("❌ Reseller Upgrade system abhi available nahi hai.");
    return;
  }

  var price = Number(Bot.getProperty("reseller_upgrade_price") || 0);
  if (!price) {
    Bot.sendMessage("❌ Reseller Upgrade price admin ne abhi set nahi kiya.");
    return;
  }

  var unifiedBal = (function () {
    var resBal = 0;
    try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
    var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
    return resBal + bonusBal;
  })();

  var text =
    "<blockquote><tg-emoji emoji-id='6102856637343600044'>👑</tg-emoji> <b>JOIN AS A RESELLER</b></blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "<tg-emoji emoji-id='6312263493051489212'>💰</tg-emoji> <b>Upgrade Price:</b> ₹<code>" + price.toFixed(2) + "</code> <i>(one-time, permanent)</i>\n" +
    "<tg-emoji emoji-id='521095630692758910'>💳</tg-emoji> <b>Wallet Balance:</b> ₹<code>" + unifiedBal.toFixed(2) + "</code>\n\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n" +
    "<b>🎁 Reseller Benefits:</b>\n" +
    "<tg-emoji emoji-id='6215386799133433653'>✔️</tg-emoji> Lower prices on every product & plan\n" +
    "<tg-emoji emoji-id='6215386799133433653'>✔️</tg-emoji> Priority order processing\n" +
    "<tg-emoji emoji-id='6215386799133433653'>✔️</tg-emoji> Access to reseller-only stock\n" +
    "<tg-emoji emoji-id='6215386799133433653'>✔️</tg-emoji> Permanent status — ek baar upgrade, hamesha ke liye\n" +
    "━━━━━━━━━━━━━━━━━━━━━";

  var buttons = [];
  if (unifiedBal >= price) {
    buttons.push([{ text: "Confirm & Pay from Wallet", callback_data: "/confirm_reseller_upgrade", style: "success", icon_custom_emoji_id: "6102856637343600044" }]);
  } else {
    buttons.push([{ text: "Pay ₹" + (price - unifiedBal).toFixed(2) + " via UPI", callback_data: "/confirm_reseller_upgrade", style: "success", icon_custom_emoji_id: "521095630692758910" }]);
  }
  buttons.push([{ text: "Cancel", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }]);

  if (request && request.message) {
    Api.editMessageText({ chat_id: String(chatId), message_id: Number(request.message.message_id), text: text, parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: buttons }) });
  } else {
    Api.sendMessage({ chat_id: chatId, text: text, parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: buttons }) });
  }

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}