/**#command
name: /menu
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var userId = user.telegramid;

  // ✅ VERIFICATION CHECK
  var isVerified = (Bot.getProperty("verified_" + userId) === true) || (User.getProperty("verified_" + userId) === true);

  if (!isVerified) {
    Api.sendMessage({
      chat_id: chat.chatid,
      text: "<blockquote><b>🔰 Pehle account verify karein.</b>\nUse /start</blockquote>",
      parse_mode: "HTML"
    });
    return;
  }

  // 📊 REAL BALANCE FETCH — ✅ FIXED: ab same wallet store se read hoga jo purchase flows use karte hain
  // (Libs.ResourcesLib "balance" resource + admin bonus balance), taaki balance sab jagah same dikhe.
  var userBal = (function() {
    var resBal = 0;
    try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
    var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
    return (resBal + bonusBal).toFixed(2);
  })();

  var welcomeMessage =
    "<tg-emoji emoji-id=\"6266967801580231067\">💎</tg-emoji> <tg-emoji emoji-id=\"5866053971960929280\">🏪</tg-emoji> <b>— KEYxMASTER PANEL —</b> <tg-emoji emoji-id=\"5866053971960929280\">🏪</tg-emoji> <tg-emoji emoji-id=\"6266967801580231067\">💎</tg-emoji>\n\n" +
    "<tg-emoji emoji-id=\"6080228009439141516\">💧</tg-emoji> <b>Genuine, limited-stock books. Instant delivery.</b>\n\n" +
    "<tg-emoji emoji-id='5231200819986047254'>💰</tg-emoji> <b>Balance:</b> ₹" + userBal + "\n\n" +
    "<i>Tap any button below to begin:</i> <tg-emoji emoji-id='6057415823222379852'>👇</tg-emoji>";

  var multiColorKeyboard = [
    [{ text: "Shop Now", callback_data: "/buy_hack", style: "primary", icon_custom_emoji_id: "5866053971960929280" }],
    [
      { text: "Profile", callback_data: "/profile", style: "primary", icon_custom_emoji_id: "5260399854500191689" },
      { text: "Add Balance", callback_data: "/addfund", style: "success", icon_custom_emoji_id: "6147815702163102310" }
    ],
    [
      { text: "My Keys", callback_data: "/mykey", style: "primary", icon_custom_emoji_id: "6113743082358841933" },
      { text: "How to use", callback_data: "/how", style: "danger", icon_custom_emoji_id: "6080214566191505147" }
    ],
    [
      { text: "Download Files", callback_data: "/download_updates", style: "primary", icon_custom_emoji_id: "5208790878931415568" },
      { text: "Daily Gift", callback_data: "/dailygift", style: "success", icon_custom_emoji_id: "6194922667242429131" }
    ],
    [
      { text: "Refer & Earn", callback_data: "/refer", style: "success", icon_custom_emoji_id: "5823654080584618403" },
      { text: "Support", callback_data: "/support", style: "danger", icon_custom_emoji_id: "5436113877181941026" }
    ],
    [{ text: "Payment Proofs", url: (Bot.getProperty("payment_proof_link") || "https://t.me/GaluModz_Proof"), style: "success", icon_custom_emoji_id: "5330237710655306682" }]
  ];

  if (Bot.getProperty("reseller_system_enabled") && !Bot.getProperty("is_reseller_" + userId)) {
    multiColorKeyboard.push([
      { text: "Reseller Upgrade", callback_data: "/reseller_upgrade", style: "success", icon_custom_emoji_id: "6102856637343600044" }
    ]);
  }

  if (request && request.callback_query && request.callback_query.id) {
    try { Api.answerCallbackQuery({ callback_query_id: request.callback_query.id }); } catch(qErr){}
    Api.editMessageText({
      chat_id: chat.chatid,
      message_id: request.callback_query.message.message_id,
      text: welcomeMessage,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: multiColorKeyboard })
    });
  } else {
    Api.sendMessage({
      chat_id: chat.chatid,
      text: welcomeMessage,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: multiColorKeyboard })
    });
  }

} catch (globalException) {
  Bot.sendMessage("🛑 <b>Menu Debug Error:</b> <code>" + globalException.message + "</code>", { parse_mode: "HTML" });
}