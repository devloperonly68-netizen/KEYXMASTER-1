/**#command
name: /download_updates
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 📥 "Download Updates" button — premium update-channel section.
// Admin sets the redirect link via /set_update_link (see that file).
// =========================================================

try {
  var chatId = chat.chatid;
  var updateLink = Bot.getProperty("update_channel_link");

  var text =
    "<blockquote><tg-emoji emoji-id='6091571559233755994'>📥</tg-emoji> <b>DOWNLOAD FILES</b></blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "<tg-emoji emoji-id='6093677128295914531'>🎉</tg-emoji> <i>Stay up to date with the latest files, features, and stock alerts!</i>\n\n" +
    (updateLink
      ? "<tg-emoji emoji-id='6080214566191505147'>🔗</tg-emoji> <b>Tap the button below to open your files.</b>"
      : "<tg-emoji emoji-id='6093854128193152827'>⚠️</tg-emoji> <i>Download link abhi admin ne set nahi kiya hai.</i>") +
    "\n━━━━━━━━━━━━━━━━━━━━━";

  var buttons = [];
  if (updateLink) {
    buttons.push([{ text: "Open Download Files", url: updateLink, style: "success", icon_custom_emoji_id: "6091571559233755994" }]);
  }
  buttons.push([{ text: "Back to Menu", callback_data: "/back", style: "primary", icon_custom_emoji_id: "5893163582194978381" }]);

  if (request && request.message) {
    try {
      Api.editMessageText({
        chat_id: String(chatId),
        message_id: Number(request.message.message_id),
        text: text,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: buttons })
      });
    } catch (e) {
      Api.sendMessage({ chat_id: chatId, text: text, parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: buttons }) });
    }
  } else {
    Api.sendMessage({ chat_id: chatId, text: text, parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: buttons }) });
  }

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) {
    try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {}
  }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}