/**#command
name: /role
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  // Check karega ki command ke sath ID bheji hai ya nahi
  if (!params || params.trim() === "") {
    Bot.sendMessage("⚠️ <b>Please provide a user ID!</b>\nExample: <code>/roles 123456789</code>", { parse_mode: "HTML" });
    return; // Code yahi ruk jayega
  }

  var targetUserId = params.trim();
  var adminId = "7088682169";
  
  var name = "N/A";
  var username = "N/A";

  // Agar aap apni khud ki ID check kar rahe hain, toh name/username mil jayega
  if (String(targetUserId) === String(user.telegramid)) {
    name = user.first_name || "N/A";
    username = user.username ? "@" + user.username : "N/A";
  }
  
  // Role checking based on target ID
  var currentRole = "Normal User <tg-emoji emoji-id='6064514463564831610'>💟</tg-emoji>";
  
  if (String(targetUserId) === adminId) {
    currentRole = "Owner / Admin <tg-emoji emoji-id='6064138396228392033'>👑</tg-emoji>";
  } else if (Bot.getProperty("is_reseller_" + targetUserId)) {
    currentRole = "Reseller <tg-emoji emoji-id='5346024644635804737'>🔰</tg-emoji>";
  }

  var rolesText = "<blockquote><b><tg-emoji emoji-id='6039605143601680423'>📞</tg-emoji> USER ACCOUNT ROLE MATRIX</b>\n\n" +
                  "• <b>Name:</b> " + name + "\n" +
                  "• <b>Username:</b> " + username + "\n" +
                  "• <b>User ID:</b> <code>" + targetUserId + "</code>\n" +
                  "• <b>Role:</b> " + currentRole + "</blockquote>";

  Bot.sendMessage(rolesText, { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("Error: " + err.message);
}