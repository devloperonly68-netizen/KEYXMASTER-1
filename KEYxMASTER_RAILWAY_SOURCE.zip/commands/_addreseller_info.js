/**#command
name: /addreseller_info
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 👑 Admin panel button — shows usage instructions for /addreseller
// (a real Telegram command needs to be typed since it takes a User ID param)
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== ownerId && !isCoAdmin) { return; }

  Bot.sendMessage(
    "<blockquote>👑 <b>DIRECT RESELLER (No Payment)</b></blockquote>\n\n" +
    "<b>Usage:</b> <code>/addreseller USERID</code>\n" +
    "<i>Example:</i> <code>/addreseller 123456789</code>\n\n" +
    "<i>User turant permanent Reseller ban jaayega, koi payment nahi lagegi. Unhe ek premium notification bhi mil jaayega.</i>",
    { parse_mode: "HTML" }
  );
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}