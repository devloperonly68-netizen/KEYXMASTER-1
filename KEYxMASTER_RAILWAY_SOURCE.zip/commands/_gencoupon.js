/**#command
name: /gencoupon
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🎟 ADMIN — Coupon Generator Wizard (Step 1: kicks off in _start.js MODULE 3)
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin0 = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  User.setProperty("coupon_gen_step", "code", "string");

  Bot.sendMessage(
    "<blockquote>🎟 <b>COUPON GENERATOR</b></blockquote>\n\n" +
    "<tg-emoji emoji-id='6080214566191505147'>🏷</tg-emoji> <b>Coupon code kya rakhna hai?</b>\n" +
    "<i>Type karke bhejein, jaise: SAVE10</i>",
    { parse_mode: "HTML" }
  );

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}