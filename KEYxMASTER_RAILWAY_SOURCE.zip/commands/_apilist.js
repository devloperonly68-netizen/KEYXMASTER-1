/**#command
name: /apilist
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var ownerId=String(Bot.getProperty("owner_id")||"7088682169"), uid=String(chat.chatid), co=Bot.getProperty("co_admin_"+uid);
  if(uid!==ownerId && !co) return;
  var reg=Bot.getProperty("api_registry")||{}, active=Bot.getProperty("active_reseller_api")||"";
  var ids=Object.keys(reg);
  if(!ids.length){Bot.sendMessage("ℹ️ No API configured.");return;}
  var t="<b>🔌 API SYSTEM</b>\\n━━━━━━━━━━━━━━\\n";
  ids.forEach(function(id){
    var a=reg[id]||{};
    t+=(id===active?"🟢 ":"⚪ ")+ "<b>"+(a.name||id)+"</b>\\nID: <code>"+id+"</code>\\nMode: <code>"+(a.mode||"custom")+"</code>\\nAndroid ID: "+(a.android_required?"Required":"Optional")+"\\nEnabled: "+(a.enabled!==false?"Yes":"No")+"\\n\\n";
  });
  Bot.sendMessage(t,{parse_mode:"HTML"});
} catch(e){Bot.sendMessage("⚠️ API List Error: "+e.message);}
