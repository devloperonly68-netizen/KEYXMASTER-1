/**#command
name: /toggle_reseller_system
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 👑 ADMIN/CO-ADMIN — Enable/Disable Reseller Upgrade System
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "7088682169";
  var currentChatId = String(chat.chatid);
  var isCoAdmin = Bot.getProperty("co_admin_" + currentChatId);

  if (currentChatId !== ownerId && !isCoAdmin) {
    Bot.sendMessage("❌ Restricted command!");
    return;
  }

  var current = Bot.getProperty("reseller_system_enabled") || false;
  var newState = !current;
  Bot.setProperty("reseller_system_enabled", newState, "boolean");

  var price = Bot.getProperty("reseller_upgrade_price");

  if (newState) {
    Bot.sendMessage(
      "<blockquote>👑 <b>RESELLER SYSTEM ENABLED</b></blockquote>\n\n" +
      (price
        ? "<i>Users ko ab menu me 'Reseller Upgrade' button dikhega — Price: ₹" + price + "</i>"
        : "<tg-emoji emoji-id='6100657257605763582'>⚠️</tg-emoji> <i>Price abhi set nahi hai! Pehle <code>/set_reseller_price AMOUNT</code> use karein.</i>"),
      { parse_mode: "HTML" }
    );
  } else {
    Bot.sendMessage("<blockquote>❌ <b>RESELLER SYSTEM DISABLED</b></blockquote>\n\n<i>Reseller Upgrade button ab kisi ko nahi dikhega.</i>", { parse_mode: "HTML" });
  }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}