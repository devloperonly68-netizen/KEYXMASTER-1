/**#command
name: /addbal_binance_paid
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// ✅ "I Paid" (Binance) — asks user directly for the payment screenshot.
// _start.js MODULE 4c catches the photo reply, forwards it to admin,
// and tells the user to wait for admin verification.
// =========================================================

try {
  let userId = user.telegramid;
  let callbackId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;

  let inrAmount = User.getProperty("binance_pending_amount_inr");
  let usdAmount = User.getProperty("binance_pending_amount_usd");

  if (!inrAmount) {
    if (callbackId) {
      Api.answerCallbackQuery({
        callback_query_id: String(callbackId),
        text: "⚠️ Order expired. Please start again from Add Balance.",
        show_alert: true
      });
    }
    return;
  }

  User.setProperty("binance_utr_step", "awaiting_screenshot", "string");

  let promptText =
    "<blockquote><tg-emoji emoji-id='6100170496077204999'>📝</tg-emoji> <b>SUBMIT PAYMENT SCREENSHOT</b></blockquote>\n\n" +
    "<tg-emoji emoji-id='6312263493051489212'>💰</tg-emoji> <b>Amount:</b> $<code>" + usdAmount + "</code> <i>(₹" + inrAmount + ")</i>\n\n" +
    "<i>Please send your <b>Payment Screenshot</b> now (as a photo):</i>";

  if (request && request.message && request.message.message_id) {
    try {
      Api.editMessageCaption({
        chat_id: chat.chatid,
        message_id: request.message.message_id,
        caption: promptText,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "Cancel", callback_data: "/cancel_topup", style: "danger" }]] })
      });
    } catch (e) {
      Api.sendMessage({ chat_id: chat.chatid, text: promptText, parse_mode: "HTML" });
    }
  } else {
    Bot.sendMessage(promptText, { parse_mode: "HTML" });
  }

  if (callbackId) {
    Api.answerCallbackQuery({ callback_query_id: String(callbackId) });
  }

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}
