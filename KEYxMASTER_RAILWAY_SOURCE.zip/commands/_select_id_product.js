/**#command
name: /select_id_product
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  // 🔥 CALLBACK DATA CLEARING & PARAM EXTRACTION PIPELINE
  var rawParams = "";
  if (typeof params !== "undefined" && params) {
    rawParams = String(params).trim();
  }

  // Fallback check agar dynamic params system bypass ho gaya ho
  if (!rawParams && typeof request !== "undefined" && request) {
    var callbackQuery = request.callback_query || request;
    if (callbackQuery && callbackQuery.data) {
      var dataStr = String(callbackQuery.data).trim();
      var parts = dataStr.split(" ");
      if (parts.length > 1) {
        rawParams = parts.slice(1).join(" ").trim();
      } else {
        rawParams = dataStr;
      }
    }
    
    // Clear loading spinner instantly
    let queryId = request.id || (request.callback_query && request.callback_query.id);
    if (queryId) {
      try { Api.answerCallbackQuery({ callback_query_id: queryId }); } catch (qErr){}
    }
  }

  // Safe Chat ID fallback
  var targetChatId = (chat && chat.chatid) ? chat.chatid : ((chat && chat.id) ? chat.id : (user ? user.telegramid : null));

  if (!targetChatId) return; // Silent guard if no context exists

  // 🛡️ SECURITY & EMPTY PARAM CHECK FIX
  if (!rawParams || rawParams.indexOf("/") === 0) { 
    Api.sendMessage({
      chat_id: targetChatId,
      text: "<tg-emoji emoji-id='5244837092042750681'>⚠️</tg-emoji> <b>Session Expired or Invalid Selection.</b>\n\nKripya main menu se phir se product select karein.",
      parse_mode: "HTML"
    });
    return;
  }

  var categories = Bot.getProperty("ff_categories") || {};

  if (!categories[rawParams]) {
    Api.sendMessage({
      chat_id: targetChatId,
      text: "❌ <b>Product nahi mila ya remove ho chuka hai!</b>\nSelected Slug: <code>" + rawParams + "</code>",
      parse_mode: "HTML"
    });
    return;
  }

  var item = categories[rawParams];
  var stockList = Bot.getProperty("ff_stock_" + rawParams) || [];

  if (!Array.isArray(stockList)) stockList = [];

  // Safe user role derivation
  var userId = (user && user.telegramid) ? user.telegramid : targetChatId;
  var isReseller = Bot.getProperty("is_reseller_" + userId);
  var hasResellerAccess = (isReseller === true || String(isReseller).toLowerCase() === "true");

  var price = hasResellerAccess
    ? (item.reseller_price !== undefined && item.reseller_price !== null ? item.reseller_price : (item.normal_price || 0))
    : (item.normal_price || 0);

  // 💎 MULTIPLE PREMIUM EMOJIS INTEGRATION & BOLD LAYOUT (NEW EMOJIS MIXED)
  var text =
    "┏━━━━━━━━━━━━━━━━━━━━━━━━┓\n" +
    "┃ <tg-emoji emoji-id='6267140231632262769'>❤️‍🔥</tg-emoji> <b>ALL DETAILS</b> <tg-emoji emoji-id='6267140231632262769'>❤️‍🔥</tg-emoji> ┃\n" +
    "┗━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
    "<tg-emoji emoji-id='5244837092042750681'>✨</tg-emoji> <b>PRODUCT DETAILS:</b>\n\n" +
    "<tg-emoji emoji-id='6267129592998270736'>📣</tg-emoji> <b>Product Name :</b> <code>" + item.name + "</code>\n\n" +
    "<tg-emoji emoji-id='6062310436672377598'>🪐</tg-emoji> <b>Current Stocks :</b> <code>" + stockList.length + " accounts</code>\n\n" +
    "<tg-emoji emoji-id='6266995104687330978'>📈</tg-emoji> <b>Price:</b> <code>₹" + price + "</code>\n\n" +
    "<tg-emoji emoji-id='4967656361073574498'>👑</tg-emoji> <b>Account Type :</b> <b>" + (hasResellerAccess ? "Reseller" : "User") + "</b>\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "<tg-emoji emoji-id='6057728771719435723'>⚡</tg-emoji> <i>Kripya confirmation ke liye niche diye gaye button par click karein.</i>";

  // Dynamic Button Configuration
  var purchaseButtonText = "Confirm Purchase";
  var purchaseButtonStyle = "success"; 
  var purchaseEmojiId = "6062310436672377598"; 

  if (stockList.length === 0) {
    purchaseButtonText = "❌ Out of Stock";
    purchaseButtonStyle = "danger"; 
    purchaseEmojiId = "5197288647275071607"; 
  }

  var buttons = {
    inline_keyboard: [
      [
        {
          text: purchaseButtonText,
          callback_data: stockList.length > 0 ? "/execute_id_buy " + rawParams : "/ff_id_menu",
          style: purchaseButtonStyle,
          icon_custom_emoji_id: purchaseEmojiId
        }
      ],
      [
        {
          text: "Back to Menu",
          callback_data: "/ff_id_menu",
          style: "danger",
          icon_custom_emoji_id: "5893163582194978381"
        }
      ]
    ]
  };

  var targetMessageId = (typeof request !== "undefined" && request && request.message) ? request.message.message_id : null;

  // Render logic handling
  if (targetMessageId) {
    try {
      Api.editMessageText({
        chat_id: targetChatId,
        message_id: targetMessageId,
        text: text,
        parse_mode: "HTML",
        reply_markup: JSON.stringify(buttons)
      });
    } catch (err) {
      Api.sendMessage({
        chat_id: targetChatId,
        text: text,
        parse_mode: "HTML",
        reply_markup: JSON.stringify(buttons)
      });
    }
  } else {
    Api.sendMessage({
      chat_id: targetChatId,
      text: text,
      parse_mode: "HTML",
      reply_markup: JSON.stringify(buttons)
    });
  }

} catch (e) {
  var errorChatId = (chat && chat.chatid) ? chat.chatid : ((user && user.telegramid) ? user.telegramid : "7088682169");
  try {
    Api.sendMessage({
      chat_id: errorChatId,
      text: "❌ <b>Checkout Error:</b>\n<code>" + e.message + "</code>",
      parse_mode: "HTML"
    });
  } catch(fatal){}
}