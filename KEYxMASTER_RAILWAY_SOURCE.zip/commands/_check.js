/**#command
name: /check
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🚀 MANUAL PAYMENT VERIFY TRIGGER COMMAND
// COMMAND: /check
// =========================================================

try {
  var order_id = params ? params.trim() : "";

  // Agar params direct na mile toh callback_query data se extract karein
  if (!order_id && request && request.callback_query) {
    var cbData = request.callback_query.data;
    order_id = cbData.replace("/check", "").replace("check", "").trim().split(" ")[0];
  }

  if (!order_id) {
    var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
    if (queryId) {
      Api.answerCallbackQuery({
        callback_query_id: queryId,
        text: "❌ Invalid or Missing Order ID!",
        show_alert: true
      });
    } else {
      Bot.sendMessage(
        "<blockquote><tg-emoji emoji-id='5875506366050734240'>➡️</tg-emoji> <b>Invalid or Missing Order ID!</b> Please try initiating the payment again.</blockquote>", 
        { parse_mode: "HTML" }
      );
    }
    return;
  }

  // ✅ BUG FIX: /onQR.js "Api.sendPhoto()" ka return value is bot-framework me
  // reliably message_id nahi deta, isliye "qr_msg_id_" property kabhi save hi
  // nahi hoti thi — aur baad me /onCheck.js ka "vanishQrMessage()" us khaali
  // property ki wajah se QR photo dhoondh hi nahi paata tha, isliye verify hone
  // ke baad bhi QR chat me pada reh jaata tha.
  // Fix: jab "Verify Payment" button dabaya jaata hai, wo button hamesha usi QR
  // photo message par hota hai jispar hai — matlab "request.message.message_id"
  // 100% sahi QR message ki ID hai. Ise yahin par (guaranteed) capture karke
  // save kar rahe hain taaki /onCheck.js use turant delete kar sake.
  try {
    var verifyUserId = user ? user.telegramid : null;
    if (verifyUserId && request && request.message && request.message.message_id) {
      Bot.setProperty("qr_msg_id_" + verifyUserId, request.message.message_id, "string");
      User.setProperty("qr_msg_id_" + verifyUserId, request.message.message_id, "string");
    }
  } catch (idErr) {}

  // Gateway API Details
  var api_key = Bot.getProperty("payment_api_key") || process.env.PAYMENT_API_KEY || "";
  var uniqueTime = new Date().getTime(); // Anti-cache parameter

  HTTP.get({
    url: "https://fampay.anujbots.xyz/verify.php?order_id=" + encodeURIComponent(order_id) + "&api_key=" + api_key + "&cb=" + uniqueTime,
    success: "/onCheck"
  });

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}