/**#command
name: /custom_stars_amount
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// ⭐ "Custom Amount" button — asks user to type a Stars amount
// (reply handled in _start.js MODULE 5)
// =========================================================

try {
  User.setProperty("awaiting_stars_amount", true, "boolean");

  var text = "<blockquote>⭐ <b>ENTER STARS AMOUNT</b></blockquote>\n\n<i>Kitne Stars deposit karne hain? Number type karke bhejein (e.g. 150)</i>";

  if (request && request.message && !request.message.photo) {
    Api.editMessageText({ chat_id: String(chat.chatid), message_id: Number(request.message.message_id), text: text, parse_mode: "HTML" });
  } else {
    Api.sendMessage({ chat_id: chat.chatid, text: text, parse_mode: "HTML" });
  }

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}