/**#command
name: /remcat_id
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169";
  if (!chat || String(chat.chatid) !== adminId) return;

  // 🛡️ CRASH FIX: Pehle check karenge ki message null toh nahi hai
  if (!message) {
    Bot.sendMessage("✍️ <b>Kripya Category ka naam text me likh kar bhejiye!</b>\n\n<b>Sahi Format:</b>\n<code>/remcat_id [Category Name]</code>\n\n<b>Example:</b>\n<code>/remcat_id Facebook Id</code>", {parse_mode: "HTML"});
    return;
  }

  var cleanMessage = message.trim();

  // Agar message me command text shuru me hai toh use clean karein
  if (cleanMessage.indexOf("/remcat_id") === 0) {
    cleanMessage = cleanMessage.replace("/remcat_id", "").trim();
  }

  if (!cleanMessage) {
    Bot.sendMessage("⚠️ <b>Format Galat Hai!</b>\n\n<b>Sahi Format:</b>\n<code>/remcat_id [Category Name]</code>\n\n<b>Example:</b>\n<code>/remcat_id Facebook Id</code>", {parse_mode: "HTML"});
    return;
  }

  // FIXED: Sahi slug creation algorithm jo addcat_id script ke bilkul same hai
  var catSlug = cleanMessage.toLowerCase().replace(/[^a-z0-9]/g, "");
  
  var categories = Bot.getProperty("ff_categories") || {};

  if (!categories[catSlug]) {
    Bot.sendMessage("❌ <b>Category nahi mili!</b>\n\nEk baar naam sahi se check karein ya menu me jaakar dekhein.", {parse_mode: "HTML"});
    return;
  }

  var oldName = categories[catSlug].name;
  
  // Category array/object se remove karein
  delete categories[catSlug];
  Bot.setProperty("ff_categories", categories, "json");
  
  // Associated stock database se completely wipe out karein
  Bot.setProperty("ff_stock_" + catSlug, null);

  Bot.sendMessage("🗑️ <b>Category Successfully Deleted!</b>\n\n• <b>Name:</b> <code>" + oldName + "</code>\n• <b>System Slug Wiped:</b> <code>" + catSlug + "</code>\n\n<i>Yeh category aur iska saara stock ab database se hat chuka hai.</i>", {parse_mode: "HTML"});

} catch(e) {
  Bot.sendMessage("Error in Remove Category: " + e.message);
}