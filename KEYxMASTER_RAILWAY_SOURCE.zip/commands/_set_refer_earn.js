/**#command
name: /set_refer_earn
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🔧 ADMIN — Configure the Refer & Earn bonus amounts
// Usage: /set_refer_earn 2|2   (topup_bonus|buy_bonus)
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin0 = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  if (!params || params.trim() === "" || params.indexOf("|") === -1) {
    var topupAmt = Bot.getProperty("refer_earn_topup_amount");
    if (topupAmt === undefined || topupAmt === null) topupAmt = "2 (default)";
    var buyAmt = Bot.getProperty("refer_earn_buy_amount");
    if (buyAmt === undefined || buyAmt === null) buyAmt = "2 (default)";
    Bot.sendMessage(
      "⚠️ <b>Format:</b> <code>/set_refer_earn 2|2</code> (topup_bonus|buy_bonus)\n\n" +
      "<b>Current:</b> Topup ₹" + topupAmt + " | Buy ₹" + buyAmt,
      { parse_mode: "HTML" }
    );
    return;
  }

  var parts = params.trim().split("|");
  var newTopup = Number(parts[0]);
  var newBuy = Number(parts[1]);

  if (isNaN(newTopup) || newTopup < 0 || isNaN(newBuy) || newBuy < 0) {
    Bot.sendMessage("❌ Invalid amount! Format: <code>2|2</code>", { parse_mode: "HTML" });
    return;
  }

  Bot.setProperty("refer_earn_topup_amount", newTopup, "number");
  Bot.setProperty("refer_earn_buy_amount", newBuy, "number");

  Bot.sendMessage(
    "✅ <b>Refer & Earn amounts update ho gaye:</b>\n" +
    "• Balance-Add Bonus: ₹" + newTopup.toFixed(2) + "\n" +
    "• Purchase Bonus: ₹" + newBuy.toFixed(2),
    { parse_mode: "HTML" }
  );

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
