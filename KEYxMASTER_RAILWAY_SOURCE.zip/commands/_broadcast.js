/**#command
name: /broadcast
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin0 = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) {
    Bot.sendMessage("❌ Restricted command!");
    return;
  }

  // Admin ki state active karna
  User.setProperty("awaiting_broadcast_data", true, "boolean");
  Bot.sendMessage("📢 <b>BROADCAST SYSTEM ACTIVATED</b>\n\nAb aap jo bhi message (Text, Photo, Video, Voice, Animation) bhejenge, wo sabhi users ko chala jayega.\n\n<i>Kripya apna message ab send karein...</i>", { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("Error: " + err.message);
}