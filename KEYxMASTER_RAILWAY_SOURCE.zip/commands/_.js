/**#command
name: *
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🛡️ WILDCARD FALLBACK — catches any message/input that doesn't match
// a specific registered command.
// ✅ BUG FIX: pehle ye ek 241-line ka STALE duplicate copy tha (purani
// admin checks, plain crown emoji, koi bhi naya fix — maintenance mode,
// coupon wizard, case-insensitive /start — yahan nahi tha). Kyunki ye
// wildcard command hai, koi bhi unmatched input isi purane/buggy logic
// se guzarta tha. Ab ye seedha /start ko delegate karta hai (jahan sab
// latest fixes maujood hain) — koi duplicate/stale logic nahi bacha.
// =========================================================

try {
  Bot.run({ command: "/start" });
} catch (err) {
  try { Bot.sendMessage("⚠️ Kripya /start type karein.", { parse_mode: "HTML" }); } catch (e) {}
}