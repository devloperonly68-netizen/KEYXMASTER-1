/**#command
name: /onProfilePhoto
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 👤 COMMAND = /onProfilePhoto (Premium Profile — Step 2: final render)
// ✅ BUG FIX: reply_markup pehle raw object bhej raha tha (JSON.stringify nahi
// kiya gaya tha) jab DP available thi — isi wajah se "Back to Menu" button
// kaam nahi kar raha tha / render hi nahi ho raha tha jab DP ke saath bheja jaata.
// =========================================================

try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;
  var adminId = "7088682169";

  // 📸 DP file_id nikaalo (agar user ki koi profile photo public hai)
  var dpFileId = null;
  try {
    var res = (typeof content === "object" && content) ? content : JSON.parse(content);
    if (res && res.ok && res.result && res.result.total_count > 0) {
      var sizes = res.result.photos[0];
      dpFileId = sizes[sizes.length - 1].file_id;
    }
  } catch (e) {}

  // 💎 Premium Emoji Set
  var e_profile = "<tg-emoji emoji-id='6102818532393750087'>👤</tg-emoji>";
  var e_id       = "<tg-emoji emoji-id='5902002809573740949'>🆔</tg-emoji>";
  var e_money    = "<tg-emoji emoji-id='6312263493051489212'>💰</tg-emoji>";
  var e_crown    = "<tg-emoji emoji-id='6102856637343600044'>👑</tg-emoji>";
  var e_calendar = "<tg-emoji emoji-id='6266866272848321043'>📅</tg-emoji>";
  var e_key      = "<tg-emoji emoji-id='6284816251143331422'>🔑</tg-emoji>";
  var e_invest   = "<tg-emoji emoji-id='5330237710655306682'>📊</tg-emoji>";
  var e_back     = "<tg-emoji emoji-id='5893163582194978381'>⬅️</tg-emoji>";

  var userBalance = (function () {
    var resBal = 0;
    try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
    var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
    return (resBal + bonusBal).toFixed(2);
  })();

  var username = user.username ? "@" + user.username : "Not Set";
  var fullName = (user.first_name || "") + (user.last_name ? " " + user.last_name : "");

  var role, roleEmojiHtml;
  if (userId === adminId) {
    role = "Admin"; roleEmojiHtml = e_crown;
  } else if (Bot.getProperty("co_admin_" + userId)) {
    role = "Co-Admin"; roleEmojiHtml = e_crown;
  } else {
    var isReseller = Bot.getProperty("is_reseller_" + userId);
    var hasReseller = (isReseller === true || String(isReseller).toLowerCase() === "true");
    role = hasReseller ? "Reseller 🔰" : "Regular User";
    roleEmojiHtml = hasReseller ? "<tg-emoji emoji-id='5346024644635804737'>🔰</tg-emoji>" : "🙋";
  }

  var joinedDate = Bot.getProperty("joined_date_" + userId) || "N/A";
  var purchasedKeys = User.getProperty("my_purchased_keys") || [];
  var totalKeys = Array.isArray(purchasedKeys) ? purchasedKeys.length : 0;
  var totalInvested = Number(Bot.getProperty("total_spent_by_" + userId) || 0).toFixed(2);

  // 🎨 Premium profile layout (matches the reference design)
  var caption =
    "<blockquote>" + e_profile + " <b>USER PROFILE</b> " + e_profile + "</blockquote>\n\n" +
    e_id + " <b>ID:</b> <code>" + userId + "</code>\n" +
    "<b>Name:</b> " + fullName + "\n" +
    "<b>Username:</b> " + username + "\n" +
    e_calendar + " <b>Joined:</b> " + joinedDate + "\n" +
    roleEmojiHtml + " <b>Account Type:</b> " + role + "\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    e_money + " <b>Balance:</b> ₹" + userBalance + "\n" +
    e_invest + " <b>Spent:</b> ₹" + totalInvested + "\n" +
    e_key + " <b>Keys:</b> " + totalKeys + "\n\n" +
    "<i>" + (dpFileId ? "Profile photo fetched from Telegram." : "No profile photo set.") + "</i>";

  var keyboard = [
    [
      { text: "My Keys", callback_data: "/mykey", style: "primary", icon_custom_emoji_id: "6284816251143331422" },
      { text: "Add Fund", callback_data: "/addfund", style: "success", icon_custom_emoji_id: "6312263493051489212" }
    ],
    [
      { text: "Back", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
    ]
  ];

  if (dpFileId) {
    Api.sendPhoto({
      chat_id: chatId,
      photo: dpFileId,
      caption: caption,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: keyboard })
    });
  } else {
    Api.sendMessage({
      chat_id: chatId,
      text: caption,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: keyboard })
    });
  }

} catch (err) {
  Bot.sendMessage("⚠️ Profile Error: " + err.message, { parse_mode: "HTML" });
}