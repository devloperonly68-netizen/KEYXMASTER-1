/**#command
name: /onPressQR
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  if (!content) {
    Bot.sendMessage("⚠️ <b>Gateway Error:</b> No response from server. Try again.", { parse_mode: "HTML" });
    return;
  }

  var res = (typeof content === "object") ? content : JSON.parse(content);

  if (res.status === "success" && res.data) {
    var orderId = res.data.order_id;
    var qrUrl = res.data.qr_url;
    var qrAmount = res.data.amount;
    var expireTime = res.data.expires_at_ist;

    User.setProperty("pending_order_id", orderId, "string");

    var caption = "🦆 <tg-emoji emoji-id='5893431652578758294'>💰</tg-emoji> <b>PAYMENT GATEWAY</b>\n" +
                  "━━━━━━━━━━━━━━━━━━━━━━\n" +
                  "🌈 <b>Amount: ₹" + qrAmount + "</b>\n" +
                  "📲 <i>Scan QR & Complete Payment</i>\n" +
                  "⏳ <b>Expire Time:</b> " + expireTime + "\n\n" +
                  "✅ <i>After Payment Click Verify Payment Button</i>\n" +
                  "━━━━━━━━━━━━━━━━━━━━━━\n" +
                  "🌐 <tg-emoji emoji-id='6192553546102085729'>🤖</tg-emoji> <i>Auto Verification System Powered</i>";

    Api.sendPhoto({
      photo: qrUrl,
      caption: caption,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({
        inline_keyboard: [
          [
            { text: "Verify Payment", callback_data: "/check" }
          ],
          [
            { text: "Cancel / Back", callback_data: "/cancel_order" }
          ]
        ]
      })
    });

  } else {
    Bot.sendMessage("⚠️ <b>Failed to generate QR:</b> " + (res.message || "Unknown error"), { parse_mode: "HTML" });
  }

} catch (err) {
  Bot.sendMessage("⚠️ <b>Exception:</b> " + err.message, { parse_mode: "HTML" });
}