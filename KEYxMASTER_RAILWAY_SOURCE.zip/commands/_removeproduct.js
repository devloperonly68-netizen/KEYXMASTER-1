/**#command
name: /removeproduct
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169"; // Aapki Admin ID
  if (String(chat.chatid) !== adminId) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  // Database se existing products fetch karna
  var productList = Bot.getProperty("stored_products") || [];

  if (productList.length === 0) {
    Bot.sendMessage("❌ <b>Database me koi product nahi mila!</b> Remove karne ke liye pehle product add karein.", { parse_mode: "HTML" });
    return;
  }

  var inlineButtons = [];

  // Saare products ke dynamic buttons loop se banana
  for (var i = 0; i < productList.length; i++) {
    var product = productList[i];
    if (!product || !product.name) continue;

    inlineButtons.push([
      {
        text: "🗑️ Remove: " + product.name.toUpperCase(),
        // Callback data me array index number pass karna
        callback_data: "/confirm_rem_prod " + i
      }
    ]);
  }

  var menuText = "<blockquote><b>🗑️ CHOOSE PRODUCT TO REMOVE</b>\n\n" +
                 "• <b>Total Registered:</b> <code>" + productList.length + " Products</code>\n\n" +
                 "<i>Niche diye gaye buttons me se jis product ko poori tarah delete karna hai, uspar click karein:</i></blockquote>";

  Bot.sendMessage(menuText, {
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: inlineButtons })
  });

} catch (err) {
  Bot.sendMessage("⚠️ Remove Product Menu Error: " + err.message);
}