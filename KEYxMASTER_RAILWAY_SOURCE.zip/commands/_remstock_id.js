/**#command
name: /remstock_id
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169";
  if (String(chat.chatid) !== adminId) return;

  var categories = Bot.getProperty("ff_categories") || {};
  var keyboard = [];
  var row = [];
  var count = 0;

  for (var slug in categories) {
    var catName = categories[slug].name || slug.toUpperCase();
    
    // Har row me 2 buttons dikhane ke liye
    row.push({ 
      text: "📁 " + catName, 
      callback_data: "/view_rem_stock " + slug 
    });
    
    count++;
    if (count % 2 === 0) {
      keyboard.push(row);
      row = [];
    }
  }
  if (row.length > 0) keyboard.push(row);

  if (keyboard.length === 0) {
    Bot.sendMessage("❌ System me abhi koi category nahi bani hai.");
    return;
  }

  Api.sendMessage({
    chat_id: adminId,
    text: "📂 <b>Select a Category to view stock for deletion:</b>",
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: keyboard })
  });

} catch (e) {
  Bot.sendMessage("Error: " + e.message);
}