/**#command
name: /execute_id_buy
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🛒 COMMAND = /execute_id_buy
// STATUS: FIXED - Real QR HTTP call + FF ID flow tracking for delivery after QR pay
// =========================================================

try {
  if (!params || typeof params !== "string") return;

  let data = params.split(" ");
  let rawType = data[0] ? data[0].toLowerCase().trim() : "";
  let actionState = data[1] ? data[1].toLowerCase().trim() : "";

  // Safe Callback Query ID & Context Extraction
  let queryId = request.id || (request.callback_query && request.callback_query.id);
  let userId = user.telegramid.toString().trim(); 
  let chatID = chat.chatid;

  // ===================================================
  // 👑 DYNAMIC PRICING SYSTEM & CATEGORY RESOLVER
  // ===================================================
  let rawResellers = Bot.getProperty("resellers_list");
  let resellers = [];

  if (rawResellers) {
      if (Array.isArray(rawResellers)) {
          resellers = rawResellers;
      } else if (typeof rawResellers === "string") {
          try { resellers = JSON.parse(rawResellers); } catch(e) { resellers = rawResellers.split(","); }
      } else if (typeof rawResellers === "object") {
          resellers = rawResellers.resellers || rawResellers.list || rawResellers.users || Object.values(rawResellers);
      }
  }
  if (!Array.isArray(resellers)) { resellers = []; }

  // Check if User is Reseller OR Admin
  let isReseller = resellers.map(function(id) {
      return id ? id.toString().toLowerCase().trim() : "";
  }).includes(userId) || (userId === "7088682169");
  
  let finalCost = 0;
  let stockData = [];
  let displayTypeName = "";
  let isDynamicCategory = false;
  let isGeneralCategory = false;
  let selectedCat = null;
  
  // ✅ FIX: BJS getProperty doesn't reliably take a default 2nd arg — use || [] pattern everywhere
  let fbCategories = Bot.getProperty("fb_categories") || [];
  if (!Array.isArray(fbCategories)) { fbCategories = []; }

  if (rawType.startsWith("fb_")) {
      isDynamicCategory = true;
      let targetCatId = rawType.replace("fb_", "").trim();
      
      for (let i = 0; i < fbCategories.length; i++) {
          if (fbCategories[i].id === targetCatId) {
              selectedCat = fbCategories[i];
              break;
          }
      }
      
      if (!selectedCat) {
          if (queryId) Api.answerCallbackQuery({ callback_query_id: String(queryId), text: "❌ Category deleted!", show_alert: true });
          return;
      }
      
      if (isReseller && selectedCat.reseller_price !== undefined && selectedCat.reseller_price !== "") {
          finalCost = Number(selectedCat.reseller_price);
      } else {
          finalCost = Number(selectedCat.price || 0);
      }
      stockData = selectedCat.stock_list || [];
      displayTypeName = selectedCat.name;
  } else if (rawType == "fb" || rawType == "google") {
      let priceRes = parseFloat(Bot.getProperty("price_res_" + rawType) || 0);
      let priceNorm = parseFloat(Bot.getProperty("price_norm_" + rawType) || 0);
      finalCost = isReseller ? priceRes : priceNorm;
      stockData = Bot.getProperty("ff_stock_" + rawType) || [];
      displayTypeName = rawType.toUpperCase();
  } else {
      var categories = Bot.getProperty("ff_categories") || {};
      if (!categories[rawType]) {
          if (queryId) Api.answerCallbackQuery({ callback_query_id: String(queryId), text: "❌ Invalid Product!", show_alert: true });
          return;
      }
      isGeneralCategory = true;
      selectedCat = categories[rawType];
      
      if (isReseller) {
          if (selectedCat.reseller_price !== undefined && selectedCat.reseller_price !== "" && selectedCat.reseller_price !== null && Number(selectedCat.reseller_price) > 0) {
              finalCost = Number(selectedCat.reseller_price);
          } else if (selectedCat.price !== undefined && selectedCat.price !== "" && selectedCat.price !== null) {
              finalCost = Number(selectedCat.price); 
          } else {
              finalCost = Number(selectedCat.normal_price || 0);
          }
      } else {
          finalCost = Number(selectedCat.normal_price || selectedCat.price || 0);
      }
      
      let fallbackStock = Bot.getProperty("ff_stock_" + rawType) || [];
      stockData = (selectedCat.stock_list && selectedCat.stock_list.length > 0) ? selectedCat.stock_list : fallbackStock;
      displayTypeName = selectedCat.name;
  }

  // Out of stock hard block check
  if (!stockData || stockData.length === 0) {
      if (queryId) {
          Api.answerCallbackQuery({
              callback_query_id: String(queryId),
              text: "❌ Stock is empty! Cannot process purchase.",
              show_alert: true
          });
      } else {
          Api.sendMessage({ chat_id: chatID, text: "❌ Out of stock items cannot be processed." });
      }
      return;
  }

  // Wallet engine balance extraction sequence
  var userRes = Libs.ResourcesLib.userRes("balance");
  var bonusBal = Bot.getProperty("balance" + userId) || 0;
  var unifiedTotalBalance = Number(userRes.value()) + Number(bonusBal);

  // 🚨 INSUFFICIENT BALANCE SYSTEM -> REDIRECT TO QR WITH SHORTAGE AMOUNT
  if (unifiedTotalBalance < finalCost) {
      var needToPay = finalCost - unifiedTotalBalance;
      
      // Save details for QR generation pipeline
      User.setProperty("buy_price", finalCost, "number");
      User.setProperty("buy_needpay", needToPay, "number");
      User.setProperty("buy_prod_name", displayTypeName, "string");

      // ✅ FIX: Tag this purchase as an FF-ID stock-based flow so /onBuyCheck
      // knows to deliver from local stock instead of the plan-based external API
      User.setProperty("buy_flow_type", "ffid", "string");
      User.setProperty("buy_ffid_rawtype", rawType, "string");
      User.setProperty("buy_ffid_is_reseller", isReseller ? true : false, "boolean");

      if (queryId) {
          Api.answerCallbackQuery({ 
              callback_query_id: String(queryId), 
              text: "⚠️ Balance low! Generating QR for ₹" + needToPay + "...", 
              show_alert: true 
          });
      }

      // ✅ FIX: Actually call the payment server for a QR instead of directly
      // triggering /onBuyQR (which needs a real HTTP response in `content`)
      var targetUrl = "https://fampay.anujbots.xyz/qr.php?upi=" + encodeURIComponent(Bot.getProperty("payment_upi_id") || "galureang@fam") + "&amount=" + encodeURIComponent(needToPay);

      Api.sendMessage({
          chat_id: chatID,
          text: "<b>📉 Requesting QR from server...\n<code>" + targetUrl + "</code></b>",
          parse_mode: "HTML"
      });

      HTTP.get({
          url: targetUrl,
          success: "/onBuyQR",
          error: "/onBuyQR"
      });
      return;
  }

  // Deduct balanced values systematically
  if (bonusBal >= finalCost) {
      Bot.setProperty("balance" + userId, bonusBal - finalCost, "number");
  } else {
      var remainingDeduction = finalCost - bonusBal;
      Bot.setProperty("balance" + userId, 0, "number");
      userRes.remove(remainingDeduction);
  }

  // Shift asset entry from inventory safely
  var accountExtracted = stockData.shift();
  
  // Stock data save back logic
  if (isDynamicCategory && selectedCat) {
      selectedCat.stock_list = stockData;
      Bot.setProperty("fb_categories", fbCategories, "json");
  } else if (isGeneralCategory && selectedCat) {
      selectedCat.stock_list = stockData;
      var categories = Bot.getProperty("ff_categories") || {};
      categories[rawType] = selectedCat;
      Bot.setProperty("ff_categories", categories, "json");
      Bot.setProperty("ff_stock_" + rawType, stockData, "json");
  } else {
      Bot.setProperty("ff_stock_" + rawType, stockData, "json");
  }

  // ===================================================
  // ⚡ CRITICAL SPLIT & BOUNDARY ISOLATION
  // ===================================================
  var fullRawString = String(accountExtracted || "").trim();
  var emailData = fullRawString;
  var passwordData = "No Password Found";

  if (fullRawString.indexOf("|") !== -1) {
      var lastPipeIndex = fullRawString.lastIndexOf("|");
      var firstPart = fullRawString.substring(0, lastPipeIndex).trim();
      var secondPart = fullRawString.substring(lastPipeIndex + 1).trim();

      if (firstPart.indexOf(" ") !== -1) {
          var spaceParts = firstPart.split(" ");
          emailData = spaceParts[spaceParts.length - 1].trim();
      } else {
          emailData = firstPart;
      }
      passwordData = secondPart;
  }

  // ===================================================
  // 💾 AUTOMATIC HISTORY STORAGE ENGINE
  // ===================================================
  let purchasedKeys = User.getProperty("my_purchased_keys") || [];
  if (!Array.isArray(purchasedKeys)) { purchasedKeys = []; }
  
  let currentDate = new Date().toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' });
  purchasedKeys.push({
      productName: displayTypeName,
      cost: finalCost.toString(),
      key: emailData + (passwordData !== "No Password Found" ? " | " + passwordData : ""),
      days: "Permanent", 
      date: currentDate
  });
  User.setProperty("my_purchased_keys", purchasedKeys, "json");

  // ===================================================
  // ⭐ COMPACT USER DISPLAY LOGIC
  // ===================================================
  var deliveryText = 
    "┏━━━━━━━━━━━━━━━━━━━━━━━━┓\n" +
    "┃ <tg-emoji emoji-id='6267140231632262769'>❤️‍🔥</tg-emoji> <b>PURCHASE SUCCESSFUL!</b> <tg-emoji emoji-id='6267140231632262769'>❤️‍🔥</tg-emoji> ┃\n" +
    "┗━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n" +
    "<tg-emoji emoji-id='5463172695132745432'>📦</tg-emoji> <b>Item:</b> <code>" + displayTypeName + "</code>\n" +
    "<tg-emoji emoji-id='6267068789146260253'>💰</tg-emoji> <b>Paid:</b> <code>₹" + finalCost + "</code> " + (isReseller ? "<b>(Reseller)</b>" : "") + "\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
    "<tg-emoji emoji-id='6145572393499762737'>👤</tg-emoji> <b>ACCOUNT DETAILS:</b>\n\n" +
    "<tg-emoji emoji-id='6041705726206808304'>🚀</tg-emoji> <b>Email:</b> <code>" + emailData + "</code>\n" +
    "<tg-emoji emoji-id='5902002809573740949'>🔒</tg-emoji> <b>Password:</b> <code>" + passwordData + "</code>\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
    "<tg-emoji emoji-id='5210956306952758910'>⚠️</tg-emoji> <i>Copy details instantly.</i>";

  Api.sendMessage({
      chat_id: chatID,
      text: deliveryText,
      parse_mode: "HTML"
  });

  if (queryId) {
      Api.answerCallbackQuery({
          callback_query_id: String(queryId),
          text: "✅ Released Successfully!",
          show_alert: false
      });
  }

  // ===================================================
  // 🔔 COMPACT ADMIN NOTIFICATION PIPELINE
  // ===================================================
  var adminLogChannel = "7088682169"; 
  var adminNotificationMsg = 
    "<blockquote><tg-emoji emoji-id='5447644880824181073'>⚠️</tg-emoji> <b>NEW ORDER ALERT</b>" + (isReseller ? " [RESELLER]" : "") + "</blockquote>\n" +
    "👤 <b>User:</b> <a href='tg://user?id=" + userId + "'>" + user.first_name + "</a> (<code>" + userId + "</code>)\n" +
    "📦 <b>Item:</b> <code>" + displayTypeName + "</code>\n" +
    "💰 <b>Revenue:</b> <code>₹" + finalCost + "</code>\n" +
    "⚡ <b>Stock Left:</b> <code>" + stockData.length + " units</code>\n\n" +
    "🖥 <b>ACCOUNT DETAILS:</b>\n" +
    "➔ <b>Email:</b> <code>" + emailData + "</code>\n" +
    "➔ <b>Password:</b> <code>" + passwordData + "</code>";

  Api.sendMessage({
      chat_id: adminLogChannel,
      text: adminNotificationMsg,
      parse_mode: "HTML"
  });

} catch(e) {
  Bot.sendMessage("Critical Execution Failure Module Error: " + e.message);
}