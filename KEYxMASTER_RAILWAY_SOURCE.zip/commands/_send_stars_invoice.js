/**#command
name: /send_stars_invoice
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// ⭐ Sends a real Telegram Stars (XTR) invoice.
// Usage via callback_data:
//   /send_stars_invoice deposit <amount>
//   /send_stars_invoice buy <prodIdx> <planIdx>
//
// ⚠️ IMPORTANT: This uses the RAW Telegram Bot API (sendInvoice) directly
// via bot.token, bypassing any platform-specific wrapper, since Stars
// payments (XTR currency, empty provider_token) need exact API compliance.
// For Stars: provider_token MUST be an empty string, currency MUST be "XTR".
// =========================================================

try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;

  var parts = params ? String(params).trim().split(" ") : [];
  var mode = parts[0];

  var title, description, payload, starsAmount;

  if (mode === "deposit") {
    starsAmount = parseInt(parts[1]);
    if (isNaN(starsAmount) || starsAmount <= 0) {
      Bot.sendMessage("❌ Invalid Stars amount.");
      return;
    }
    title = "Wallet Deposit — " + starsAmount + " Stars";
    description = "Add " + starsAmount + " Telegram Stars to your KEYxMASTER wallet balance.";
    payload = "deposit:" + userId + ":" + starsAmount;

  } else if (mode === "buy") {
    var prodIdx = Number(parts[1]);
    var planIdx = Number(parts[2]);
    var productList = Bot.getProperty("stored_products") || [];
    var product = productList[prodIdx];
    if (!product || !product.plans || !product.plans[planIdx]) {
      Bot.sendMessage("❌ Product/Plan not found.");
      return;
    }
    var plan = product.plans[planIdx];
    var cleanProdName = product.name.trim().toUpperCase();
    var planUnit = plan.unit || "day";
    var cleanPlanDays = String(plan.days).replace(/[^0-9.]/g, "").trim();
    var starsKeySuffix = (planUnit === "day") ? cleanPlanDays : (cleanPlanDays + "_" + planUnit);
    var starsPriceKey = "stars_price_" + cleanProdName + "_" + starsKeySuffix;
    starsAmount = Number(Bot.getProperty(starsPriceKey) || 0);

    if (!starsAmount) {
      Bot.sendMessage("❌ Is plan ke liye Stars price abhi set nahi hai. Admin se contact karein.");
      return;
    }

    var durationDisplay = plan.durationDisplay || (cleanPlanDays + " " + (planUnit === "hour" ? "Hour(s)" : planUnit === "minute" ? "Minute(s)" : "Day(s)"));
    title = product.name + " — " + durationDisplay;
    description = "Instant key delivery for " + product.name + " (" + durationDisplay + "), paid via Telegram Stars.";
    payload = "buy:" + userId + ":" + prodIdx + ":" + planIdx;

  } else {
    Bot.sendMessage("❌ Invalid invoice request.");
    return;
  }

  var invoiceBody = {
    chat_id: chatId,
    title: title,
    description: description,
    payload: payload,
    provider_token: "", // ✅ MUST be empty string for Telegram Stars (XTR)
    currency: "XTR",
    prices: JSON.stringify([{ label: title, amount: starsAmount }])
  };

  HTTP.post({
    url: "https://api.telegram.org/bot" + bot.token + "/sendInvoice",
    body: invoiceBody
  });

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) {
    try { Api.answerCallbackQuery({ callback_query_id: String(queryId), text: "⭐ Invoice sent!" }); } catch (e) {}
  }

} catch (err) {
  Bot.sendMessage("⚠️ Stars Invoice Error: " + err.message, { parse_mode: "HTML" });
}