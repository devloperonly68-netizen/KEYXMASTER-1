/**#command
name: /dismiss_msg
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var callbackId = request ? request.id : (request.callback_query && request.callback_query.id);

  if (request && request.message) {
    try { Api.deleteMessage({ chat_id: chat.chatid, message_id: request.message.message_id }); } catch (e) {}
  }

  if (callbackId) {
    Api.answerCallbackQuery({ callback_query_id: String(callbackId) });
  }
} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}