/**#command
name: /manage_coadmin
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 👑 OWNER-ONLY — Manage Co-Admins
// Usage: /manage_coadmin add USERID | /manage_coadmin remove USERID | /manage_coadmin list
// Co-Admins get full /admin panel access (product/plan/key/price/coupon/broadcast controls)
// but CANNOT manage other co-admins or transfer ownership — that stays Owner-only.
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "7088682169";
  var currentChatId = String(chat.chatid);

  if (currentChatId !== ownerId) {
    Bot.sendMessage("❌ Sirf Owner hi co-admins manage kar sakta hai!");
    return;
  }

  if (!params || params.trim() === "") {
    var coAdminList = Bot.getProperty("co_admin_list") || [];
    Bot.sendMessage(
      "⚠️ <b>Format:</b>\n" +
      "<code>/manage_coadmin add USERID</code>\n" +
      "<code>/manage_coadmin remove USERID</code>\n" +
      "<code>/manage_coadmin list</code>\n\n" +
      "<b>Current Co-Admins:</b> " + (coAdminList.length ? coAdminList.join(", ") : "None"),
      { parse_mode: "HTML" }
    );
    return;
  }

  var parts = params.trim().split(" ");
  var action = parts[0].toLowerCase();
  var targetId = parts[1] ? parts[1].trim() : null;

  var coAdminList = Bot.getProperty("co_admin_list") || [];

  if (action === "list") {
    Bot.sendMessage(
      "<blockquote>👑 <b>CO-ADMIN LIST</b></blockquote>\n\n" + (coAdminList.length ? coAdminList.map(function (id) { return "• <code>" + id + "</code>"; }).join("\n") : "<i>Koi co-admin nahi hai.</i>"),
      { parse_mode: "HTML" }
    );
    return;
  }

  if (!targetId || isNaN(Number(targetId))) {
    Bot.sendMessage("❌ Valid User ID chahiye! Example: <code>/manage_coadmin add 123456789</code>", { parse_mode: "HTML" });
    return;
  }

  if (action === "add") {
    if (targetId === ownerId) {
      Bot.sendMessage("❌ Owner khud apne aap ko co-admin nahi bana sakta!");
      return;
    }
    Bot.setProperty("co_admin_" + targetId, true, "boolean");
    if (coAdminList.indexOf(targetId) === -1) {
      coAdminList.push(targetId);
      Bot.setProperty("co_admin_list", coAdminList, "json");
    }
    Bot.sendMessage("✅ <b>Co-Admin Added!</b> User <code>" + targetId + "</code> ab poora admin panel access kar sakta hai.", { parse_mode: "HTML" });
    try {
      Api.sendMessage({
        chat_id: targetId,
        text: "<blockquote>👑 <b>YOU ARE NOW A CO-ADMIN!</b></blockquote>\n\n<i>Aapko is store ke admin panel ka full access de diya gaya hai. /admin command use karke access karein.</i>",
        parse_mode: "HTML"
      });
    } catch (e) {}
  } else if (action === "remove") {
    Bot.setProperty("co_admin_" + targetId, null, "boolean");
    var idx = coAdminList.indexOf(targetId);
    if (idx > -1) { coAdminList.splice(idx, 1); Bot.setProperty("co_admin_list", coAdminList, "json"); }
    Bot.sendMessage("✅ <b>Co-Admin Removed!</b> User <code>" + targetId + "</code> ka admin access hata diya gaya.", { parse_mode: "HTML" });
  } else {
    Bot.sendMessage("❌ Action 'add', 'remove', ya 'list' hona chahiye.");
  }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}