/**#command
name: /addstock_id
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169";
  if (String(chat.chatid) !== adminId) return;

  // Agar message khali hai
  if (!message) {
    Bot.sendMessage("❌ Format: <code>/addstock_id category_name email|password</code>", {parse_mode: "HTML"});
    return;
  }

  // Pura text line-by-line split karein (Bulk upload support ke liye)
  var lines = message.split("\n");
  var categories = Bot.getProperty("ff_categories") || {};
  
  var pendingStock = {}; 
  var totalAdded = 0;
  var reportMessage = "⚡ <b>Stock Loaded Successfully!</b>\n\n";

  for (var i = 0; i < lines.length; i++) {
    var currentLine = lines[i].trim();
    if (!currentLine) continue;

    // Command hatayein agar pehli line me ho
    if (currentLine.toLowerCase().indexOf("/addstock_id") === 0) {
      currentLine = currentLine.substring(12).trim(); // "/addstock_id" ki length 12 hai
    }
    
    if (!currentLine) continue;

    // Category aur account data ke beech ka space dhoondhein
    var spaceIndex = currentLine.indexOf(" ");
    if (spaceIndex === -1) continue;

    var alias = currentLine.substring(0, spaceIndex).toLowerCase().trim(); 
    var credential = currentLine.substring(spaceIndex + 1).trim(); // email|pass

    // Agar credential me "|" nahi hai toh line skip karein (Valid format check)
    if (credential.indexOf("|") === -1) continue;

    var finalSlug = "";

    // 1. Exact Category Slug Check
    if (categories[alias]) {
      finalSlug = alias;
    } else {
      // 2. Contains Slug Check or Name Match (Jaise 'lodu' ya 'fb')
      for (var key in categories) {
        var cleanKey = key.toLowerCase();
        var catName = categories[key].name ? categories[key].name.toLowerCase() : "";
        
        if (cleanKey.indexOf(alias) !== -1 || alias.indexOf(cleanKey) !== -1 ||
            catName.indexOf(alias) !== -1 || alias.indexOf(catName) !== -1) {
          finalSlug = key;
          break;
        }
      }
    }

    // Queue data if category found
    if (finalSlug !== "") {
      if (!pendingStock[finalSlug]) {
        pendingStock[finalSlug] = [];
      }
      pendingStock[finalSlug].push(credential);
      totalAdded++;
    }
  }

  // Database me save karein
  if (totalAdded > 0) {
    for (var slug in pendingStock) {
      var currentStock = Bot.getProperty("ff_stock_" + slug) || [];
      if (!Array.isArray(currentStock)) currentStock = [];

      var newAccounts = pendingStock[slug];
      for (var j = 0; j < newAccounts.length; j++) {
        currentStock.push(newAccounts[j]);
      }

      Bot.setProperty("ff_stock_" + slug, currentStock, "json");

      var catName = categories[slug] && categories[slug].name ? categories[slug].name : slug.toUpperCase();
      reportMessage += "• <code>" + newAccounts.length + " accounts</code> ➔ <b>" + catName + "</b>\n";
    }

    Bot.sendMessage(reportMessage, {parse_mode: "HTML"});
  } else {
    Bot.sendMessage("❌ <b>Stock Add Nahi Hua!</b>\n\nKyu nahi hua?\n1. <code>LODU</code> naam ki category system me nahi bani hai.\n2. Aapne account ke beech me <code>|</code> nahi lagaya.\n\n<b>Sahi Format:</b>\n<code>/addstock_id lodu jajaj@gmail.com|Sam72@</code>", {parse_mode: "HTML"});
  }

} catch(e) {
  Bot.sendMessage("Error: " + e.message);
}