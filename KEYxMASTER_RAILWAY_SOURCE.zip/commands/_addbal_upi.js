/**#command
name: /addbal_upi
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 💳 "UPI Pay" chosen on Add Balance screen — same purana FamPay QR
// flow jo pehle /press.js ke confirm button me seedha chalta tha.
// Amount hamesha ₹ (India price) me dikhta hai.
// =========================================================

try {
  let userId = user.telegramid;
  let callbackId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;

  let finalAmount = String(parseInt(params ? String(params).trim() : "0"));
  if (!finalAmount || finalAmount === "0" || isNaN(parseInt(finalAmount)) || parseInt(finalAmount) <= 0) {
    Bot.sendMessage("❌ Invalid amount!");
    return;
  }

  let e_gear = "<tg-emoji emoji-id='5348292765325212780'>⚙</tg-emoji>";
  let upiId = Bot.getProperty("payment_upi_id") || "galureang@fam";

  User.setProperty("deposit_amount", finalAmount, "string");

  HTTP.get({
    url: "https://fampay.anujbots.xyz/qr.php?upi=" + encodeURIComponent(upiId) + "&amount=" + encodeURIComponent(finalAmount),
    success: "/onQR",
    error: "/onApiError"
  });

  let generatingText =
    "<blockquote>" + e_gear + " <b>Generating QR Code for ₹" + finalAmount + "...</b>\n" +
    "<i>Please wait a moment</i></blockquote>";

  if (request && request.message) {
    Api.editMessageText({
      chat_id: chat.chatid,
      message_id: request.message.message_id,
      text: generatingText,
      parse_mode: "HTML"
    });

    try {
      Bot.setProperty("gen_msg_id_" + userId, request.message.message_id, "string");
      User.setProperty("gen_msg_id_" + userId, request.message.message_id, "string");
    } catch (e) {}
  } else {
    let genMsg = Api.sendMessage({ chat_id: chat.chatid, text: generatingText, parse_mode: "HTML" });
    try {
      let gmid = (genMsg && genMsg.result && genMsg.result.message_id) ? genMsg.result.message_id : (genMsg && genMsg.message_id ? genMsg.message_id : null);
      if (gmid) {
        Bot.setProperty("gen_msg_id_" + userId, gmid, "string");
        User.setProperty("gen_msg_id_" + userId, gmid, "string");
      }
    } catch (e) {}
  }

  if (callbackId) {
    Api.answerCallbackQuery({ callback_query_id: String(callbackId) });
  }

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}
