/**#command
name: /delete_coupon
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var ownerId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== ownerId && !isCoAdmin) { return; }

  var code = params ? String(params).trim().toUpperCase() : "";
  var c = Bot.getProperty("coupon_" + code);
  if (!c) {
    Bot.sendMessage("❌ Coupon not found.");
    return;
  }

  Bot.setProperty("coupon_" + code, null, "json");

  var couponList = Bot.getProperty("coupon_list") || [];
  var idx = couponList.indexOf(code);
  if (idx > -1) { couponList.splice(idx, 1); Bot.setProperty("coupon_list", couponList, "json"); }

  Bot.sendMessage("🗑 Coupon <code>" + code + "</code> delete ho gaya.", { parse_mode: "HTML" });

  Bot.run({ command: "/coupons" });

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}