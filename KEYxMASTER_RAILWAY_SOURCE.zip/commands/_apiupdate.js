/**#command
name: /apiupdate
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var ownerId=String(Bot.getProperty("owner_id")||"7088682169"), uid=String(chat.chatid), co=Bot.getProperty("co_admin_"+uid);
  if(uid!==ownerId && !co) return;
  var p=(params?String(params).trim():"").split("|").map(function(x){return x.trim();});
  if(p.length<3){ Bot.sendMessage("❌ Format: <code>/apiupdate ID | FIELD | VALUE</code>\nFields: name,url,api_key,master_key,mode,android_required,enabled",{parse_mode:"HTML"}); return; }
  var reg=Bot.getProperty("api_registry")||{}, id=p[0], field=p[1], value=p.slice(2).join("|");
  if(!reg[id]){Bot.sendMessage("❌ API ID not found: <code>"+id+"</code>",{parse_mode:"HTML"});return;}
  if(["name","url","api_key","master_key","mode"].indexOf(field)>=0) reg[id][field]=value;
  else if(field==="android_required" || field==="enabled") reg[id][field]=String(value).toLowerCase()==="true";
  else {Bot.sendMessage("❌ Invalid field.");return;}
  reg[id].updated_at=new Date().toISOString(); Bot.setProperty("api_registry",reg,"json");
  Bot.sendMessage("✅ <b>API Updated</b>\n<code>"+id+"</code> → <b>"+field+"</b>",{parse_mode:"HTML"});
} catch(e){Bot.sendMessage("⚠️ API Update Error: "+e.message);}
