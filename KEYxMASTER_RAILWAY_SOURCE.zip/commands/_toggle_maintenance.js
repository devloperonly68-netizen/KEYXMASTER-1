/**#command
name: /toggle_maintenance
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🛠 ADMIN/CO-ADMIN — Toggle Maintenance Mode
// ON: regular users see a premium "Under Maintenance" screen instead of the bot.
// OFF: next time each user hits /start, they get a one-time premium
// "Maintenance Removed — Bot is Back!" welcome with /start + Buy Now buttons.
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "7088682169";
  var currentChatId = String(chat.chatid);
  var isCoAdmin = Bot.getProperty("co_admin_" + currentChatId);

  if (currentChatId !== ownerId && !isCoAdmin) {
    Bot.sendMessage("❌ Restricted command!");
    return;
  }

  var current = Bot.getProperty("maintenance_mode") || false;
  var newState = !current;
  Bot.setProperty("maintenance_mode", newState, "boolean");

  if (newState) {
    Bot.sendMessage(
      "<blockquote><tg-emoji emoji-id='6100657257605763582'>🛠</tg-emoji> <b>MAINTENANCE MODE ENABLED</b></blockquote>\n\n" +
      "<i>Regular users ab bot use nahi kar payenge — unhe premium maintenance screen dikhega. Aap aur co-admins normally kaam karte rahenge.</i>",
      { parse_mode: "HTML" }
    );
  } else {
    Bot.setProperty("maintenance_removed_at", Date.now(), "number");
    Bot.sendMessage(
      "<blockquote><tg-emoji emoji-id='6102856637343600044'>✅</tg-emoji> <b>MAINTENANCE MODE DISABLED</b></blockquote>\n\n" +
      "<i>Bot phir se live hai! Users ko agli baar /start karne par ek premium 'We're Back!' welcome dikhega.</i>",
      { parse_mode: "HTML" }
    );
  }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}