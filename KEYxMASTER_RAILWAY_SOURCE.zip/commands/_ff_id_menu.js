/**#command
name: /ff_id_menu
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {

  // Answer Callback safely
  if (request && request.id) {
    try {
      Api.answerCallbackQuery({ callback_query_id: request.id });
    } catch (e) {}
  } else if (request && request.callback_query && request.callback_query.id) {
    try {
      Api.answerCallbackQuery({ callback_query_id: request.callback_query.id });
    } catch (e) {}
  }

  // Safe Chat ID Selection
  var targetChatId = (chat && chat.chatid) ? chat.chatid : ((chat && chat.id) ? chat.id : user.telegramid);

  var categories = Bot.getProperty("ff_categories") || {};
  var inlineButtons = [];
  var hasCategories = false;

  for (var slug in categories) {
    if (!categories.hasOwnProperty(slug)) continue;

    hasCategories = true;

    var item = categories[slug];
    var stock = Bot.getProperty("ff_stock_" + slug) || [];

    if (!Array.isArray(stock)) stock = [];

    var buttonText = item.name;
    var buttonStyle = "primary"; // Default Blue Color

    if (stock.length === 0) {
      buttonText += " [OUT OF STOCK]";
      buttonStyle = "danger"; // Native Red Color
    } else {
      buttonText += " [Stock: " + stock.length + "]";
      buttonStyle = "success"; // Native Green Color
    }

    // Dynamic Emoji ID: Admin jo ID save karega, exact wahi inject hogi.
    var adminPremiumEmojiId = item.emoji_id || "5334890573281114250";

    inlineButtons.push([
      {
        text: buttonText,
        callback_data: "/select_id_product " + slug,
        style: buttonStyle,                         
        icon_custom_emoji_id: adminPremiumEmojiId   
      }
    ]);
  }

  // Agar categories na ho toh Danger (Red) Button
  if (!hasCategories) {
    inlineButtons.push([
      {
        text: "⚠️ No Platforms Active",
        callback_data: "/back",
        style: "danger"
      }
    ]);
  }

  // ✅ UPDATED: Back button styled to Primary (Blue) with your specific Premium Emoji ID
  inlineButtons.push([
    {
      text: "Back to Dashboard",
      callback_data: "/back",
      style: "primary",
      icon_custom_emoji_id: "5893163582194978381"
    }
  ]);

  // 📊 Live stats footer
  var totalCategories = 0;
  var totalStockAll = 0;
  for (var s in categories) {
    if (!categories.hasOwnProperty(s)) continue;
    totalCategories++;
    var st = Bot.getProperty("ff_stock_" + s) || [];
    if (Array.isArray(st)) totalStockAll += st.length;
  }

  var text =
    "<blockquote><b><tg-emoji emoji-id='6080228009439141516'>🎮</tg-emoji> FF ID STORE — SELECT A PLATFORM <tg-emoji emoji-id='6093854128193152827'>🔥</tg-emoji></b>\n\n" +
    "<i>Browse our available categories below. Instant delivery, verified accounts.</i></blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n" +
    "<tg-emoji emoji-id='6080214566191505147'>📦</tg-emoji> <b>Categories:</b> <code>" + totalCategories + "</code>   " +
    "<tg-emoji emoji-id='6091571559233755994'>📥</tg-emoji> <b>Total Stock:</b> <code>" + totalStockAll + " accounts</code>\n" +
    "━━━━━━━━━━━━━━━━━━━━━";

  var targetMessageId = (request && request.message) ? request.message.message_id : null;

  var replyMarkupObj = {
    inline_keyboard: inlineButtons
  };

  if (targetMessageId) {
    Api.editMessageText({
      chat_id: targetChatId,
      message_id: targetMessageId,
      text: text,
      parse_mode: "HTML",
      reply_markup: JSON.stringify(replyMarkupObj)
    });
  } else {
    Api.sendMessage({
      chat_id: targetChatId,
      text: text,
      parse_mode: "HTML",
      reply_markup: JSON.stringify(replyMarkupObj)
    });
  }

} catch (e) {
  var errorChatId = (chat && chat.chatid) ? chat.chatid : user.telegramid;
  Api.sendMessage({
    chat_id: errorChatId,
    text: "❌ Error structure:\n<code>" + e.message + "</code>",
    parse_mode: "HTML"
  });
}