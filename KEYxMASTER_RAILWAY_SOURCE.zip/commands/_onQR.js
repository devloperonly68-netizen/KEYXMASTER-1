/**#command
name: /onQR
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  if (!content) { 
    Bot.sendMessage("❌ Error: No response received from server.");
    return; 
  }

  var res = (typeof content === "object") ? content : JSON.parse(content);

  if (!res || res.status != "success" || !res.data) {
    Api.sendMessage({
      chat_id: chat.chatid,
      text: "<tg-emoji emoji-id='6219547832169273793'>❌</tg-emoji> <b>QR Generation Failed /</b>",
      parse_mode: "HTML"
    });
    return;
  }

  var order_id = res.data.order_id;
  var qr = res.data.qr_url;
  var expire = res.data.expires_at_ist ? res.data.expires_at_ist : "5 Minutes";
  
  var userId = user.telegramid;
  
  var deposit_amount = res.data.amount ||
                       Bot.getProperty("pending_pay_amount_" + userId) || 
                       User.getProperty("pending_pay_amount_" + userId) || 
                       Bot.getProperty("deposit_amount_" + userId) || 
                       User.getProperty("deposit_amount") || 
                       "0";

  if (!qr) {
    Bot.sendMessage("❌ Error: QR Code link missing from API response.");
    return;
  }

  var finalAmount = parseFloat(deposit_amount);
  if (isNaN(finalAmount) || finalAmount <= 0) {
    finalAmount = 0.00; 
  }

  var gatewayMsg = "<blockquote><tg-emoji emoji-id='6100170496077204999'>📋</tg-emoji> <b>Instructions</b></blockquote>\n" +
    "• Scan the QR using any UPI app.\n" +
    "• Pay the exact amount shown below.\n" +
    "• Wait a few seconds after payment.\n" +
    "• Tap <b>Verify Payment</b> below.\n\n" +
    "🧾 <b>Order ID:</b> <code>" + order_id + "</code>\n" +
    "<tg-emoji emoji-id='6312263493051489212'>💰</tg-emoji> <b>Amount:</b> ₹<code>" + finalAmount.toFixed(2) + "</code>\n" +
    "<tg-emoji emoji-id='6100657257605763582'>⏳</tg-emoji> <b>Expires:</b> <code>" + expire + "</code>\n\n" +
    "<tg-emoji emoji-id='6102856637343600044'>✅</tg-emoji> <i>Your balance will be credited automatically after successful verification.</i>";

  var inlineButtons = [
    [
      {
        text: "Verify Payment",
        callback_data: "/check " + order_id,
        style: "success",
        icon_custom_emoji_id: "6102856637343600044"
      }
    ],
    [
      {
        text: "Cancel",
        callback_data: "/cancel_topup " + order_id,
        style: "danger",
        icon_custom_emoji_id: "6219547832169273793"
      }
    ]
  ];

  // ⚡ SPEED FIX: QR photo pehle bhejo taaki user ko turant dikhe, "Generating..."
  // wala purana message uske baad (background me) delete karo — pehle ye ulta
  // tha (pehle delete, fir photo), jisse QR dikhne me extra gap lagta tha.
  var genMsgId = null;
  try {
    genMsgId = Bot.getProperty("gen_msg_id_" + userId) || User.getProperty("gen_msg_id_" + userId);
  } catch (genErr) {}

  var sentQrMsg = Api.sendPhoto({
    chat_id: chat.chatid,
    photo: qr,
    caption: gatewayMsg,
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: inlineButtons })
  });

  if (genMsgId) {
    try { Api.deleteMessage({ chat_id: chat.chatid, message_id: genMsgId }); } catch (delGenErr) {}
    Bot.setProperty("gen_msg_id_" + userId, null, "string");
    User.setProperty("gen_msg_id_" + userId, null, "string");
  }

  var qrMsgId = null;
  try {
    if (sentQrMsg) {
      if (sentQrMsg.result && sentQrMsg.result.message_id) {
        qrMsgId = sentQrMsg.result.message_id;
      } else if (sentQrMsg.message_id) {
        qrMsgId = sentQrMsg.message_id;
      }
    }

    if (qrMsgId) {
      Bot.setProperty("qr_msg_id_" + userId, qrMsgId, "string");
      User.setProperty("qr_msg_id_" + userId, qrMsgId, "string");
    }

    if (order_id) {
      Bot.setProperty("qr_order_id_" + userId, order_id, "string");
      User.setProperty("qr_order_id_" + userId, order_id, "string");
      User.setProperty("pending_order_id", order_id, "string");

      // ✅ Ye "watch id" hai — expiry callback isse compare karega ki order abhi bhi wahi hai ya resolve ho chuka
      Bot.setProperty("qr_watch_order_" + userId, order_id, "string");
      User.setProperty("qr_watch_order_" + userId, order_id, "string");
    }

    Bot.setProperty("qr_caption_" + userId, gatewayMsg, "string");
    User.setProperty("qr_caption_" + userId, gatewayMsg, "string");
    Bot.setProperty("qr_buttons_" + userId, JSON.stringify(inlineButtons), "string");
    User.setProperty("qr_buttons_" + userId, JSON.stringify(inlineButtons), "string");

    var nowTs = String(new Date().getTime());
    Bot.setProperty("qr_created_ts_" + userId, nowTs, "string");
    User.setProperty("qr_created_ts_" + userId, nowTs, "string");

    Bot.setProperty("verifying_lock_" + userId, false, "boolean");
    User.setProperty("verifying_lock_" + userId, false, "boolean");
  } catch (saveErr) {}

  // ✅ CHANGED (per request): koi auto-expiry timer nahi hai ab. QR tab tak
  // valid rehta hai jab tak user khud "Cancel" na dabaye ya payment verify
  // na ho jaaye. Order kabhi background me apne aap "expire" nahi hoga —
  // sirf manual Cancel button se hi QR vanish hoga (see /cancel_topup).

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}