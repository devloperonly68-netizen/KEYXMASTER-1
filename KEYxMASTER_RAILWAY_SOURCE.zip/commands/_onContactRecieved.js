/**#command
name: /onContactRecieved
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var userId = user.telegramid;
  var contactData = request && request.message ? request.message.contact : null;

  if (!contactData) {
    Bot.sendMessage("⚠️ Contact data nahi mila, dobara try karein.");
    return;
  }

  if (String(contactData.user_id) !== String(userId)) {
    Api.sendMessage({
      chat_id: chat.chatid,
      text: "⚠️ <b>Please share your own contact</b> to verify.",
      parse_mode: "HTML",
      reply_markup: JSON.stringify({
        keyboard: [[{ text: "✅ Verify Account", request_contact: true }]],
        resize_keyboard: true,
        one_time_keyboard: true
      })
    });
    return;
  }

  Bot.setProperty("verified_" + userId, true, "boolean");
  User.setProperty("verified_" + userId, true, "boolean");
  // ✅ NEW: Joined date save karo (Profile section me dikhane ke liye)
  if (!Bot.getProperty("joined_date_" + userId)) {
    Bot.setProperty("joined_date_" + userId, new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }), "string");
  }

  var phone = contactData.phone_number || "N/A";

  Api.sendMessage({
    chat_id: chat.chatid,
    text: "<blockquote><tg-emoji emoji-id='5330237710655306682'>✅</tg-emoji> <b>Account Verified Successfully!</b>\n<tg-emoji emoji-id='6266994443262367483'>😊</tg-emoji> <i>Welcome! Loading your menu...</i></blockquote>",
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ remove_keyboard: true })
  });

  var adminId = "7088682169";
  var uName = (user && user.first_name) ? user.first_name : "Unknown";
  var uUsername = (user && user.username) ? "@" + user.username : "No Username";

  var adminAlert = "<blockquote>" +
    "<tg-emoji emoji-id='6113743082358841933'>🔰</tg-emoji> <b>NEW USER VERIFIED</b>\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
    "👤 <b>Name:</b> " + uName + " (" + uUsername + ")\n" +
    "🆔 <b>User ID:</b> <code>" + userId + "</code>\n" +
    "📞 <b>Phone:</b> <code>" + phone + "</code>\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
    "✅ <i>Status: Verified via Contact Share</i>" +
    "</blockquote>";

  Api.sendMessage({ chat_id: adminId, text: adminAlert, parse_mode: "HTML" });

  // 🔗 PENDING DEEP LINK -> LOADING THEN SHOW PRODUCT PLANS (via HTTP delay)
  var pendingSlug = Bot.getProperty("pending_deeplink_" + userId) || User.getProperty("pending_deeplink_" + userId) || "";

  if (pendingSlug !== "") {
    var productList = Bot.getProperty("stored_products") || [];
    var matchedIdx = -1;

    for (var p = 0; p < productList.length; p++) {
      var slug = String(productList[p].name || "").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
      if (slug === pendingSlug.toLowerCase()) {
        matchedIdx = p;
        break;
      }
    }

    Bot.setProperty("pending_deeplink_" + userId, null, "string");
    User.setProperty("pending_deeplink_" + userId, null, "string");

    if (matchedIdx > -1) {
      // ⏳ STEP 1: LOADING MESSAGE
      var loadingText = "<blockquote>" +
        "<tg-emoji emoji-id='6147936236125298267'>⏳</tg-emoji> <b>Loading your product</b><tg-emoji emoji-id='6193006377389005214'>...</tg-emoji>\n" +
        "<i>Please wait a moment</i>" +
        "</blockquote>";

      var loadingMsg = Api.sendMessage({
        chat_id: chat.chatid,
        text: loadingText,
        parse_mode: "HTML"
      });

      var loadingMsgId = (loadingMsg && loadingMsg.result && loadingMsg.result.message_id) ? loadingMsg.result.message_id : null;

      // 💾 STEP 2: Save state for the delayed callback
      User.setProperty("dl_wait_msgid", loadingMsgId, "number");
      User.setProperty("dl_wait_prodidx", matchedIdx, "number");
      User.setProperty("dl_wait_chatid", String(chat.chatid), "string");

      // ⏳ STEP 3: 4-SECOND DELAY VIA HTTP CALLBACK (setTimeout ke bajaye)
      HTTP.get({
        url: "https://httpbin.org/delay/4",
        success: "/onDeepLinkPlanShow",
        error: "/onDeepLinkPlanShow"
      });

      return;
    }
  }

  // ✅ Koi pending deep-link nahi -> DIRECT MAIN MENU
  var userBal2 = "0.00";
  try {
    var res2 = 0;
    if (Libs && Libs.ResourcesLib) { res2 = Libs.ResourcesLib.userRes("balance").value() || 0; }
    var adminBal2 = Bot.getProperty("balance" + userId) || 0;
    userBal2 = (Number(res2) + Number(adminBal2)).toFixed(2);
  } catch (balErr2) {
    var fallbackBal2 = Bot.getProperty("balance" + userId) || 0;
    userBal2 = Number(fallbackBal2).toFixed(2);
  }

  var welcomeMessage2 =
    "<tg-emoji emoji-id=\"6266967801580231067\">💎</tg-emoji> <tg-emoji emoji-id=\"5866053971960929280\">🏪</tg-emoji> <b>— KEYxMASTER PANEL —</b> <tg-emoji emoji-id=\"5866053971960929280\">🏪</tg-emoji> <tg-emoji emoji-id=\"6266967801580231067\">💎</tg-emoji>\n\n" +
    "<tg-emoji emoji-id=\"6093677128295914531\">🎉</tg-emoji> <b>Hello, " + ((user && user.first_name) ? user.first_name.toUpperCase() : "RESELLER") + "!</b>\n\n" +
    "<tg-emoji emoji-id=\"6080228009439141516\">💧</tg-emoji> <b>Genuine, limited-stock books. Instant delivery.</b>\n\n" +
    "<tg-emoji emoji-id=\"6093591495237967001\">🌐</tg-emoji> Wide product catalog\n" +
    "<tg-emoji emoji-id=\"6215386799133433653\">🔑</tg-emoji> Instant delivery on payment\n" +
    "<tg-emoji emoji-id=\"6312263493051489212\">💰</tg-emoji> Multiple payment gateways\n" +
    "<tg-emoji emoji-id=\"6100170496077204999\">👑</tg-emoji> 24/7 admin support\n\n" +
    "<i>Balance: ₹" + userBal2 + "</i>\n\n" +
    "<i>Tap any button below to begin:</i> <tg-emoji emoji-id='6057415823222379852'>👇</tg-emoji>";

  var multiColorKeyboard2 = [
    [{ text: "Shop Now", callback_data: "/buy_hack", style: "primary", icon_custom_emoji_id: "5866053971960929280" }],
    [
      { text: "Profile", callback_data: "/profile", style: "primary", icon_custom_emoji_id: "5260399854500191689" },
      { text: "Add Balance", callback_data: "/addfund", style: "success", icon_custom_emoji_id: "6147815702163102310" }
    ],
    [
      { text: "My Keys", callback_data: "/mykey", style: "primary", icon_custom_emoji_id: "6113743082358841933" },
      { text: "How to use", callback_data: "/how", style: "danger", icon_custom_emoji_id: "6080214566191505147" }
    ],
    [{ text: "Payment Proofs", url: (Bot.getProperty("payment_proof_link") || "https://t.me/GaluModz_Proof"), style: "success", icon_custom_emoji_id: "5330237710655306682" }],
    [{ text: "Support", callback_data: "/support", style: "danger", icon_custom_emoji_id: "5436113877181941026" }]
  ];

  Api.sendMessage({
    chat_id: chat.chatid,
    text: welcomeMessage2,
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: multiColorKeyboard2 })
  });

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}