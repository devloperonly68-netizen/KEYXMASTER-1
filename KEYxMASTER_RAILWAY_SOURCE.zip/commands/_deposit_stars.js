/**#command
name: /deposit_stars
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// ⭐ TELEGRAM STARS — Deposit screen (Wallet top-up in Stars)
// Note: Stars balance is tracked SEPARATELY from the Rupee/UPI wallet,
// since Telegram Stars (XTR) is its own currency and can't be mixed 1:1
// with rupee balance without a fixed conversion rate.
// =========================================================

try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;
  var starsBalance = Number(Bot.getProperty("stars_balance_" + userId) || 0);

  var text =
    "<blockquote>⭐ <b>DEPOSIT TELEGRAM STARS</b></blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "⭐ <b>Current Stars Balance:</b> <code>" + starsBalance + "</code>\n\n" +
    "<i>Choose an amount below, or enter a custom amount. Payment goes through Telegram's official Stars checkout — instant &amp; secure.</i>\n" +
    "━━━━━━━━━━━━━━━━━━━━━";

  var buttons = [
    [
      { text: "⭐ 50", callback_data: "/send_stars_invoice deposit 50", style: "primary" },
      { text: "⭐ 100", callback_data: "/send_stars_invoice deposit 100", style: "primary" },
      { text: "⭐ 250", callback_data: "/send_stars_invoice deposit 250", style: "primary" }
    ],
    [
      { text: "⭐ 500", callback_data: "/send_stars_invoice deposit 500", style: "primary" },
      { text: "⭐ 1000", callback_data: "/send_stars_invoice deposit 1000", style: "primary" }
    ],
    [
      { text: "Custom Amount", callback_data: "/custom_stars_amount", style: "success", icon_custom_emoji_id: "6312263493051489212" }
    ],
    [
      { text: "Back to Menu", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
    ]
  ];

  if (request && request.message && !request.message.photo) {
    Api.editMessageText({ chat_id: String(chatId), message_id: Number(request.message.message_id), text: text, parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: buttons }) });
  } else {
    if (request && request.message && request.message.photo) {
      try { Api.deleteMessage({ chat_id: chatId, message_id: request.message.message_id }); } catch (e) {}
    }
    Api.sendMessage({ chat_id: chatId, text: text, parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: buttons }) });
  }

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}