/**#command
name: /set_payment_binance
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🟡 ADMIN — Quick one-line Binance Pay config (no QR).
// Usage: /set_payment_binance binance_id|usdt_address|rate
// Rate is optional. Use /set_payment_binance_btn for the full wizard
// (including QR upload).
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin0 = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  if (!params || params.trim() === "") {
    var currentId0 = Bot.getProperty("binance_pay_id") || "Not set";
    var currentAddr0 = Bot.getProperty("binance_usdt_address") || "Not set";
    var currentRate0 = Bot.getProperty("usd_rate") || "91 (default)";
    Bot.sendMessage(
      "⚠️ <b>Format:</b> <code>/set_payment_binance binance_id|usdt_address|91</code>\n" +
      "<i>(QR set karne ke liye Admin Panel me \"Set Payment (Binance Pay)\" button use karein)</i>\n\n" +
      "<b>Current Binance Pay ID:</b> <code>" + currentId0 + "</code>\n" +
      "<b>Current USDT Address:</b> <code>" + currentAddr0 + "</code>\n" +
      "<b>Current USD Rate:</b> <code>₹" + currentRate0 + " = $1</code>",
      { parse_mode: "HTML" }
    );
    return;
  }

  var rawInput = params.trim();
  var inputParts = rawInput.split("|");
  var newBinanceId = inputParts[0].trim();
  var newUsdtAddress = (inputParts.length > 1) ? inputParts[1].trim() : null;
  var newRate = (inputParts.length > 2) ? parseFloat(inputParts[2].trim()) : null;

  if (!newBinanceId) {
    Bot.sendMessage("❌ Invalid Binance Pay ID!", { parse_mode: "HTML" });
    return;
  }
  if (newRate !== null && (isNaN(newRate) || newRate <= 0)) {
    Bot.sendMessage("❌ Invalid USD Rate! Ek valid positive number bhejein, jaise 91.", { parse_mode: "HTML" });
    return;
  }

  Bot.setProperty("binance_pay_id", newBinanceId, "string");
  var confirmMsg = "✅ <b>Binance payment config update ho gaya:</b>\n• Binance Pay ID: <code>" + newBinanceId + "</code>";

  if (newUsdtAddress) {
    Bot.setProperty("binance_usdt_address", newUsdtAddress, "string");
    confirmMsg += "\n• USDT Address: <code>" + newUsdtAddress + "</code>";
  }
  if (newRate !== null) {
    Bot.setProperty("usd_rate", newRate, "string");
    confirmMsg += "\n• USD Rate: <code>₹" + newRate + " = $1</code>";
  }

  confirmMsg += "\n\n<i>Note: QR change karne ke liye Admin Panel wizard use karein.</i>";
  Bot.sendMessage(confirmMsg, { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
