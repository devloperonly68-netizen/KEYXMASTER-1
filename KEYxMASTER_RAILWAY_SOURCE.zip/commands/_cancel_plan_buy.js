/**#command
name: /cancel_plan_buy
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// ❌ Cancel button on the "Confirm Your Purchase" screen
// =========================================================

try {
  var chatId = chat.chatid;

  var cancelText =
    "<blockquote>" +
    "<tg-emoji emoji-id='6219547832169273793'>❌</tg-emoji> <b>PURCHASE CANCELLED</b>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n" +
    "<tg-emoji emoji-id='6266994443262367483'>😊</tg-emoji> <i>Koi baat nahi, jab chaho phir se shop se buy kar sakte ho.</i>" +
    "</blockquote>";

  var buttons = [[
    { text: "Shop Menu", callback_data: "/buy_hack", style: "success", icon_custom_emoji_id: "5330237710655306682" }
  ]];

  if (request && request.message) {
    try {
      Api.editMessageText({
        chat_id: String(chatId),
        message_id: Number(request.message.message_id),
        text: cancelText,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: buttons })
      });
    } catch (e) {
      Api.sendMessage({ chat_id: chatId, text: cancelText, parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: buttons }) });
    }
  } else {
    Api.sendMessage({ chat_id: chatId, text: cancelText, parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: buttons }) });
  }

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) {
    try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {}
  }

} catch (e) {
  Bot.sendMessage("⚠️ Error: " + e.message);
}