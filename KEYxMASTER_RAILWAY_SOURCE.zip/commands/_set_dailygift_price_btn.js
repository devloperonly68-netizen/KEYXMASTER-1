/**#command
name: /set_dailygift_price_btn
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🎁 ADMIN PANEL BUTTON — "Set Daily Gift Price"
// Pressing this button prompts the admin to send the new amount as a
// normal text message next; _start.js (MODULE 5) auto-captures that
// reply and forwards it to /set_dailygift_price internally.
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var currentChatId = String(chat.chatid);
  var isCoAdmin = Bot.getProperty("co_admin_" + currentChatId);

  if (currentChatId !== adminId && !isCoAdmin) {
    Bot.sendMessage("❌ You are not authorized to use this.");
    return;
  }

  var currentAmount = Bot.getProperty("daily_gift_amount");
  if (currentAmount === undefined || currentAmount === null) currentAmount = "1 (default)";

  User.setProperty("set_dailygift_price_step", "waiting_input", "string");

  var promptText =
    "<blockquote><tg-emoji emoji-id='6194922667242429131'>🎁</tg-emoji> <b>Set Daily Gift Amount</b></blockquote>\n\n" +
    "<i>Naya amount bhejein (₹) jo har user ko 24 ghante me ek baar Daily Gift me milega.</i>\n\n" +
    "<b>Current amount:</b> ₹<code>" + currentAmount + "</code>";

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;

  if (request && request.message && request.message.message_id) {
    try {
      Api.editMessageText({
        chat_id: String(chat.chatid),
        message_id: Number(request.message.message_id),
        text: promptText,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "Cancel", callback_data: "/admin", style: "danger" }]] })
      });
    } catch (e) {
      Api.sendMessage({ chat_id: chat.chatid, text: promptText, parse_mode: "HTML" });
    }
  } else {
    Bot.sendMessage(promptText, { parse_mode: "HTML" });
  }

  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
