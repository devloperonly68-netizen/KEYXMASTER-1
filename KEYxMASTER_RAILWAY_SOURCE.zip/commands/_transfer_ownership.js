/**#command
name: /transfer_ownership
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 👑 OWNER-ONLY — Transfer Ownership
// Usage: /transfer_ownership USERID
// ⚠️ IMPORTANT LIMITATION: this updates the dynamic "owner_id" property that
// NEW commands (admin panel, coupon, co-admin, maintenance) check. Older
// admin-only commands in this bot (addproduct, addkey, addbal, etc.) still
// have the original owner ID hardcoded as literal text in ~30 files — those
// would need a separate one-time refactor to fully recognize a new owner too.
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "7088682169";
  var currentChatId = String(chat.chatid);

  if (currentChatId !== ownerId) {
    Bot.sendMessage("❌ Sirf current Owner hi ownership transfer kar sakta hai!");
    return;
  }

  if (!params || params.trim() === "") {
    Bot.sendMessage("⚠️ <b>Format:</b> <code>/transfer_ownership USERID</code>", { parse_mode: "HTML" });
    return;
  }

  var newOwnerId = params.trim();
  if (isNaN(Number(newOwnerId))) {
    Bot.sendMessage("❌ Valid numeric User ID chahiye!");
    return;
  }
  if (newOwnerId === ownerId) {
    Bot.sendMessage("❌ Ye to already aap hi hain!");
    return;
  }

  User.setProperty("pending_ownership_transfer_to", newOwnerId, "string");

  Api.sendMessage({
    chat_id: chat.chatid,
    text: "<blockquote>⚠️ <b>CONFIRM OWNERSHIP TRANSFER</b></blockquote>\n\n" +
          "Aap ownership <code>" + newOwnerId + "</code> ko transfer karne wale hain.\n" +
          "<b>Ye action turant apply hoga aur aap Owner nahi rahenge!</b>\n\n" +
          "<i>Kya aap sure hain?</i>",
    parse_mode: "HTML",
    reply_markup: JSON.stringify({
      inline_keyboard: [[
        { text: "Confirm Transfer", callback_data: "/confirm_ownership_transfer", style: "danger", icon_custom_emoji_id: "6215386799133433653" },
        { text: "Cancel", callback_data: "/cancel_ownership_transfer", style: "primary" }
      ]]
    })
  });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}