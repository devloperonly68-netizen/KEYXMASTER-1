/**#command
name: /setprice
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
    // 1. Admin ID validation check
    if (String(user.telegramid) !== "7088682169") {
        Bot.sendMessage("❌ You are not authorized to use this command.");
        return;
    }

    // 2. Check agar parameters empty hain
    if (!params || params.trim() === "") {
        Bot.sendMessage("⚠️ *Format galat hai!*\nAise use karein: `setprice 450` ya `/setprice 450`", { parse_mode: "Markdown" });
        return;
    }

    // 3. String se number nikalna aur check karna
    let newPrice = parseInt(params.trim(), 10);

    if (isNaN(newPrice) || newPrice <= 0) {
        Bot.sendMessage("⚠️ *Valid price enter karein!* Number hona chahiye.", { parse_mode: "Markdown" });
        return;
    }

    // 4. Global property me save karna
    Bot.setProperty("reseller_price", newPrice, "integer");
    
    // Success feedback message
    Bot.sendMessage("<tg-emoji emoji-id='6102856637343600044'>👑</tg-emoji> <b>[Admin Panel]</b>\n\n✅ Reseller Price successfully updated to: <b>₹" + newPrice + "</b>", { parse_mode: "HTML" });

} catch (err) {
    Bot.sendMessage("⚠️ Error: " + err.message);
}