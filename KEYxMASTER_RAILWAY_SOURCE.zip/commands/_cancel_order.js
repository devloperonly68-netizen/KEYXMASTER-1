/**#command
name: /cancel_order
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var userId = user.telegramid;

  Api.deleteMessage({
    chat_id: chat.chatid,
    message_id: request.message.message_id
  });

  User.setProperty("pending_order_id", null);
  User.setProperty("pending_pay_amount", null);

  // ✅ Expiry-watcher ko disable karo taaki baad mein galat message edit na ho
  Bot.setProperty("qr_order_id_" + userId, null, "string");
  User.setProperty("qr_order_id_" + userId, null, "string");
  Bot.setProperty("qr_watch_order_" + userId, null, "string");
  User.setProperty("qr_watch_order_" + userId, null, "string");
  Bot.setProperty("verifying_lock_" + userId, false, "boolean");
  User.setProperty("verifying_lock_" + userId, false, "boolean");

  var cancelMsg = "✖ <tg-emoji emoji-id='6082547652556233400'>❌</tg-emoji> <b>ORDER CANCELLED</b>\n" +
                  "━━━━━━━━━━━━━━━━━━━━━━\n" +
                  "<i>Your payment request has been cancelled successfully.</i>";

  Api.sendMessage({
    chat_id: chat.chatid,
    text: cancelMsg,
    parse_mode: "HTML",
    reply_markup: JSON.stringify({
      inline_keyboard: [[
        { text: "Back to Menu", callback_data: "/back", style: "primary", icon_custom_emoji_id: "6057415823222379852" }
      ]]
    })
  });

  Api.answerCallbackQuery({
    callback_query_id: request.id,
    text: "Order Cancelled",
    show_alert: false
  });

} catch (err) {
  Bot.sendMessage("✖ <b>Order Cancelled.</b>", { parse_mode: "HTML" });
}