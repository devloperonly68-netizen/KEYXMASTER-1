/**#command
name: /confirm_delete_stock
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var ADMIN_ID = "7088682169";
  if (String(user.telegramid) !== ADMIN_ID) return;

  if (!params) return;
  var catSlug = params.trim().toLowerCase();

  var categories = Bot.getProperty("ff_categories") || {};
  
  // Stock data clean logic dono references se
  var oldStock = categories[catSlug] && categories[catSlug].stock_list ? categories[catSlug].stock_list : (Bot.getProperty("ff_stock_" + catSlug) || []);
  var totalRemoved = Array.isArray(oldStock) ? oldStock.length : 0;

  // 1. Clear from separate property
  Bot.setProperty("ff_stock_" + catSlug, [], "json");

  // 2. Clear inside ff_categories property (if exists)
  if (categories[catSlug]) {
    categories[catSlug].stock_list = [];
    Bot.setProperty("ff_categories", categories, "json");
  }

  // Purane confirmation message ko edit karke success message dikhana
  var queryId = request.id || (request.callback_query && request.callback_query.id);
  
  var successText = "<blockquote><tg-emoji emoji-id='6267140231632262769'>✨</tg-emoji> <b>STOCK PURGED SUCCESSFULLY</b></blockquote>\n" +
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                    "📂 <b>Category Slug:</b> <code>" + catSlug.toUpperCase() + "</code>\n" +
                    "🗑 <b>Removed Count:</b> <code>" + totalRemoved + " Items</code>\n\n" +
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                    "✅ <i>All stock has been permanently wiped from the database.</i>";

  HTTP.post({
    url: "https://api.telegram.org/bot" + bot.token + "/editMessageText",
    body: {
      chat_id: chat.chatid,
      message_id: request.message.message_id,
      text: successText,
      parse_mode: "HTML"
    }
  });

  if (queryId) {
    Api.answerCallbackQuery({
      callback_query_id: String(queryId),
      text: "🗑️ Stock cleared completely!",
      show_alert: false
    });
  }

} catch (e) {
  Bot.sendMessage("Delete Callback Error: " + e.message);
}