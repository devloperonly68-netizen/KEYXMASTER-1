/**#command
name: /refer
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🎁 REFER & EARN — user-facing screen
// Shows the user's own referral link + how much they've earned so far.
// Bonus crediting logic lives in _start.js (capture), _onCheck.js
// (topup bonus) and _confirm_buyitem.js / _onWebKeyReceive.js (buy bonus).
// =========================================================

try {
  var userId = String(user.telegramid);
  var botUsername = Bot.getProperty("bot_username") || "X_Panel_Store_bot";

  var referralLink = "https://t.me/" + botUsername + "?start=ref" + userId;

  var referralCount = (Bot.getProperty("referrals_of_" + userId) || []).length;
  var totalEarned = Number(Bot.getProperty("refer_earnings_" + userId) || 0);

  var topupBonus = Number(Bot.getProperty("refer_earn_topup_amount"));
  if (isNaN(topupBonus)) topupBonus = 2;
  var buyBonus = Number(Bot.getProperty("refer_earn_buy_amount"));
  if (isNaN(buyBonus)) buyBonus = 2;

  var referText =
    "<blockquote><b>REFER & EARN</b></blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "<i>Apne dosto ko neeche wale link se invite karein aur free me kamaye!</i>\n\n" +
    "<tg-emoji emoji-id='5346004239246183111'>➕</tg-emoji> <b>Aapko milega:</b>\n" +
    "• ₹" + topupBonus.toFixed(2) + " — jab friend pehli baar balance add kare\n" +
    "• ₹" + buyBonus.toFixed(2) + " — jab friend pehli baar koi purchase kare\n\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n" +
    "<tg-emoji emoji-id='6039605143601680423'>📊</tg-emoji> <b>Total Referrals:</b> <code>" + referralCount + "</code>\n" +
    "<tg-emoji emoji-id='6267068789146260253'>💰</tg-emoji> <b>Total Earned:</b> <code>₹" + totalEarned.toFixed(2) + "</code>\n\n" +
    "<tg-emoji emoji-id='6091571559233755994'>🔗</tg-emoji> <b>Your Referral Link:</b>\n<code>" + referralLink + "</code>";

  var referButtons = [
    [{ text: "📤 Share Link", url: "https://t.me/share/url?url=" + encodeURIComponent(referralLink) + "&text=" + encodeURIComponent("Join karo aur turant discount pao!"), style: "success" }],
    [{ text: "Back to Menu", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }]
  ];

  if (request && request.message && request.message.message_id) {
    Api.editMessageText({
      chat_id: String(chat.chatid),
      message_id: Number(request.message.message_id),
      text: referText,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: referButtons })
    });
  } else {
    Api.sendMessage({
      chat_id: String(chat.chatid),
      text: referText,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: referButtons })
    });
  }

  var qid = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (qid) { try { Api.answerCallbackQuery({ callback_query_id: String(qid) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ <b>Refer & Earn Error:</b> <code>" + err.message + "</code>", { parse_mode: "HTML" });
}
