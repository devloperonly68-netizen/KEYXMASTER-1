/**#command
name: /clearstock
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var ADMIN_ID = "7088682169";

  if (String(user.telegramid) !== ADMIN_ID) {
    return;
  }

  // FIX 1: Message aur Params dono check karein (Button callback aur Direct typing dono handle karne ke liye)
  var input = (message || "").trim();
  var catSlug = "";

  if (params && params.trim() !== "") {
    catSlug = params.trim().toLowerCase();
  } else if (input.indexOf(" ") !== -1) {
    catSlug = input.split(" ")[1].trim().toLowerCase();
  } else {
    Bot.sendMessage("⚠️ <b>Format:</b> <code>/clearstock [category_slug]</code>\n\n<i>Example: /clearstock lodu</i>", { parse_mode: "HTML" });
    return;
  }

  var categories = Bot.getProperty("ff_categories") || {};

  if (!categories[catSlug]) {
    Bot.sendMessage(
      "❌ Category <code>" + catSlug + "</code> not found.",
      { parse_mode: "HTML" }
    );
    return;
  }

  // Stock check
  var oldStock = categories[catSlug].stock_list || Bot.getProperty("ff_stock_" + catSlug) || [];
  if (!Array.isArray(oldStock)) { oldStock = []; }

  var catName = categories[catSlug].name ? categories[catSlug].name.toUpperCase() : catSlug.toUpperCase();

  // HTML Content Builder
  var text = "<blockquote><tg-emoji emoji-id='5447644880824181073'>⚠️</tg-emoji> <b>CONFIRM STOCK DELETION</b></blockquote>\n" +
             "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
             "📁 <b>Category:</b> <code>" + catName + "</code>\n" +
             "📦 <b>Total Items:</b> <code>" + oldStock.length + "</code>\n" +
             "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
             "📋 <b>LIVE STOCK LIST:</b>\n\n";

  if (oldStock.length > 0) {
    for (var i = 0; i < oldStock.length; i++) {
      var rawItem = oldStock[i];
      var email = "N/A";
      var pass = "N/A";
      var price = "N/A"; // Added Price Variable

      // FIX 2: email|password|price dynamic parsing logic
      if (typeof rawItem === "string") {
        if (rawItem.indexOf("|") !== -1) {
          var parts = rawItem.split("|");
          email = parts[0] ? parts[0].trim() : "N/A";
          pass = parts[1] ? parts[1].trim() : "N/A";
          price = parts[2] ? parts[2].trim() : "N/A"; // Extra Price extraction
        } else {
          email = rawItem.trim();
        }
      } else if (rawItem && typeof rawItem === "object") {
        email = rawItem.email || rawItem.username || "N/A";
        pass = rawItem.password || rawItem.pass || "N/A";
        price = rawItem.price || "N/A";
      }

      text += "🆔 <b>Item #" + (i + 1) + "</b>\n" +
              "📧 <b>Email:</b> <code>" + email + "</code>\n" +
              "🔑 <b>Pass:</b> <code>" + pass + "</code>\n" +
              "💰 <b>Price:</b> <code>₹" + price + "</code>\n\n"; // Rendered Price beautifully
    }
  } else {
    text += "❌ <i>Stock is already empty!</i>\n";
  }

  text += "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
          "<i>Are you sure you want to permanently delete all items?</i>";

  // Inline Buttons
  var inlineButtons = [];
  if (oldStock.length > 0) {
    inlineButtons.push([
      { 
        text: "🗑️ Delete All Stock", 
        callback_data: "/confirm_delete_stock " + catSlug 
      }
    ]);
  }
  inlineButtons.push([
    { text: "❌ Cancel", callback_data: "/back" }
  ]);

  Api.sendMessage({
    chat_id: chat.chatid,
    text: text,
    reply_markup: JSON.stringify({ inline_keyboard: inlineButtons }),
    parse_mode: "HTML"
  });

} catch (e) {
  Bot.sendMessage(
    "❌ <b>Error:</b>\n<code>" + e.message + "</code>",
    { parse_mode: "HTML" }
  );
}