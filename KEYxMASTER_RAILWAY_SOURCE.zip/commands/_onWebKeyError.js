/**#command
name: /onWebKeyError
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

var dataOptions = options;
var chatId = dataOptions ? dataOptions.chat_id : chat.chatid;
var adminId = "7088682169";

var systemErrorText = "<blockquote>" +
  "❌ <b>ORDER FAILED</b>\n" +
  "━━━━━━━━━━━━━━━━━━━━━\n\n" +
  "⚠️ <b>Something went wrong. Please retry soon.</b>\n\n" +
  "⏳ <i>Wait some time, admin will stock refill soon.</i>\n" +
  "💰 <b>Status:</b> Your funds were not deducted.\n\n" +
  "━━━━━━━━━━━━━━━━━━━━━\n" +
  "🗣 <i>Feel free to check back in a few minutes!</i>" +
  "</blockquote>";

var errorInlineButtons = [[
  { text: "Back to Menu", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
]];

// ✅ FIX: sendMessage use kiya (photo message pe editMessageText fail hoti hai)
Api.sendMessage({
  chat_id: String(chatId),
  text: systemErrorText,
  parse_mode: "HTML",
  reply_markup: JSON.stringify({ inline_keyboard: errorInlineButtons })
});

if (dataOptions) {
  var adminAlertText = "⚠️ <b>API Reseller Error Alert!</b>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n" +
    "👤 <b>User:</b> " + (dataOptions.first_name || "Unknown") + " (<code>" + dataOptions.user_id + "</code>)\n" +
    "📦 <b>Product:</b> <code>" + dataOptions.prod_name + "</code>\n" +
    "⏳ <b>Plan:</b> <code>" + dataOptions.plan_days + " Days</code>\n" +
    "💵 <b>Price Amount:</b> ₹" + Number(dataOptions.price).toFixed(2) + "\n" +
    "🚨 <b>Reason:</b> External Website API is down or connection timed out.";

  Bot.sendMessageToChatWithId(adminId, adminAlertText);
}