/**#command
name: /onVerifyResult
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🚀 COMMAND = /onVerifyResult
// STATUS: ERROR-FREE DATA VALIDATION PIPELINE
// =========================================================

try {
  if (!content) {
    Bot.sendMessage("⚠️ Server response was blank. Please contact admin if payment was deducted.");
    return;
  }

  var res = (typeof content === "object") ? content : null;
  if (!res) {
    try { res = JSON.parse(content); } catch (e) { res = null; }
  }

  // Aapke response scheme ke mutabik status handle matrix
  var paymentVerified = (res && (res.status === "success" || res.status === "PAID" || res.success === true));
  var live_amount = res && res.data && res.data.amount ? res.data.amount : (User.getProperty("deposit_amount") || "0");
  var order_id = params ? params.trim() : "UNKNOWN";

  // ✅ BUG FIX: pehle yaha QR message delete/clear karne ka koi code hi nahi tha,
  // isi wajah se balance add hone ke baad bhi purana QR code chat me pada reh
  // jaata tha. Ab /onCheck.js jaisa hi vanish + state-clear logic add kiya gaya
  // hai taaki verify hote hi QR turant hat jaaye.
  var verifyUserId = (typeof user !== "undefined" && user) ? user.telegramid : null;
  var verifyChatId = (typeof chat !== "undefined" && chat) ? chat.chatid : null;

  function vanishQrOnVerify(uid, fallbackChatId) {
    try {
      var qrMsgId = Bot.getProperty("qr_msg_id_" + uid) ||
                    User.getProperty("qr_msg_id_" + uid) ||
                    User.getProperty("last_qr_message_id_" + uid);
      if (qrMsgId && fallbackChatId) {
        try { Api.deleteMessage({ chat_id: fallbackChatId, message_id: qrMsgId }); } catch (e) {}
      }
    } catch (e) {}
  }

  function clearQrStateOnVerify(uid) {
    if (!uid) return;
    Bot.setProperty("qr_msg_id_" + uid, null, "string");
    User.setProperty("qr_msg_id_" + uid, null, "string");
    User.setProperty("last_qr_message_id_" + uid, null, "string");
    Bot.setProperty("qr_order_id_" + uid, null, "string");
    User.setProperty("qr_order_id_" + uid, null, "string");
    Bot.setProperty("qr_watch_order_" + uid, null, "string");
    User.setProperty("qr_watch_order_" + uid, null, "string");
    Bot.setProperty("verifying_lock_" + uid, false, "boolean");
    User.setProperty("verifying_lock_" + uid, false, "boolean");
    User.setProperty("pending_order_id", null);
  }

  if (paymentVerified == true) {

    // Payment verify hote hi sabse pehle QR ko vanish karo (product delivery ho
    // ya sirf wallet balance add — dono cases me QR hatna chahiye)
    vanishQrOnVerify(verifyUserId, verifyChatId);
    clearQrStateOnVerify(verifyUserId);

    var prodIdx = User.getProperty("last_selected_prod_idx");
    var planIdx = User.getProperty("last_selected_plan_idx");
    var productList = Bot.getProperty("stored_products") || [];
    
    var product = (prodIdx !== undefined && prodIdx !== null) ? productList[Number(prodIdx)] : null;
    var plan = (product && planIdx !== undefined && planIdx !== null) ? product.plans[Number(planIdx)] : null;

    if (product && plan) {
      // 🟢 CASE A: DIRECT KEY EXTRACTION
      var stockList = Bot.getProperty("stock_" + product.name.trim() + "_" + plan.days.trim() + "_Day") || Bot.getProperty("stock_" + prodIdx + "_" + planIdx) || [];
      
      if (stockList.length > 0) {
        var deliveredKey = stockList.shift();
        
        Bot.setProperty("stock_" + product.name.trim() + "_" + plan.days.trim() + "_Day", stockList, "json");
        Bot.setProperty("stock_" + prodIdx + "_" + planIdx, stockList, "json");
        
        var userKeysHistory = User.getProperty("my_purchased_keys") || [];
        userKeysHistory.push({ product: product.name, days: plan.days, price: live_amount, key: deliveredKey, date: new Date().toLocaleDateString() });
        User.setProperty("my_purchased_keys", userKeysHistory, "json");

        var gatewaySuccessText = "┏━━━━━━━━━━━━━━━━━━━━━━━━ Club ┓\n" +
          "┃ <tg-emoji emoji-id='5350447674971660988'>✅</tg-emoji> <b>PAYMENT SUCCESSFUL</b> <tg-emoji emoji-id='5352825278672412291'>👆</tg-emoji> ┃\n" +
          "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n" +
          "<blockquote>" +
          "<tg-emoji emoji-id='6147767796097884213'>📦</tg-emoji> <b>Product Name:</b> <code>" + product.name + "</code>\n" +
          "<tg-emoji emoji-id='6145391828779672333'>💰</tg-emoji> <b>Validity:</b> <code>" + plan.days + " Days</code>\n" +
          "<tg-emoji emoji-id='6284816251143331422'>🗝</tg-emoji> <b>Your Key:</b> <code>" + deliveredKey + "</code>\n\n" +
          "━━━━━━━━━━━━━━━━━━━━━\n" +
          "✨ <i>Payment auto-verified! Enjoy your premium product.</i>" +
          "</blockquote>";

        Bot.sendMessage(gatewaySuccessText, { parse_mode: "HTML" });

        // Admin Log
        var adminMsg = "<blockquote>" +
          "🔔 <b>QR PAYMENT DIRECT DELIVERY</b> ✔️\n\n" +
          "👤 <b>Buyer:</b> " + user.first_name + " (<code>" + user.telegramid + "</code>)\n" +
          "📦 <b>Product:</b> " + product.name + "\n" +
          "🔑 <b>Key:</b> <code>" + deliveredKey + "</code>" +
          "</blockquote>";
          
        // ✅ FIXED: pehle yaha ek hardcoded chat_id ("7088682169" — kisi aur bot ka
        // reference ID) tha, jiski wajah se admin log tumhare admin ko kabhi milta
        // hi nahi tha. Ab yeh owner_id property se aata hai (same jo /start me set hai).
        var logAdminId = Bot.getProperty("owner_id") || "7088682169";
        Api.sendMessage({ chat_id: logAdminId, text: adminMsg, parse_mode: "HTML" });
        
        User.setProperty("last_selected_prod_idx", null);
        User.setProperty("last_selected_plan_idx", null);
        return;
      } else {
        Bot.sendMessage("⚠️ Payment received, but item went Out of Stock! Contact Admin with Order ID: <code>" + order_id + "</code>");
        return;
      }
    } else {
      // 🟡 CASE B: RE-ALIGNED BALANCE FALLBACK
      Libs.ResourcesLib.userRes("balance").add(Number(live_amount));

      // 🔔 Admin notification for wallet balance top-up
      var walletLogAdminId = Bot.getProperty("owner_id") || "7088682169";
      var walletAdminMsg = "<blockquote>" +
        "🔔 <b>WALLET BALANCE ADDED</b> ✔️\n\n" +
        "👤 <b>User:</b> " + user.first_name + " (<code>" + user.telegramid + "</code>)\n" +
        "💰 <b>Amount Added:</b> ₹" + Number(live_amount).toFixed(2) + "\n" +
        "🆔 <b>Order ID:</b> <code>" + order_id + "</code>" +
        "</blockquote>";
      try {
        Api.sendMessage({ chat_id: walletLogAdminId, text: walletAdminMsg, parse_mode: "HTML" });
      } catch (e) {}

      var walletSuccessText = "┏━━━━━━━━━━━━━━━━━━━━━━━━ Club ┓\n" +
        "┃ <tg-emoji emoji-id='6194922667242429131'>🎉</tg-emoji> <b>PAYMENT SUCCESSFUL</b> <tg-emoji emoji-id='6192822213486321961'>✨</tg-emoji> ┃\n" +
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n" +
        "<blockquote>" +
        "<tg-emoji emoji-id='6194911182499881916'>🗣</tg-emoji> <b>Amount Added:</b> ₹<code>" + Number(live_amount).toFixed(2) + "</code>\n\n" +
        "ℹ️ <i>Click the button below to browse products.</i>" +
        "</blockquote>";

      var shopButtons = [[{ text: "🛒 Shop Now", callback_data: "/back", style: "success", icon_custom_emoji_id: "6194922667242429131" }]];

      Api.sendMessage({
        chat_id: chat.chatid,
        text: walletSuccessText,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: shopButtons })
      });
    }
  } else {
    Bot.sendMessage("❌ <b>Payment not found yet.</b> Please complete the transaction first and make sure you have paid the exact amount.", { parse_mode: "HTML" });
  }
} catch (err) {
  Bot.sendMessage("⚠️ Process Error: " + err.message);
}