/**#command
name: /addkey
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169";
  if (String(chat.chatid) !== adminId) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  if (!params) {
    Bot.sendMessage("⚠️ *Format:* `/addkey PRODUCT NAME | DAYS | KEY1`\n`KEY2`\n`KEY3` (Line-by-line)", { parse_mode: "Markdown" });
    return;
  }

  var lines = params.split("\n");
  var firstLineParts = lines[0].split("|");

  if (firstLineParts.length < 3) {
    Bot.sendMessage("⚠️ *Galat Format!*\nPehli line me `Product Name | Days | Key` hona chahiye.", { parse_mode: "Markdown" });
    return;
  }

  // 1. Inputs ko clean aur trim karna
  var pName = firstLineParts[0].trim().toLowerCase();
  var pDays = firstLineParts[1].trim(); 
  
  var pDaysClean = pDays.includes("_Day") ? pDays : pDays + "_Day";
  var pDaysNumOnly = pDays.replace("_Day", "").trim(); 

  var keysToAdd = [];
  keysToAdd.push(firstLineParts[2].trim());

  for (var l = 1; l < lines.length; l++) {
    var currentLineKey = lines[l].trim();
    if (currentLineKey !== "") {
      keysToAdd.push(currentLineKey);
    }
  }

  // 2. Products fetching
  var productList = Bot.getProperty("stored_products") || [];
  var prodIdx = -1;
  var planIdx = -1;
  var exactProdName = firstLineParts[0].trim(); // Fallback name

  // Soft loop matching (Case insensitive)
  for (var i = 0; i < productList.length; i++) {
    if (productList[i].name.trim().toLowerCase() === pName) {
      prodIdx = i;
      exactProdName = productList[i].name.trim();
      break;
    }
  }

  // FORCE CORRECTION: Agar index loop se na mile to handle anyway
  if (prodIdx === -1) {
    Bot.sendMessage("⚠️ Product *" + exactProdName + "* lists me nahi mila, par system dynamic key store bypass generate kar raha hai...", { parse_mode: "Markdown" });
  } else {
    var plans = productList[prodIdx].plans || [];
    for (var j = 0; j < plans.length; j++) {
      if (String(plans[j].days).trim() === pDaysNumOnly) {
        planIdx = j;
        break;
      }
    }
  }

  // 3. Dual-pipeline saving mechanics
  var stockKeyText = "stock_" + exactProdName + "_" + pDaysClean;
  var currentStock = Bot.getProperty(stockKeyText) || [];
  
  // Array merging
  var updatedStock = currentStock.concat(keysToAdd);
  Bot.setProperty(stockKeyText, updatedStock, "json");

  // Agar structured index match hua hai to us pipeline ko bhi update karein
  if (prodIdx !== -1 && planIdx !== -1) {
    var stockKeyIndex = "stock_" + prodIdx + "_" + planIdx;
    Bot.setProperty(stockKeyIndex, updatedStock, "json");
  }

  // 4. GUARANTEED SUCCESS CONFIRMATION MESSAGE
  var successMsg = "<blockquote><b>📦 STOCK UPDATED SUCCESSFULLY</b>\n\n" +
                   "• <b>Product:</b> <code>" + exactProdName + "</code>\n" +
                   "• <b>Plan:</b> <code>" + pDaysClean + "</code>\n" +
                   "• <b>Added Keys:</b> <code>" + keysToAdd.length + " Keys</code>\n" +
                   "• <b>Total Stock Now:</b> <code>" + updatedStock.length + " Keys available</code></blockquote>";

  Bot.sendMessage(successMsg, { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}