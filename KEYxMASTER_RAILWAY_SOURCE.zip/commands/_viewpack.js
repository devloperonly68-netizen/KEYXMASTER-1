/**#command
name: /viewpack
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Command: /viewpack
if (user.telegramid !== "7088682169") {
  Bot.sendMessage("❌ Only Admin can use this.");
  return;
}

// 📂 AGAR BANDA SIRF /viewpack LIKHE (BINA PARAMS KE) -> TOH SARE PACKS KI LIST DIKHAO
if (!params) {
  // Global packs tracking list nikalna (Packs register karne ke liye /savepack me track hona zaroorat hota hai, 
  // ya fir hum 'premium_emojis' se nikal sakte hain)
  var emojis = Bot.getProperty("premium_emojis") || {};
  var uniquePacks = {};

  // Saare keys me se pack names extract karna (jaise pubg_1 -> pubg)
  for (var key in emojis) {
    var parts = key.split("_");
    if (parts.length > 1) {
      var pName = parts.slice(0, -1).join("_"); // handle names with multiple underscores
      uniquePacks[pName] = (uniquePacks[pName] || 0) + 1;
    } else {
      uniquePacks["global_single"] = (uniquePacks["global_single"] || 0) + 1;
    }
  }

  var packKeys = Object.keys(uniquePacks);

  if (packKeys.length === 0) {
    Bot.sendMessage("🚫 Koyi bhi Emoji Pack saved nahi hai. Pehle `/savepack` ka use karein.");
    return;
  }

  var allPacksMsg = "<blockquote><b>🗂️ ALL SAVED EMOJI PACKS</b></blockquote>\n\n";
  for (var j = 0; j < packKeys.length; j++) {
    var name = packKeys[j];
    var count = uniquePacks[name];
    allPacksMsg += "📦 <b>Pack Name:</b> <code>" + name + "</code>\n";
    allPacksMsg += "┗ 🔢 <b>Total Emojis:</b> <code>" + count + "</code>\n";
    allPacksMsg += "👉 <i>Open karne ke liye type karein:</i> `/viewpack " + name + "`\n\n";
  }

  Bot.sendMessage(allPacksMsg, { parse_mode: "HTML" });
  return;
}

// 🔍 AGAR BANDA /viewpack [PACK_NAME] LIKHE -> SPECIFIC PACK OPEN KRE
var packName = params.toLowerCase().trim();
var packStorage = Bot.getProperty("emoji_pack_" + packName);

// Fallback: Agar /savepack direct use nahi kiya par global list me data hai
if (!packStorage || packStorage.length === 0) {
  var globalEmojis = Bot.getProperty("premium_emojis") || {};
  packStorage = [];
  var indexCounter = 1;
  while (globalEmojis[packName + "_" + indexCounter]) {
    packStorage.push(globalEmojis[packName + "_" + indexCounter]);
    indexCounter++;
  }
}

if (!packStorage || packStorage.length === 0) {
  Bot.sendMessage("🚫 Pack **'" + packName + "'** nahi mila ya khali hai.", { parse_mode: "Markdown" });
  return;
}

var listMessage = "<blockquote><b>📦 PACK: " + packName.toUpperCase() + " (" + packStorage.length + " Emojis)</b></blockquote>\n\n";

for (var i = 0; i < packStorage.length; i++) {
  var id = packStorage[i];
  var visualEmoji = "<tg-emoji emoji-id='" + id + "'>✨</tg-emoji>";
  var index = i + 1;
  
  listMessage += visualEmoji + " <b>Code:</b> <code>{emj_" + packName + "_" + index + "}</code>\n";
  listMessage += "┗ <b>ID:</b> <code>" + id + "</code>\n\n";
}

Bot.sendMessage(listMessage, { parse_mode: "HTML" });