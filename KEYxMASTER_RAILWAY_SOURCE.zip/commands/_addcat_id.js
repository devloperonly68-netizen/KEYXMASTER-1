/**#command
name: /addcat_id
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169";
  if (!chat || String(chat.chatid) !== adminId) return;

  // 🛡️ CRASH FIX: Pehle check karenge ki message null toh nahi hai
  if (!message) {
    Bot.sendMessage("✍️ <b>Kripya Category ki details text me likh kar bhejiye!</b>\n\n<b>Sahi Format:</b>\n<code>/addcat_id [Emoji_ID] [Category Name]</code>\n\n<b>Example:</b>\n<code>/addcat_id 5323261730283863478 Facebook Id</code>", {parse_mode: "HTML"});
    return;
  }

  var cleanMessage = message.trim();

  // Command string removal
  if (cleanMessage.indexOf("/addcat_id") === 0) {
    cleanMessage = cleanMessage.replace("/addcat_id", "").trim();
  }

  var parts = cleanMessage.split(" ");
  if (parts.length < 2 || !parts[0] || isNaN(parts[0].substring(0, 3))) {
    Bot.sendMessage("⚠️ <b>Format Galat Hai!</b>\n\n<b>Sahi Format:</b>\n<code>[Emoji_ID] [Category Name]</code>\n\n<b>Example:</b>\n<code>5323261730283863478 Facebook Id</code>", {parse_mode: "HTML"});
    return;
  }

  var emojiId = parts[0].trim();
  var catName = parts.slice(1).join(" ").trim();
  
  // Dynamic safe slug creation
  var catSlug = catName.toLowerCase().replace(/[^a-z0-9]/g, "");

  var categories = Bot.getProperty("ff_categories");
  if (!categories || typeof categories !== "object") {
    categories = {};
  }

  // FIXED: Yahan emoji_id property save hogi jo menu script se synced hai
  categories[catSlug] = {
    name: catName,
    emoji_id: emojiId, 
    normal_price: 0,
    reseller_price: 0
  };

  Bot.setProperty("ff_categories", categories, "json");
  Bot.setProperty("ff_stock_" + catSlug, [], "json");

  Bot.sendMessage("✅ <b>Category Successfully Added!</b>\n\n• <b>Icon:</b> <tg-emoji emoji-id='" + emojiId + "'>✨</tg-emoji>\n• <b>Name:</b> <code>" + catName + "</code>\n• <b>Emoji ID:</b> <code>" + emojiId + "</code>\n• <b>System Slug:</b> <code>" + catSlug + "</code>\n\n<i>Ab aapka FF ID menu perfect chalega!</i>", {parse_mode: "HTML"});

} catch(e) {
  Bot.sendMessage("Error in Add Category: " + e.message);
}