/**#command
name: /cancel_topup
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var userId = user.telegramid;
  var callbackId = request ? request.id : (request.callback_query && request.callback_query.id);

  var qrMsgId = Bot.getProperty("qr_msg_id_" + userId) || User.getProperty("qr_msg_id_" + userId) || (request.message ? request.message.message_id : null);

  if (qrMsgId) {
    try { Api.deleteMessage({ chat_id: chat.chatid, message_id: qrMsgId }); } catch (e) {}
  }

  User.setProperty("pending_order_id", null);
  User.setProperty("deposit_amount", "0", "string");
  Bot.setProperty("qr_msg_id_" + userId, null, "string");
  User.setProperty("qr_msg_id_" + userId, null, "string");
  Bot.setProperty("qr_caption_" + userId, null, "string");
  User.setProperty("qr_caption_" + userId, null, "string");
  Bot.setProperty("qr_buttons_" + userId, null, "string");
  User.setProperty("qr_buttons_" + userId, null, "string");
  Bot.setProperty("qr_order_id_" + userId, null, "string");
  User.setProperty("qr_order_id_" + userId, null, "string");

  // ✅ Expiry-watcher ko disable karo taaki baad mein galat message edit na ho
  Bot.setProperty("qr_watch_order_" + userId, null, "string");
  User.setProperty("qr_watch_order_" + userId, null, "string");
  Bot.setProperty("verifying_lock_" + userId, false, "boolean");
  User.setProperty("verifying_lock_" + userId, false, "boolean");

  var cancelText = "<blockquote>" +
    "<tg-emoji emoji-id='6219547832169273793'>❌</tg-emoji> <b>Order Cancelled</b>\n" +
    "<tg-emoji emoji-id='6266994443262367483'>😊</tg-emoji> <i>Koi baat nahi, jab chaho phir se wallet me balance add kar sakte ho.</i>" +
    "</blockquote>";

  Api.sendMessage({
    chat_id: chat.chatid,
    text: cancelText,
    parse_mode: "HTML",
    reply_markup: JSON.stringify({
      inline_keyboard: [[
        { text: "Back to Menu", callback_data: "/back", style: "primary", icon_custom_emoji_id: "6057415823222379852" }
      ]]
    })
  });

  if (callbackId) {
    Api.answerCallbackQuery({ callback_query_id: String(callbackId) });
  }

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}