/**#command
name: /checkbal
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  // ✅ FIXED (v3): dynamic owner_id + co-admin check (same fix as /addbal).
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin) return;

  // ✅ FIXED: instantly ack the button press so it doesn't feel stuck/slow.
  if (request && request.id) {
    try {
      HTTP.post({
        url: "https://api.telegram.org/bot" + bot.token + "/answerCallbackQuery",
        body: { callback_query_id: request.id }
      });
    } catch (ackErr) {}
  }

  // Expected Usage: /checkbalance USER_ID
  var targetId = params ? params.trim() : null;

  // ✅ FIXED: same button-click bug as /addbal — ab prompt aata hai.
  if (!targetId || isNaN(targetId)) {
    User.setProperty("checkbal_step", "waiting_input", "string");
    Bot.sendMessage(
      "<tg-emoji emoji-id='6039605143601680423'>📊</tg-emoji> <b>Check Balance</b>\n\n" +
      "<i>Jis user ka balance check karna hai uski User ID reply karein:</i>\n<code>7088682169</code>",
      { parse_mode: "HTML" }
    );
    return;
  }

  // 👤 NAME & USERNAME DEFAULT FALLBACKS
  var name = "N/A";
  var username = "N/A";

  // Agar admin apni khud ki ID check kar raha hai tabhi user metadata direct load hoga
  if (String(targetId) === String(user.telegramid)) {
    name = user.first_name || "N/A";
    username = user.username ? "@" + user.username : "N/A";
  }

  // 💰 WALLET BALANCE REGISTERS FETCH
  var userResBalance = Libs.ResourcesLib.anotherUserRes("balance", targetId).value() || 0;
  var adminCustomBal = Bot.getProperty("balance" + targetId) || 0;
  var totalUserBal = (Number(userResBalance) + Number(adminCustomBal)).toFixed(2);

  // 📉 TOTAL EXPENSE NODE TRACKING (Total Invest mapping)
  var totalSpent = Bot.getProperty("total_spent_by_" + targetId) || 0;
  var formattedSpent = Number(totalSpent).toFixed(2);

  // 📄 FINAL RESPONSE BOX
  var messageText = "<blockquote><b><tg-emoji emoji-id='6039605143601680423'>📞</tg-emoji> USER ACCOUNT DETAILS</b>\n\n" +
                    "• <b>Name:</b> " + name + "\n" +
                    "• <b>Username:</b> " + username + "\n" +
                    "• <b>User ID:</b> <code>" + targetId + "</code>\n" +
                    "• <b>Balance:</b> <code>₹" + totalUserBal + "</code>\n" +
                    "• <b>Total Invest:</b> <code>₹" + formattedSpent + "</code></blockquote>";

  Bot.sendMessage(messageText, { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}