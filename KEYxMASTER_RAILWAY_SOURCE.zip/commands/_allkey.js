/**#command
name: /allkey
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169"; // Aapki Admin ID
  if (String(chat.chatid) !== adminId) return;

  var productList = [];
  try {
    productList = Bot.getProperty("stored_products") || [];
  } catch (err) {
    productList = [];
  }

  var inlineButtons = [];

  // 🛡️ SYSTEM SAFEGUARD: Agar master product data structural crash ho, to standard hardcoded check fallback lagana
  if (!productList || productList.length === 0) {
    // Agar empty list hai to manually display list paths
    inlineButtons.push([
      { text: "🔄 Load DRIP CLIENT (1 Day)", callback_data: "/view_keys_list DRIP CLIENT|1_Day" }
    ]);
  } else {
    // Standard dynamic listing execution loop
    for (var i = 0; i < productList.length; i++) {
      var product = productList[i];
      if (!product || !product.name) continue;

      var plans = product.plans || [];
      // Default configurations display if plans empty
      if (plans.length === 0) {
        plans = [{ days: "1" }, { days: "7" }];
      }

      for (var j = 0; j < plans.length; j++) {
        var plan = plans[j];
        if (!plan || !plan.days) continue;
        
        var cleanProdName = product.name.trim();
        var cleanPlanDays = String(plan.days).trim() + "_Day";
        
        var stockKeyText = "stock_" + cleanProdName + "_" + cleanPlanDays;
        var currentStock = Bot.getProperty(stockKeyText) || [];

        inlineButtons.push([
          {
            text: cleanProdName.toUpperCase() + " (" + plan.days + " Days) - [" + currentStock.length + " Keys]",
            callback_data: "/view_keys_list " + cleanProdName + "|" + cleanPlanDays
          }
        ]);
      }
    }
  }

  // Final menu check interface safety attachment
  if (inlineButtons.length === 0) {
    inlineButtons.push([{ text: "🔄 Refresh Stock Matrix", callback_data: "/allkey" }]);
  }

  var menuText = "<blockquote><b>🔑 GLOBAL STOCK AUDIT LOGS</b>\n\n" +
                 "<i>Niche diye gaye buttons me product aur uske plan ka live stock status dikh raha hai. Saari keys dekhne ke liye click karein:</i></blockquote>";

  Bot.sendMessage(menuText, {
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: inlineButtons })
  });

} catch (err) {
  Bot.sendMessage("⚠️ Master Inventory Render Error: " + err.message);
}