/**#command
name: /apiset
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var ownerId=String(Bot.getProperty("owner_id")||"7088682169"), uid=String(chat.chatid), co=Bot.getProperty("co_admin_"+uid);
  if(uid!==ownerId && !co) return;
  var id=params?String(params).trim():"", reg=Bot.getProperty("api_registry")||{};
  if(!id || !reg[id]){Bot.sendMessage("❌ Use <code>/apiset API_ID</code>",{parse_mode:"HTML"});return;}
  if(reg[id].enabled===false){Bot.sendMessage("❌ This API is disabled.");return;}
  Bot.setProperty("active_reseller_api",id,"string");
  Bot.sendMessage("✅ Active reseller API set to <code>"+id+"</code>\nAll external reseller purchases will use this API.",{parse_mode:"HTML"});
} catch(e){Bot.sendMessage("⚠️ API Set Error: "+e.message);}
