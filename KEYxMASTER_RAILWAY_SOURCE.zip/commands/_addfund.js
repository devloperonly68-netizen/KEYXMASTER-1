/**#command
name: /addfund
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 💰 COMMAND = Initial Deposit Keypad Setup
// STATUS: ✅ PREMIUM CALCULATOR UI — colored buttons + premium emojis
// (kept in sync with /press.js so the screen never "flickers"/changes
// style when the user presses the first digit)
// =========================================================

try {
  // Amount ko shuru me 0 set karein
  User.setProperty("deposit_amount", "0", "string");

  // 💎 Premium Emoji Set — user-provided premium IDs applied across this screen
  let e_money   = "<tg-emoji emoji-id='6312263493051489212'>💰</tg-emoji>";
  let e_clear   = "<tg-emoji emoji-id='5348224471050238603'>✏</tg-emoji>";
  let e_confirm = "<tg-emoji emoji-id='5348191451341668809'>✅</tg-emoji>";
  let e_back    = "<tg-emoji emoji-id='5893163582194978381'>⬅️</tg-emoji>";
  let e_hour    = "<tg-emoji emoji-id='6100657257605763582'>✔️</tg-emoji>";
  let e_check   = "<tg-emoji emoji-id='6311870645277825763'>✔️</tg-emoji>";

  // 🎨 Main message — premium "Enter Custom Amount" calculator screen
  let msg =
    "<blockquote>" + e_money + " <b>ADD BALANCE — ENTER AMOUNT</b> <tg-emoji emoji-id='6312263493051489212'>💎</tg-emoji></blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "<tg-emoji emoji-id='6312263493051489212'>💎</tg-emoji> <b>Amount:</b> ₹<code>0</code>\n\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n" +
    e_check + " <i>Instant Auto-Credit</i>\n" +
    "<tg-emoji emoji-id='6215386799133433653'>🔒</tg-emoji> <i>100% Secure UPI Payment</i>\n" +
    e_hour + " <i>Verified in Seconds</i>\n\n" +
    "<tg-emoji emoji-id='6100170496077204999'>👑</tg-emoji> <i>Use the keypad below to enter amount</i>";

  // 🎨 Styled keyboard payload — blue number pad, red clear/back, green confirm
  let keyboard = [
    [
      { text: "1", callback_data: "/press 1", style: "primary" },
      { text: "2", callback_data: "/press 2", style: "primary" },
      { text: "3", callback_data: "/press 3", style: "primary" }
    ],
    [
      { text: "4", callback_data: "/press 4", style: "primary" },
      { text: "5", callback_data: "/press 5", style: "primary" },
      { text: "6", callback_data: "/press 6", style: "primary" }
    ],
    [
      { text: "7", callback_data: "/press 7", style: "primary" },
      { text: "8", callback_data: "/press 8", style: "primary" },
      { text: "9", callback_data: "/press 9", style: "primary" }
    ],
    [
      { text: "Clear", callback_data: "/press clear", style: "danger", icon_custom_emoji_id: "5348224471050238603" },
      { text: "0", callback_data: "/press 0", style: "primary" },
      { text: "Confirm", callback_data: "/press confirm", style: "success", icon_custom_emoji_id: "5348191451341668809" }
    ],
    [
      { text: "Back", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
    ]
  ];

  // 'request.message' check karta hai ki kya ye kisi button click se trigger hua hai
  // ✅ BUG FIX: agar previous message ek PHOTO thi (jaise DP-attached Profile),
  // editMessageText kaam nahi karta — isi wajah se Profile se "Add Fund" click
  // karne par deposit screen aati hi nahi thi. Ab photo ho to delete + fresh send.
  if (request && request.message && request.message.message_id) {
    if (request.message.photo) {
      try { Api.deleteMessage({ chat_id: chat.chatid, message_id: request.message.message_id }); } catch (delErr) {}
      Api.sendMessage({
        chat_id: chat.chatid,
        text: msg,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: keyboard })
      });
    } else {
      // Alag se naya message nahi bhejega, usi menu ko edit karke keypad bana dega
      Api.editMessageText({
        chat_id: chat.chatid,
        message_id: request.message.message_id,
        text: msg,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: keyboard })
      });
    }
  } else {
    // Agar direct command run hua toh naya message bhejega safety ke liye
    Api.sendMessage({
      chat_id: chat.chatid,
      text: msg,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: keyboard })
    });
  }

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}