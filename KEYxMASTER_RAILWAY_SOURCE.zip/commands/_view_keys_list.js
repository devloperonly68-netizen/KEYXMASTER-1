/**#command
name: /view_keys_list
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169";
  if (String(chat.chatid) !== adminId) return;

  var callbackId = request ? request.id : null;
  var dataStr = params ? params.trim() : "";
  
  if (!dataStr) {
    var cbData = request && request.callback_query ? request.callback_query.data : "";
    dataStr = cbData.replace("/view_keys_list ", "");
  }

  if (!dataStr) {
    if (callbackId) Api.answerCallbackQuery({ callback_query_id: callbackId, text: "❌ Empty execution data string!", show_alert: true });
    return;
  }

  var parts = dataStr.split("|");
  var prodName = parts[0].trim();
  var cleanPlanDays = parts[1].trim();

  // Fetch from key properties tables
  var stockKeyText = "stock_" + prodName + "_" + cleanPlanDays;
  var keyStock = Bot.getProperty(stockKeyText) || [];

  if (keyStock.length === 0) {
    if (callbackId) {
      Api.answerCallbackQuery({ callback_query_id: callbackId, text: "❌ Is plan me currently 0 keys hain!", show_alert: true });
    } else {
      Bot.sendMessage("❌ Stock empty for: " + prodName + " (" + cleanPlanDays + ")");
    }
    return;
  }

  var reportText = "<blockquote><b>🔑 LIVE ACTIVE KEYS LIST</b>\n\n" +
                   "• <b>Product:</b> <code>" + prodName.toUpperCase() + "</code>\n" +
                   "• <b>Plan:</b> <code>" + cleanPlanDays + "</code>\n" +
                   "• <b>Total Available:</b> <code>" + keyStock.length + " Keys</code>\n" +
                   "━━━━━━━━━━━━━━━━━━━━━━━━━━\n";

  for (var i = 0; i < keyStock.length; i++) {
    reportText += (i + 1) + ". <code>" + keyStock[i] + "</code>\n";
  }
  
  reportText += "</blockquote>";

  var inlineButtons = [
    [
      { text: "⬅️ Back to Stock List", callback_data: "/allkey" }
    ]
  ];

  if (request && request.message) {
    HTTP.post({
      url: "https://api.telegram.org/bot" + bot.token + "/editMessageText",
      body: {
        chat_id: String(chat.chatid),
        message_id: Number(request.message.message_id),
        text: reportText,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: inlineButtons })
      }
    });
  } else {
    Bot.sendMessage(reportText, { parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: inlineButtons }) });
  }

  if (callbackId) {
    Api.answerCallbackQuery({ callback_query_id: callbackId, text: "Keys fetched!" });
  }

} catch (err) {
  Bot.sendMessage("⚠️ Rendering Keys List Mismatch: " + err.message);
}