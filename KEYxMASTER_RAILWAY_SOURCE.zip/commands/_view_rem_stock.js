/**#command
name: /view_rem_stock
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169";
  if (String(chat.chatid) !== adminId) return;

  // Callback data se slug nikalna
  var slug = params ? params.trim() : "";
  if (!slug) return;

  var currentStock = Bot.getProperty("ff_stock_" + slug) || [];
  var categories = Bot.getProperty("ff_categories") || {};
  var catName = categories[slug] && categories[slug].name ? categories[slug].name : slug.toUpperCase();

  if (!Array.isArray(currentStock) || currentStock.length === 0) {
    Bot.sendMessage("📭 <b>" + catName + "</b> me abhi koi stock mojud nahi hai.", {parse_mode: "HTML"});
    return;
  }

  var keyboard = [];
  
  // Har ek account ke liye ek button banayein
  for (var i = 0; i < currentStock.length; i++) {
    var accountData = currentStock[i]; // Format: email|pass|price
    
    keyboard.push([
      { 
        text: "❌ " + accountData, 
        callback_data: "/confirm_rem_stock " + slug + " " + i 
      }
    ]);
  }

  // Wapis main list par jaane ke liye Back button
  keyboard.push([{ text: "🔙 Back to Categories", callback_data: "/remstock_id" }]);

  Api.sendMessage({
    chat_id: adminId,
    text: "🛒 <b>" + catName + " Stock List:</b>\n\n<i>Niche diye gaye kisi bhi account button par click karke use delete karein:</i>",
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: keyboard })
  });

} catch (e) {
  Bot.sendMessage("Error: " + e.message);
}