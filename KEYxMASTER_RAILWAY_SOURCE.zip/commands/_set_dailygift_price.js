/**#command
name: /set_dailygift_price
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🔧 ADMIN — Configure the /dailygift fixed reward amount
// Usage: /set_dailygift_price 5
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin0 = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  if (!params || params.trim() === "") {
    var currentAmount = Bot.getProperty("daily_gift_amount");
    if (currentAmount === undefined || currentAmount === null) currentAmount = "1 (default)";
    Bot.sendMessage(
      "⚠️ <b>Format:</b> <code>/set_dailygift_price 5</code>\n\n" +
      "<b>Current amount:</b> ₹<code>" + currentAmount + "</code>",
      { parse_mode: "HTML" }
    );
    return;
  }

  var newAmount = Number(params.trim());
  if (isNaN(newAmount) || newAmount <= 0) {
    Bot.sendMessage("❌ Invalid amount! Sirf positive number bhejein, jaise: <code>5</code>", { parse_mode: "HTML" });
    return;
  }

  Bot.setProperty("daily_gift_amount", newAmount, "number");
  Bot.sendMessage(
    "✅ <b>Daily Gift amount update ho gaya:</b> ₹" + newAmount.toFixed(2) + "\n\n<i>Ab har user ko is naye amount ka Daily Gift milega.</i>",
    { parse_mode: "HTML" }
  );

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
