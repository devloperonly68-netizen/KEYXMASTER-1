/**#command
name: /normalprice
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169";
  if (String(chat.chatid) !== adminId) return;

  // Expected Format: pubg_mobile | 1_Day | 120
  if (!params) {
    Bot.sendMessage("❌ <b>Usage:</b>\n<code>/normalprice product_name | days | price</code>\n\n<i>Example: pubg_mobile | 1_Day | 120</i>", { parse_mode: "HTML" });
    return;
  }

  // Pipe '|' symbol ke hisab se text ko split karna
  var args = params.split("|");

  if (args.length < 3) {
    Bot.sendMessage("❌ <b>Incorrect Format!</b> Use Pipe symbol:\n<code>/setnormalprice product_name | days | price</code>", { parse_mode: "HTML" });
    return;
  }

  // Spaces remove karna trim() use karke
  var prodName = args[0].trim();
  var planName = args[1].trim();
  var price = args[2].trim();

  if (!prodName || !planName || !price || isNaN(price)) {
    Bot.sendMessage("❌ Invalid price number or structure. Double check inputs!", { parse_mode: "HTML" });
    return;
  }

  // Database standard configurations me save karna
  Bot.setProperty("price_normal_" + prodName + "_" + planName, Number(price), "float");

  var successText = "<blockquote><b><tg-emoji emoji-id='6064514463564831610'>💟</tg-emoji> NORMAL PRICE UPDATED</b>\n\n" +
                    "• <b>Product:</b> <code>" + prodName + "</code>\n" +
                    "• <b>Validity/Days:</b> <code>" + planName + "</code>\n" +
                    "• <b>New Price:</b> <code>₹" + Number(price).toFixed(2) + "</code></blockquote>";

  Bot.sendMessage(successText, { parse_mode: "HTML" });

} catch (err) { 
  Bot.sendMessage("Error: " + err.message); 
}