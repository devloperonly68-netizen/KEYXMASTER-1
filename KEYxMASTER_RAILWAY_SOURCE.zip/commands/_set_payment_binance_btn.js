/**#command
name: /set_payment_binance_btn
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🟡 ADMIN PANEL BUTTON — "Set Payment (Binance Pay)"
// 4-step wizard: QR (photo or URL) -> Binance Pay ID -> USDT Address -> USD rate.
// _start.js MODULE 4b handles each reply.
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var currentChatId = String(chat.chatid);
  var isCoAdmin = Bot.getProperty("co_admin_" + currentChatId);

  if (currentChatId !== adminId && !isCoAdmin) {
    Bot.sendMessage("❌ You are not authorized to use this.");
    return;
  }

  var currentQr = Bot.getProperty("binance_qr_file_id") || Bot.getProperty("binance_qr_url");
  var currentBinanceId = Bot.getProperty("binance_pay_id") || "Not set";
  var currentUsdtAddr = Bot.getProperty("binance_usdt_address") || "Not set";
  var currentRate = Bot.getProperty("usd_rate") || "91 (default)";

  User.setProperty("set_payment_binance_step", "waiting_qr", "string");

  var promptText =
    "<blockquote><tg-emoji emoji-id='6312263493051489212'>🟡</tg-emoji> <b>Set Payment (Binance Pay)</b></blockquote>\n\n" +
    "<i>Step 1/4 —</i> Ab apna Binance Pay <b>QR Code</b> bhejein.\n" +
    "<i>Ya toh QR ki <b>photo</b> bhejein, ya QR image ka <b>direct URL link</b> paste kar dein.</i>\n\n" +
    "<b>Current QR:</b> " + (currentQr ? "✅ Already set" : "❌ Not set") + "\n" +
    "<b>Current Binance Pay ID:</b> <code>" + currentBinanceId + "</code>\n" +
    "<b>Current USDT Address:</b> <code>" + currentUsdtAddr + "</code>\n" +
    "<b>Current USD Rate:</b> <code>₹" + currentRate + " = $1</code>";

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;

  if (request && request.message && request.message.message_id) {
    try {
      Api.editMessageText({
        chat_id: String(chat.chatid),
        message_id: Number(request.message.message_id),
        text: promptText,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "Cancel", callback_data: "/admin", style: "danger" }]] })
      });
    } catch (e) {
      Api.sendMessage({ chat_id: chat.chatid, text: promptText, parse_mode: "HTML" });
    }
  } else {
    Bot.sendMessage(promptText, { parse_mode: "HTML" });
  }

  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
