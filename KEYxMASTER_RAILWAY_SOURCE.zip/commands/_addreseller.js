/**#command
name: /addreseller
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin0 = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) return;

  // Input se User ID nikalna
  var targetId = params ? params.trim() : null;

  if (!targetId) {
    Bot.sendMessage("❌ <b>Usage:</b> <code>/addreseller 123456789</code>", { parse_mode: "HTML" });
    return;
  }

  // Pehle check karein ki kya wo user pehle se reseller hai
  var alreadyReseller = Bot.getProperty("is_reseller_" + targetId);

  if (alreadyReseller === true) {
    Bot.sendMessage("<tg-emoji emoji-id='5346024644635804737'>🔰</tg-emoji> Yeh user (<code>" + targetId + "</code>) <b>pehle se hi Reseller hai!</b>", { parse_mode: "HTML" });
    return; // Code yahan ruk jayega
  }

  // Agar reseller nahi hai, to save karein
  Bot.setProperty("is_reseller_" + targetId, true, "boolean");

  Bot.sendMessage("<tg-emoji emoji-id='6064138396228392033'>✅</tg-emoji> User <code>" + targetId + "</code> successfully reseller role me add ho gaya hai!", { parse_mode: "HTML" });

  // Reseller ko premium notification bhejna
  var notifText = "<blockquote><b><tg-emoji emoji-id='6064138396228392033'>✨</tg-emoji> CONGRATULATIONS <tg-emoji emoji-id='6064138396228392033'>✨</tg-emoji></b>\n\n" +
                  "<tg-emoji emoji-id='5346024644635804737'>🔰</tg-emoji> You Are Now A Reseller.\n" +
                  "Check Your Discounted Store /start To Check Now<tg-emoji emoji-id='6298298582982199311'>💰</tg-emoji></blockquote>";
                  
  Api.sendMessage({
    chat_id: targetId,
    text: notifText,
    parse_mode: "HTML"
  });

} catch (err) {
  Bot.sendMessage("Error: " + err.message);
}