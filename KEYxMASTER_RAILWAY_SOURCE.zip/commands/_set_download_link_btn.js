/**#command
name: /set_download_link_btn
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🔗 ADMIN PANEL BUTTON — "Set Download Link"
// Pressing this button prompts the admin to just send the link as
// a normal text message next; _start.js (MODULE 5) auto-captures
// that reply and forwards it to /set_update_link internally.
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var currentChatId = String(chat.chatid);
  var isCoAdmin = Bot.getProperty("co_admin_" + currentChatId);

  if (currentChatId !== adminId && !isCoAdmin) {
    Bot.sendMessage("❌ You are not authorized to use this.");
    return;
  }

  var currentLink = Bot.getProperty("update_channel_link") || "Not set";

  User.setProperty("set_download_link_step", "waiting_input", "string");

  var promptText =
    "<blockquote><tg-emoji emoji-id='6080214566191505147'>🔗</tg-emoji> <b>Set Download Files Link</b></blockquote>\n\n" +
    "<i>Send the link (http/https) you want the \"Download Files\" button to open. It will be sent as the next message.</i>\n\n" +
    "<b>Current link:</b> " + currentLink;

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;

  if (request && request.message && request.message.message_id) {
    try {
      Api.editMessageText({
        chat_id: String(chat.chatid),
        message_id: Number(request.message.message_id),
        text: promptText,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "Cancel", callback_data: "/admin", style: "danger" }]] })
      });
    } catch (e) {
      Api.sendMessage({ chat_id: chat.chatid, text: promptText, parse_mode: "HTML" });
    }
  } else {
    Bot.sendMessage(promptText, { parse_mode: "HTML" });
  }

  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
