/**#command
name: /onBuyCheck
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

function resolveApiDuration(plan, cleanPlanDays, planUnit) {
  var raw = String((plan && (plan.api_duration || plan.name_on_website || plan.durationDisplay || plan.name || plan.title)) || "").replace(/\s+/g, " ").trim();
  var canonical = ["1 DaYS NONROOT","House","1 DaYs","15 DaYs All Colours Mix","30 DaYs PRO","1 DaYs Basic","1 Year Ios Esign Gbox Certificate","1 DaYs Root + Nonroot","7 DaYS PC AIMKILL","30 Day Pc Modmenu x86","3 DaYs SAFE","3 DaYs BRUTAL"];
  for (var i=0;i<canonical.length;i++) if (raw.toLowerCase() === canonical[i].toLowerCase()) return canonical[i];
  var gd=raw.match(/^([0-9]+(?:\.[0-9]+)?)\s*(day|days)$/i);
  if(gd) return Number(gd[1])===1 ? "1 DaYs" : gd[1]+" Days";
  // HOURS: preserve the exact duration entered by admin/API.
  // Examples: "1 Hours", "2 Hours", "12 Hours" all remain unchanged.
  var gh=raw.match(/^([0-9]+(?:\.[0-9]+)?)\s*(hour|hours)$/i);
  if(gh) return raw;
  var gm=raw.match(/^([0-9]+(?:\.[0-9]+)?)\s*(minute|minutes)$/i);
  if(gm) return gm[1]+(Number(gm[1])===1?" Minute":" Minutes");
  return raw || (Number(cleanPlanDays||"1")===1 ? "1 DaYs" : String(cleanPlanDays)+" Days");
}


try {
  var userId = user.telegramid;

  // ✅ CRITICAL FIX: Proper atomic duplicate-payment prevention
  var utrFromContent = null;
  
  // Parse content to get UTR early
  if (content) {
    var res = (typeof content === "object") ? content : JSON.parse(content);
    if (res && res.data && res.data.utr) {
      utrFromContent = res.data.utr;
    }
  }

  // 🛑 STEP 1: Check if payment already processed using UTR (most reliable identifier)
  if (utrFromContent && Bot.getProperty("paid_" + utrFromContent)) {
    // ✅ FIX: Vanish the QR completely instead of leaving a stale "already used" caption behind
    try {
      Api.deleteMessage({ chat_id: chat.chatid, message_id: request.message.message_id });
    } catch (e) {}

    try {
      Bot.setProperty("buy_qr_msg_id_" + userId, null, "string");
      User.setProperty("buy_qr_msg_id_" + userId, null, "string");
    } catch (e) {}

    if (request && request.id) {
      try {
        Api.answerCallbackQuery({
          callback_query_id: String(request.id),
          text: "✅ ALREADY CLAIMED ✅\nYe order pehle hi deliver ho chuka hai.",
          show_alert: true
        });
      } catch (e) {}
    }

    Api.sendMessage({
      chat_id: chat.chatid,
      text: "<blockquote><tg-emoji emoji-id='5330237710655306682'>✅</tg-emoji> <b>ORDER ALREADY CLAIMED</b>\n<i>Ye payment pehle hi verify ho kar item deliver ho chuka hai. Apni keys 'All History' me check karein.</i></blockquote>",
      parse_mode: "HTML",
      reply_markup: JSON.stringify({
        inline_keyboard: [[
          { text: "📜 My Keys", callback_data: "/mykey", style: "primary" },
          { text: "🛒 Shop Menu", callback_data: "/buy_hack", style: "success" }
        ]]
      })
    });
    return;
  }

  // 🛑 STEP 2: Duplicate-click lock check
  var isChecking = User.getProperty("buy_verifying_lock_" + userId);
  if (isChecking) {
    if (request && request.id) {
      Api.answerCallbackQuery({
        callback_query_id: String(request.id),
        text: "⏳ ALREADY CHECKING — PLEASE WAIT...",
        show_alert: true
      });
    }
    return;
  }
  
  // 🛑 STEP 3: SET LOCK IMMEDIATELY before any async operations
  User.setProperty("buy_verifying_lock_" + userId, true, "boolean");

  if (!content) {
    Api.editMessageCaption({
      chat_id: chat.chatid, message_id: request.message.message_id,
      caption: "<blockquote>⚠️ <b>Server didn't respond.</b>\nClick 'I have paid' again.</blockquote>", parse_mode: "HTML"
    });
    User.setProperty("buy_verifying_lock_" + userId, false, "boolean");
    return;
  }

  var res = (typeof content === "object") ? content : JSON.parse(content);

  if (res.status === "success" && res.data) {
    var utr = res.data.utr;
    var isPaid = Bot.getProperty("paid_" + utr);

    if (isPaid) {
      // ✅ FIX: Vanish the QR completely instead of leaving a stale "already used" caption behind
      try {
        Api.deleteMessage({ chat_id: chat.chatid, message_id: request.message.message_id });
      } catch (e) {}

      try {
        Bot.setProperty("buy_qr_msg_id_" + userId, null, "string");
        User.setProperty("buy_qr_msg_id_" + userId, null, "string");
      } catch (e) {}

      if (request && request.id) {
        try {
          Api.answerCallbackQuery({
            callback_query_id: String(request.id),
            text: "✅ ALREADY CLAIMED ✅\nYe order pehle hi deliver ho chuka hai.",
            show_alert: true
          });
        } catch (e) {}
      }

      Api.sendMessage({
        chat_id: chat.chatid,
        text: "<blockquote><tg-emoji emoji-id='5330237710655306682'>✅</tg-emoji> <b>ORDER ALREADY CLAIMED</b>\n<i>Ye payment pehle hi verify ho kar item deliver ho chuka hai. Apni keys 'All History' me check karein.</i></blockquote>",
        parse_mode: "HTML",
        reply_markup: JSON.stringify({
          inline_keyboard: [[
            { text: "📜 My Keys", callback_data: "/mykey", style: "primary" },
            { text: "🛒 Shop Menu", callback_data: "/buy_hack", style: "success" }
          ]]
        })
      });
      User.setProperty("buy_verifying_lock_" + userId, false, "boolean");
      return;
    }
    
    // ✅ IMMEDIATELY mark as paid BEFORE any async API calls to prevent race condition
    Bot.setProperty("paid_" + utr, true, "boolean");

    Api.editMessageCaption({
      chat_id: chat.chatid, message_id: request.message.message_id,
      caption: "<tg-emoji emoji-id='6192822213486321961'>🔄</tg-emoji> <b>Payment verified! Delivering your key...</b>",
      parse_mode: "HTML"
    });

    // ✅ FIX: Detect which purchase pipeline this QR payment belongs to.
    // "ffid" = local stock-based FF ID item (set by /execute_id_buy on low balance)
    // default/"plan" = original plan-based product via external xyzcheats API
    var flowType = User.getProperty("buy_flow_type") || "plan";

    if (flowType === "ffid") {
      // =========================================================
      // 🎮 FF ID STOCK DELIVERY (after successful QR payment)
      // =========================================================
      try {
        var rawType = User.getProperty("buy_ffid_rawtype") || "";
        var isResellerFlow = User.getProperty("buy_ffid_is_reseller") === true;
        var finalCost = Number(User.getProperty("buy_price") || 0);
        var displayTypeName = User.getProperty("buy_prod_name") || rawType;

        var stockData = [];
        var isDynamicCategory = false;
        var isGeneralCategory = false;
        var selectedCat = null;

        var fbCategories = Bot.getProperty("fb_categories") || [];
        if (!Array.isArray(fbCategories)) { fbCategories = []; }

        if (rawType.indexOf("fb_") === 0) {
          isDynamicCategory = true;
          var targetCatId = rawType.replace("fb_", "").trim();
          for (var i = 0; i < fbCategories.length; i++) {
            if (fbCategories[i].id === targetCatId) { selectedCat = fbCategories[i]; break; }
          }
          if (selectedCat) { stockData = selectedCat.stock_list || []; }
        } else if (rawType === "fb" || rawType === "google") {
          stockData = Bot.getProperty("ff_stock_" + rawType) || [];
        } else {
          isGeneralCategory = true;
          var categoriesFF = Bot.getProperty("ff_categories") || {};
          selectedCat = categoriesFF[rawType];
          if (selectedCat) {
            var fallbackStock = Bot.getProperty("ff_stock_" + rawType) || [];
            stockData = (selectedCat.stock_list && selectedCat.stock_list.length > 0) ? selectedCat.stock_list : fallbackStock;
          }
        }

        if (!stockData || stockData.length === 0) {
          Api.editMessageCaption({
            chat_id: chat.chatid, message_id: request.message.message_id,
            caption: "⚠️ Payment received but item went out of stock. Contact admin with UTR: " + utr,
            parse_mode: "HTML"
          });
          User.setProperty("buy_verifying_lock_" + userId, false, "boolean");
          return;
        }

        var accountExtracted = stockData.shift();

        if (isDynamicCategory && selectedCat) {
          selectedCat.stock_list = stockData;
          Bot.setProperty("fb_categories", fbCategories, "json");
        } else if (isGeneralCategory && selectedCat) {
          selectedCat.stock_list = stockData;
          var categoriesFF2 = Bot.getProperty("ff_categories") || {};
          categoriesFF2[rawType] = selectedCat;
          Bot.setProperty("ff_categories", categoriesFF2, "json");
          Bot.setProperty("ff_stock_" + rawType, stockData, "json");
        } else {
          Bot.setProperty("ff_stock_" + rawType, stockData, "json");
        }

        var fullRawString = String(accountExtracted || "").trim();
        var emailData = fullRawString;
        var passwordData = "No Password Found";

        if (fullRawString.indexOf("|") !== -1) {
          var lastPipeIndex = fullRawString.lastIndexOf("|");
          var firstPart = fullRawString.substring(0, lastPipeIndex).trim();
          var secondPart = fullRawString.substring(lastPipeIndex + 1).trim();

          if (firstPart.indexOf(" ") !== -1) {
            var spaceParts = firstPart.split(" ");
            emailData = spaceParts[spaceParts.length - 1].trim();
          } else {
            emailData = firstPart;
          }
          passwordData = secondPart;
        }

        var purchasedKeys = User.getProperty("my_purchased_keys") || [];
        if (!Array.isArray(purchasedKeys)) { purchasedKeys = []; }
        var currentDate = new Date().toLocaleDateString('en-IN', { timeZone: "Asia/Kolkata" });
        purchasedKeys.push({
          productName: displayTypeName,
          cost: finalCost.toString(),
          key: emailData + (passwordData !== "No Password Found" ? " | " + passwordData : ""),
          days: "Permanent",
          date: currentDate
        });
        User.setProperty("my_purchased_keys", purchasedKeys, "json");

        var deliveryText =
          "┏━━━━━━━━━━━━━━━━━━━━━━━━┓\n" +
          "┃ ❤️‍🔥 <b>PURCHASE SUCCESSFUL!</b> ❤️‍🔥 ┃\n" +
          "┗━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n" +
          "📦 <b>Item:</b> <code>" + displayTypeName + "</code>\n" +
          "💰 <b>Paid:</b> <code>₹" + finalCost + "</code> " + (isResellerFlow ? "<b>(Reseller)</b>" : "") + "\n" +
          "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
          "👤 <b>ACCOUNT DETAILS:</b>\n\n" +
          "🚀 <b>Email:</b> <code>" + emailData + "</code>\n" +
          "🔒 <b>Password:</b> <code>" + passwordData + "</code>\n" +
          "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
          "⚠️ <i>Copy details instantly.</i>";

        Api.sendMessage({
          chat_id: chat.chatid,
          text: deliveryText,
          parse_mode: "HTML"
        });

        var adminLogChannel = "7088682169";
        var adminNotificationMsg =
          "<blockquote>⚠️ <b>NEW ORDER ALERT (QR)</b>" + (isResellerFlow ? " [RESELLER]" : "") + "</blockquote>\n" +
          "👤 <b>User:</b> <a href='tg://user?id=" + userId + "'>" + user.first_name + "</a> (<code>" + userId + "</code>)\n" +
          "📦 <b>Item:</b> <code>" + displayTypeName + "</code>\n" +
          "💰 <b>Revenue:</b> <code>₹" + finalCost + "</code>\n" +
          "⚡ <b>Stock Left:</b> <code>" + stockData.length + " units</code>\n\n" +
          "🖥 <b>ACCOUNT DETAILS:</b>\n" +
          "➔ <b>Email:</b> <code>" + emailData + "</code>\n" +
          "➔ <b>Password:</b> <code>" + passwordData + "</code>";

        Api.sendMessage({
          chat_id: adminLogChannel,
          text: adminNotificationMsg,
          parse_mode: "HTML"
        });

        // Cleanup all buy_ state for this order
        User.setProperty("buy_flow_type", null, "string");
        User.setProperty("buy_ffid_rawtype", null, "string");
        User.setProperty("buy_ffid_is_reseller", null, "boolean");
        User.setProperty("buy_price", null, "number");
        User.setProperty("buy_needpay", null, "number");
        User.setProperty("buy_prod_name", null, "string");
        User.setProperty("buy_plan_unit", null, "string");
        User.setProperty("buy_plan_name_on_website", null, "string");
        User.setProperty("buy_pending_order_id", null);
        Bot.setProperty("buy_qr_msg_id_" + userId, null, "string");
        User.setProperty("buy_qr_msg_id_" + userId, null, "string");
        Bot.setProperty("buy_qr_caption_" + userId, null, "string");
        User.setProperty("buy_qr_caption_" + userId, null, "string");
        Bot.setProperty("buy_qr_buttons_" + userId, null, "string");
        User.setProperty("buy_qr_buttons_" + userId, null, "string");

      } catch (ffErr) {
        Api.editMessageCaption({
          chat_id: chat.chatid, message_id: request.message.message_id,
          caption: "⚠️ Delivery error. Contact admin with UTR: " + utr + " | Error: " + ffErr.message,
          parse_mode: "HTML"
        });
      }
      User.setProperty("buy_verifying_lock_" + userId, false, "boolean");
      return;
    }

    // =========================================================
    // 📦 ORIGINAL PLAN-BASED DELIVERY (external xyzcheats API)
    // =========================================================
    var prodIdx = User.getProperty("buy_prod_idx");
    var planIdx = User.getProperty("buy_plan_idx");
    var productList = Bot.getProperty("stored_products") || [];
    var product = productList[prodIdx];
    var plan = product && product.plans ? product.plans[planIdx] : null;

    if (!product || !plan) {
      Api.editMessageCaption({
        chat_id: chat.chatid, message_id: request.message.message_id,
        caption: "⚠️ Payment received but product data missing. Contact admin with UTR: " + utr,
        parse_mode: "HTML"
      });
      User.setProperty("buy_verifying_lock_" + userId, false, "boolean");
      return;
    }

    var webProductId = String(product.id || "PID_ID").trim();
    var cleanPlanDays = User.getProperty("buy_plan_days") || String(plan.days);
    var planUnit = User.getProperty("buy_plan_unit") || plan.unit || "day";
    var prodNameLower = String(product.name).toLowerCase();
    var durationParam = resolveApiDuration(plan, cleanPlanDays, planUnit);

    // 🔌 Use configured multi-API system instead of a hardcoded API.
    var apiRegistry = Bot.getProperty("api_registry") || {};
    var activeApiId = Bot.getProperty("active_reseller_api") || "";
    var selectedApi = activeApiId ? apiRegistry[activeApiId] : null;
    if (!selectedApi) {
      selectedApi = { id:"default", url:"https://xyzcheats.com/api/reseller_v1.php", api_key:process.env.RESELLER_API_KEY || "", master_key:process.env.RESELLER_MASTER_KEY || "", android_required:false, enabled:true };
    }
    if (selectedApi.enabled === false) {
      Bot.sendMessage("❌ Selected API is disabled. Admin ko /apiset se active API select karna hoga.");
      return;
    }
    var postFields = { api_key:selectedApi.api_key || "", action:"buy", product_id:webProductId, duration:durationParam };
    var savedAndroidId = User.getProperty("android_id") || User.getProperty("android_id_" + userId) || Bot.getProperty("android_id_" + userId) || "";
    if (selectedApi.android_required && !savedAndroidId) {
      Bot.sendMessage("⚠️ Android ID required for this API/product.");
      return;
    }
    if (savedAndroidId) postFields.android_id = String(savedAndroidId);
    var postFieldsString = Object.keys(postFields).map(function(k){ return encodeURIComponent(k) + "=" + encodeURIComponent(postFields[k]); }).join("&");
    User.setProperty("last_pending_api_id", String(selectedApi.id || activeApiId || ""), "string");

    User.setProperty("last_pending_price", User.getProperty("buy_price"), "number");
    User.setProperty("last_pending_prod_id", webProductId, "string");
    User.setProperty("last_pending_prod_name", String(product.name).trim(), "string");
    User.setProperty("last_pending_plan_days", cleanPlanDays, "string");
    User.setProperty("last_pending_plan_unit", planUnit, "string");

    HTTP.post({
      url: selectedApi.url,
      body: postFieldsString,
      headers: (function(){ var h={"Content-Type":"application/x-www-form-urlencoded"}; if(selectedApi.master_key) h["x-master-key"]=selectedApi.master_key; return h; })(),
      success: "/onWebKeyReceive",
      error: "/onWebKeyError"
    });

    User.setProperty("buy_pending_order_id", null);
    User.setProperty("buy_prod_idx", null);
    User.setProperty("buy_plan_idx", null);
    Bot.setProperty("buy_qr_msg_id_" + userId, null, "string");
    User.setProperty("buy_qr_msg_id_" + userId, null, "string");
    Bot.setProperty("buy_qr_caption_" + userId, null, "string");
    User.setProperty("buy_qr_caption_" + userId, null, "string");
    Bot.setProperty("buy_qr_buttons_" + userId, null, "string");
    User.setProperty("buy_qr_buttons_" + userId, null, "string");
    
    User.setProperty("buy_verifying_lock_" + userId, false, "boolean");

  } else {
    // ❌ Payment not found — restore original QR caption/buttons, then show dismissible notice
    try {
      var origCaption = Bot.getProperty("buy_qr_caption_" + userId) || User.getProperty("buy_qr_caption_" + userId);
      var origButtons = Bot.getProperty("buy_qr_buttons_" + userId) || User.getProperty("buy_qr_buttons_" + userId);

      if (origCaption) {
        Api.editMessageCaption({
          chat_id: chat.chatid,
          message_id: request.message.message_id,
          caption: origCaption,
          parse_mode: "HTML",
          reply_markup: origButtons ? origButtons : undefined
        });
      }
    } catch (e) {}

    if (request && request.id) {
      Api.answerCallbackQuery({
        callback_query_id: String(request.id),
        text: "❌ PAYMENT NOT FOUND ❌\nPlease complete the payment first, then tap again.",
        show_alert: true
      });
    }
    User.setProperty("buy_verifying_lock_" + userId, false, "boolean");
  }

} catch (err) {
  try {
    User.setProperty("buy_verifying_lock_" + user.telegramid, false, "boolean");
  } catch (e) {}
  Bot.sendMessage("⚠️ <b>Verification Exception:</b> " + err.message, { parse_mode: "HTML" });
}
