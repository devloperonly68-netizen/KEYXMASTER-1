/**#command
name: /onWebKeyReceive
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try { 
  // Parse response safely only if content exists
  var response = null;
  if (typeof content === "string" && content.trim() !== "") {
    try {
      response = JSON.parse(content);
    } catch (e) {
      // Keep response as null if JSON parsing fails
    }
  }

  var userId = user.telegramid;
  var chatId = chat.chatid;

  // 🔄 PRODUCT DATA ACCURACY CORE (DYNAMIC)
  var dataOptions = options || {}; 
  
  // 🆔 1. PRODUCT ID LAYER (Added for flawless API requests)
  var prodId = dataOptions.prod_id || dataOptions.id || dataOptions.product_id || User.getProperty("last_pending_prod_id") || null;

  // 2. Raw options fallback mechanisms
  var rawProdName = dataOptions.prod_name || dataOptions.product || dataOptions.name || User.getProperty("last_pending_prod_name") || "Product";
  var planDays = String(dataOptions.plan_days || dataOptions.days || User.getProperty("last_pending_plan_days") || "1");
  var pDaysNumOnly = planDays.replace(/[^0-9]/g, "").trim(); 
  var planUnit = dataOptions.plan_unit || User.getProperty("last_pending_plan_unit") || "day";
  var unitLabelWordW = (planUnit === "hour") ? (Number(pDaysNumOnly) === 1 ? "Hour" : "Hours") :
                        (planUnit === "minute") ? (Number(pDaysNumOnly) === 1 ? "Minute" : "Minutes") :
                        (Number(pDaysNumOnly) === 1 ? "Day" : "Days");
  var durationDisplayW = pDaysNumOnly + " " + unitLabelWordW;

  // 3. Database validation layer to completely kill the "Product" fallback string bug
  var productList = Bot.getProperty("stored_products") || [];
  var prodName = rawProdName.trim(); 

  // ⚡ DEEP ADVANCED DATABASE SEARCH MATCH (Matches by ID first if available, then name)
  if (productList.length > 0) {
    var checkTerm = prodName.toLowerCase();
    var foundMatch = false;

    for (var i = 0; i < productList.length; i++) {
      var dbItem = productList[i];
      var dbName = dbItem.name ? dbItem.name.trim() : "";
      var dbId = dbItem.id || null;
      
      // If ID matches directly, use it!
      if (prodId && dbId && String(prodId) === String(dbId)) {
        prodName = dbName;
        foundMatch = true;
        break;
      }

      if (!dbName) continue;
      
      if (dbName.toLowerCase() === checkTerm || 
          (checkTerm !== "product" && (checkTerm.indexOf(dbName.toLowerCase()) > -1 || dbName.toLowerCase().indexOf(checkTerm) > -1))) {
        prodName = dbName; 
        if (dbId) { prodId = dbId; } // Backfill ID if name matched
        foundMatch = true;
        break;
      }
    }

    if (!foundMatch || prodName.toLowerCase() === "product") {
      var lastPending = User.getProperty("last_pending_prod_name");
      if (lastPending && lastPending.toLowerCase() !== "product") {
        prodName = lastPending.trim();
      } else if (productList.length === 1) {
        prodName = productList[0].name.trim();
        if (productList[0].id) { prodId = productList[0].id; }
      }
    }
  }

  var price = Number(dataOptions.price) || Number(User.getProperty("last_pending_price")) || 0;
  var firstName = dataOptions.first_name || user.first_name || "User";
  var usernameText = user.username ? "@" + user.username : "No Username";
  var currentWalletBal = Libs.ResourcesLib.userRes("balance").value().toFixed(2);

  var generatedKey = null;
  var isApiDelivery = false;
  var isBackupUsed = false;

  var cleanProdNameUpper = prodName.trim().toUpperCase();
  var manualKeysStorageKey = "manual_keys_" + cleanProdNameUpper + "_" + pDaysNumOnly;
  var backupStockKey = "stock_" + prodName.trim() + "_" + pDaysNumOnly + "_Day";
  
  // ⚡ STEP 1: FORCE CHECK MANUAL STOCK (CRITICAL OVERRIDE)
  var manualStock = Bot.getProperty(manualKeysStorageKey);

  if (!manualStock || (Array.isArray(manualStock) && manualStock.length === 0)) {
    manualStock = Bot.getProperty(backupStockKey);
    isBackupUsed = true;
  }

  if (typeof manualStock === "string" && manualStock.trim() !== "") {
    try {
      manualStock = JSON.parse(manualStock);
    } catch(err) {
      manualStock = manualStock.split("\n").map(function(k) { return k.trim(); }).filter(Boolean);
    }
  }

  if (Array.isArray(manualStock) && manualStock.length > 0) {
    generatedKey = manualStock.shift(); 
    
    if (isBackupUsed) {
      Bot.setProperty(backupStockKey, manualStock, "json");
      var mainStock = Bot.getProperty(manualKeysStorageKey) || [];
      if (typeof mainStock === "string") { mainStock = mainStock.split("\n").map(function(k) { return k.trim(); }).filter(Boolean); }
      if (Array.isArray(mainStock)) {
        var idx = mainStock.indexOf(generatedKey);
        if (idx > -1) { mainStock.splice(idx, 1); }
        Bot.setProperty(manualKeysStorageKey, mainStock, "json");
      }
    } else {
      Bot.setProperty(manualKeysStorageKey, manualStock, "json");
      var backupStock = Bot.getProperty(backupStockKey) || [];
      if (typeof backupStock === "string") { backupStock = backupStock.split("\n").map(function(k) { return k.trim(); }).filter(Boolean); }
      if (Array.isArray(backupStock)) {
        var idx = backupStock.indexOf(generatedKey);
        if (idx > -1) { backupStock.splice(idx, 1); }
        Bot.setProperty(backupStockKey, backupStock, "json");
      }
    }
  }

  // ⚡ STEP 2: FALLBACK TO API KEYS (IF NO MANUAL STOCK WAS FOUND)
  if (!generatedKey && response && response.status === "success") {
    generatedKey = response.key || response.code || response.serial;
    if (generatedKey) {
      isApiDelivery = true;
    }
  }

  // STEP 3: SUCCESS DELIVERY MECHANICS
  if (generatedKey) {
    Libs.ResourcesLib.userRes("balance").add(-price);

    var pastSpent = Bot.getProperty("total_spent_by_" + userId) || 0;
    Bot.setProperty("total_spent_by_" + userId, Number(pastSpent) + price, "number");

    // 🎁 REFER & EARN — referrer bonus jab referred friend PEHLI baar purchase kare
    try {
      var referredByBuy3 = User.getProperty("referred_by");
      if (referredByBuy3 && !User.getProperty("ref_buy_bonus_given")) {
        var refBonusBuy3 = Number(Bot.getProperty("refer_earn_buy_amount"));
        if (isNaN(refBonusBuy3)) refBonusBuy3 = 2;
        if (refBonusBuy3 > 0) {
          Libs.ResourcesLib.anotherUserRes("balance", referredByBuy3).add(refBonusBuy3);
          var pastEarnBuy3 = Number(Bot.getProperty("refer_earnings_" + referredByBuy3) || 0);
          Bot.setProperty("refer_earnings_" + referredByBuy3, pastEarnBuy3 + refBonusBuy3, "number");
          try {
            Api.sendMessage({
              chat_id: referredByBuy3,
              text: "<blockquote>💸 <b>Referral Bonus!</b>\n\nAapke referred friend ne pehli purchase ki — aapko ₹" + refBonusBuy3.toFixed(2) + " mile hain!</blockquote>",
              parse_mode: "HTML"
            });
          } catch (e) {}
        }
        User.setProperty("ref_buy_bonus_given", true, "boolean");
      }
    } catch (e) {}

    var userKeysHistory = User.getProperty("my_purchased_keys") || [];
    userKeysHistory.push({
      product: prodName,
      product_id: prodId,
      days: pDaysNumOnly,
      price: price,
      key: generatedKey,
      date: new Date().toLocaleDateString()
    });
    User.setProperty("my_purchased_keys", userKeysHistory, "json");

    var remainingBal = Libs.ResourcesLib.userRes("balance").value().toFixed(2);
    
    var updateLinkForKey = Bot.getProperty("update_channel_link");
    var keyDeliveryButtons = [[{ text: "📋 Copy Key", copy_text: { text: generatedKey } }]];
    if (updateLinkForKey) {
      keyDeliveryButtons.push([{ text: "📥 Join Updates", url: updateLinkForKey, style: "primary", icon_custom_emoji_id: "6091571559233755994" }]);
    }
    keyDeliveryButtons.push([{ text: "Back to Menu", callback_data: "/back", style: "primary", icon_custom_emoji_id: "5893163582194978381" }]);
    var keyDeliveryMarkup = JSON.stringify({ inline_keyboard: keyDeliveryButtons });

    var deliverText = "<blockquote>" +
                      "<tg-emoji emoji-id='5350447674971660988'>✅</tg-emoji> <b>PURCHASE SUCCESSFUL!</b>\n\n" +
                      "<tg-emoji emoji-id='6147767796097884213'>📦</tg-emoji> <b>Product:</b> <code>" + prodName + "</code>\n" +
                      "<tg-emoji emoji-id='6284816251143331422'>🗝</tg-emoji> <b>Validity:</b> <code>" + durationDisplayW + "</code>\n" +
                      "<tg-emoji emoji-id='5352825278672412291'>👆</tg-emoji> <b>Your Key:</b> <code>" + generatedKey + "</code>\n\n" +
                      "━━━━━ <tg-emoji emoji-id='6147934084346682063'>#⃣</tg-emoji> <b>BALANCE DETAILS</b> ━━━━━\n" +
                      "<tg-emoji emoji-id='6195037488898121775'>✨</tg-emoji> <b>Total Invest:</b> ₹" + price.toFixed(2) + "\n" +
                      "<tg-emoji emoji-id='5409048419211682843'>💵</tg-emoji> <b>New Wallet Balance:</b> ₹" + remainingBal + "\n\n" +
                      "<i>Enjoy your purchase. <tg-emoji emoji-id='6057881002540274780'>🥳</tg-emoji></i>" +
                      "</blockquote>";
                      
    // ✅ FIX: "Processing your order..." wala purana message ab delete ho jaata
    // hai, taaki chat me sirf final key-delivery message rahe.
    try {
      var procMsgId = Bot.getProperty("gen_msg_id_" + userId) || User.getProperty("gen_msg_id_" + userId);
      if (procMsgId) {
        Api.deleteMessage({ chat_id: chatId, message_id: Number(procMsgId) });
        Bot.setProperty("gen_msg_id_" + userId, null, "string");
        User.setProperty("gen_msg_id_" + userId, null, "string");
      }
    } catch (cleanupErr) {}

    Api.sendMessage({
      chat_id: chatId,
      text: deliverText,
      parse_mode: "HTML",
      reply_markup: keyDeliveryMarkup
    });

    var adminId = "7088682169"; 
    var deliveryMethodLabel = isApiDelivery ? "API" : "MANUAL STOCK";
    var adminMsg = "🔔 <b>NEW PURCHASE DELIVERED (" + deliveryMethodLabel + ")</b> ✔️\n\n" +
                   "👤 <b>Buyer:</b> " + firstName + " (<code>" + userId + "</code>)\n" +
                   "📦 <b>Product:</b> " + prodName + " (ID: " + (prodId || "N/A") + ")\n" +
                   "⏳ <b>Plan:</b> " + durationDisplayW + "\n" +
                   "💸 <b>Price Deducted:</b> ₹" + price.toFixed(2) + "\n" +
                   "💳 <b>User Remaining Bal:</b> ₹" + remainingBal + "\n" +
                   "🔑 <b>Key:</b> <code>" + generatedKey + "</code>";
                   
    Api.sendMessage({ chat_id: adminId, text: adminMsg, parse_mode: "HTML" });

    User.setProperty("last_pending_price", null);
    User.setProperty("last_pending_prod_name", null);
    User.setProperty("last_pending_plan_days", null);
    User.setProperty("last_pending_prod_id", null);
    User.setProperty("last_pending_plan_unit", null);

  } else {
    // STEP 4: BOTH FAILED (System goes into error notification mode)
    Api.sendMessage({
      chat_id: chatId,
      text: "⏳ <b>Wait some time admin will stock refill soon</b>\n<i>Your funds were not deducted.</i>",
      parse_mode: "HTML"
    });

    var webBalance = "Low/Empty";
    var websiteErrorReason = "Website API Empty Response / Down";
    
    if (response) {
      webBalance = response.balance || response.website_balance || "Low/Empty";
      websiteErrorReason = response.msg || response.message || "Low Balance / Out of Stock";
    }

    var alertAdminId = "7088682169";
    var lowBalanceAdminMsg = "⚠️ <b>LOW BALANCE IN WEBSITE / API ERROR</b>\n" +
                             "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                             "🛒 <b>PRODUCT DETAILS:</b>\n" +
                             "📦 <b>Product Name:</b> <code>" + prodName + "</code>\n" +
                             "🆔 <b>Product ID:</b> <code>" + (prodId || "Not Passed") + "</code>\n" +
                             "⏳ <b>Days:</b> <code>" + pDaysNumOnly + " Days</code>\n" +
                             "💰 <b>Your Balance Website:</b> <code>" + webBalance + "</code>\n" +
                             "ℹ️ <b>API Reason:</b> <code>" + websiteErrorReason + "</code>\n\n" +
                             "👤 <b>USER DETAILS:</b>\n" +
                             "🗣 <b>User Name:</b> " + usernameText + "\n" +
                             "📛 <b>Name:</b> " + firstName + "\n" +
                             "🆔 <b>User ID:</b> <code>" + userId + "</code>\n" +
                             "💳 <b>Available Balance (User Wallet):</b> ₹" + currentWalletBal + "\n\n" +
                             "📌 <i>Action Required: Please refill your website API or add/deliver the key manually to this user!</i>";

    Api.sendMessage({ chat_id: alertAdminId, text: lowBalanceAdminMsg, parse_mode: "HTML" });
  }
} catch (e) {
  Bot.sendMessage("❌ Error executing delivery pipeline: " + e.message);
}