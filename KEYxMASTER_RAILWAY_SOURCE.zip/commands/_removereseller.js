/**#command
name: /removereseller
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169";
  if (String(chat.chatid) !== adminId) return;

  var targetId = params ? params.trim() : null;

  if (!targetId) {
    Bot.sendMessage("❌ <b>Usage:</b> <code>/removereseller 123456789</code>", { parse_mode: "HTML" });
    return;
  }

  Bot.setProperty("is_reseller_" + targetId, false, "boolean");

  Bot.sendMessage("<tg-emoji emoji-id='6143299028655280273'>☠</tg-emoji> User <code>" + targetId + "</code> ka reseller role remove kar diya gaya hai.", { parse_mode: "HTML" });

  // User ko notification
  var removeNotif = "<blockquote><b><tg-emoji emoji-id='6143299028655280273'>⚠️</tg-emoji> ROLE REMOVED</b>\n\n" +
                    "Aapka **Reseller Role** admin dwara remove kar diya gaya hai. Ab aapko normal prices show hongi.</blockquote>";
                    
  Api.sendMessage({
    chat_id: targetId,
    text: removeNotif,
    parse_mode: "HTML"
  });

} catch (err) {
  Bot.sendMessage("Error: " + err.message);
}