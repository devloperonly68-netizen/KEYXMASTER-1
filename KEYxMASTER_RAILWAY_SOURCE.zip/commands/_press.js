/**#command
name: /press
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Command Name: /press (Premium Calculator Keypad Handler)
// ✅ FIXED: "Back" button pehle "/dmenu" call kar raha tha jo bot me exist hi nahi karta
// (dead button — click karne par kuch nahi hota tha). Ab "/back" (real menu command) use hota hai.
// ✅ Number buttons ab addfund screen jaisi hi blue "primary" styling ke saath hain (pehle plain/colorless the).

try {
  // Purana set default check: Agar user ne naya deposit shuru kiya hai toh default 0 rahe
  let current_amount = User.getProperty("deposit_amount");
  if (!current_amount) {
    current_amount = "0";
  }

  let pressed = params ? params.trim() : "";
  let queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;

  // 💎 Premium Emoji Set (same IDs as /addfund — keeps the screen visually identical, no flicker)
  let e_money   = "<tg-emoji emoji-id='6312263493051489212'>💰</tg-emoji>";
  let e_clear   = "<tg-emoji emoji-id='5348224471050238603'>✏</tg-emoji>";
  let e_confirm = "<tg-emoji emoji-id='5348191451341668809'>✅</tg-emoji>";
  let e_back    = "<tg-emoji emoji-id='5893163582194978381'>⬅️</tg-emoji>";
  let e_hour    = "<tg-emoji emoji-id='6100657257605763582'>✔️</tg-emoji>";
  let e_check   = "<tg-emoji emoji-id='6311870645277825763'>✔️</tg-emoji>";
  let e_gear    = "<tg-emoji emoji-id='5348292765325212780'>⚙</tg-emoji>";

  // --- CONFIRM BUTTON CLICK ---
  if (pressed == "confirm") {
    if (parseInt(current_amount) <= 0 || current_amount == "" || current_amount == "0") {
      if (queryId) {
        Api.answerCallbackQuery({
          callback_query_id: queryId,
          text: "👀 PLEASE ENTER A VALID AMOUNT!",
          show_alert: true
        });
      }
      return;
    }

    // ✅ NEW: ab seedhe QR generate nahi hota — pehle "Choose Payment Method"
    // screen dikhti hai (UPI Pay / Binance Pay), jaise buyitem checkout me hoti hai.
    let finalAmount = String(parseInt(current_amount));
    let usdRate = Number(Bot.getProperty("usd_rate") || 91);
    let usdAmount = (parseInt(current_amount) / usdRate).toFixed(2);

    let e_upi = "<tg-emoji emoji-id='5348392971207194994'>💳</tg-emoji>";
    let e_binance = "<tg-emoji emoji-id='6312263493051489212'>🟡</tg-emoji>";

    let methodText =
      "<blockquote>" + e_money + " <b>CHOOSE PAYMENT METHOD</b></blockquote>\n" +
      "━━━━━━━━━━━━━━━━━━━━━\n\n" +
      e_money + " <b>Amount:</b> ₹<code>" + finalAmount + "</code> <i>(≈ $" + usdAmount + ")</i>\n\n" +
      "━━━━━━━━━━━━━━━━━━━━━\n" +
      "<i>Select a payment gateway below:</i>";

    let methodButtons = [
      [{ text: "UPI Pay ₹" + finalAmount, callback_data: "/addbal_upi " + finalAmount, style: "success", icon_custom_emoji_id: "5348392971207194994" }],
      [{ text: "Binance Pay $" + usdAmount, callback_data: "/addbal_binance " + finalAmount, style: "primary", icon_custom_emoji_id: "6312263493051489212" }],
      [{ text: "Back", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }]
    ];

    Api.editMessageText({
      chat_id: chat.chatid,
      message_id: request.message.message_id,
      text: methodText,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: methodButtons })
    });

    // Amount reset to 0 so next time it starts fresh
    User.setProperty("deposit_amount", "0", "string");

    if (queryId) {
      Api.answerCallbackQuery({ callback_query_id: queryId });
    }

    return;
  }

  // --- KEYPAD INPUT LOGIC ---
  if (pressed == "clear") {
    if (current_amount.length > 1) {
      current_amount = current_amount.slice(0, -1);
    } else {
      current_amount = "0";
    }
  } else if (pressed !== "") {
    if (current_amount == "0") {
      current_amount = pressed;
    } else {
      if ((current_amount + pressed).length <= 6) {
        current_amount = current_amount + pressed;
      }
    }
  }

  // Save current keypad amount state
  User.setProperty("deposit_amount", current_amount, "string");

  if (queryId) {
    Api.answerCallbackQuery({ callback_query_id: queryId });
  }

  // 🎨 Keypad Buttons — same premium colored styling as /addfund
  let inlineKeyboardPayload = [
    [
      { text: "1", callback_data: "/press 1", style: "primary" },
      { text: "2", callback_data: "/press 2", style: "primary" },
      { text: "3", callback_data: "/press 3", style: "primary" }
    ],
    [
      { text: "4", callback_data: "/press 4", style: "primary" },
      { text: "5", callback_data: "/press 5", style: "primary" },
      { text: "6", callback_data: "/press 6", style: "primary" }
    ],
    [
      { text: "7", callback_data: "/press 7", style: "primary" },
      { text: "8", callback_data: "/press 8", style: "primary" },
      { text: "9", callback_data: "/press 9", style: "primary" }
    ],
    [
      { text: "Clear", callback_data: "/press clear", style: "danger", icon_custom_emoji_id: "5348224471050238603" },
      { text: "0", callback_data: "/press 0", style: "primary" },
      { text: "Confirm", callback_data: "/press confirm", style: "success", icon_custom_emoji_id: "5348191451341668809" }
    ],
    [
      // ✅ FIXED: "/dmenu" -> "/back" (dead command replaced with the real menu handler)
      { text: "Back", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
    ]
  ];

  let keypadMsg =
    "<blockquote>" + e_money + " <b>ADD BALANCE — ENTER AMOUNT</b> <tg-emoji emoji-id='6312263493051489212'>💎</tg-emoji></blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "<tg-emoji emoji-id='6312263493051489212'>💎</tg-emoji> <b>Amount:</b> ₹<code>" + current_amount + "</code>\n\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n" +
    e_check + " <i>Instant Auto-Credit</i>\n" +
    "<tg-emoji emoji-id='6215386799133433653'>🔒</tg-emoji> <i>100% Secure UPI Payment</i>\n" +
    e_hour + " <i>Verified in Seconds</i>\n\n" +
    "<tg-emoji emoji-id='6100170496077204999'>👑</tg-emoji> <i>Use the keypad below to enter amount</i>";

  Api.editMessageText({
    chat_id: chat.chatid,
    message_id: request.message.message_id,
    text: keypadMsg,
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: inlineKeyboardPayload })
  });

} catch (err) {
  Bot.sendMessage("⚠️ System Error in Keypad: " + err.message);
}