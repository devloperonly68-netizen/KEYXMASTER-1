/**#command
name: /process_buy
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🛒 COMMAND = /process_buy (ORIGINAL)
// =========================================================

try {
  if (!params || typeof params !== "string") return;

  let data = params.split(" ");
  let rawType = data[0] ? data[0].toLowerCase().trim() : "";
  let actionState = data[1] ? data[1].toLowerCase().trim() : "";

  let queryId = request.id || (request.callback_query && request.callback_query.id);
  let userId = user.telegramid.toString().trim(); 
  let chatID = chat.chatid;

  let rawResellers = Bot.getProperty("resellers_list");
  let resellers = [];

  if (rawResellers) {
      if (Array.isArray(rawResellers)) {
          resellers = rawResellers;
      } else if (typeof rawResellers === "string") {
          try { resellers = JSON.parse(rawResellers); } catch(e) { resellers = rawResellers.split(","); }
      } else if (typeof rawResellers === "object") {
          resellers = rawResellers.resellers || rawResellers.list || rawResellers.users || Object.values(rawResellers);
      }
  }
  if (!Array.isArray(resellers)) { resellers = []; }

  let isReseller = resellers.map(function(id) {
      return id ? id.toString().toLowerCase().trim() : "";
  }).includes(userId) || (userId === "7088682169");
  
  let finalCost = 0;
  let stockData = [];
  let displayTypeName = "";
  let isDynamicCategory = false;
  let isGeneralCategory = false;
  let selectedCat = null;
  
  let fbCategories = Bot.getProperty("fb_categories", []);
  if (!Array.isArray(fbCategories)) { fbCategories = []; }

  if (rawType.startsWith("fb_")) {
      isDynamicCategory = true;
      let targetCatId = rawType.replace("fb_", "").trim();
      
      for (let i = 0; i < fbCategories.length; i++) {
          if (fbCategories[i].id === targetCatId) {
              selectedCat = fbCategories[i];
              break;
          }
      }
      
      if (!selectedCat) {
          if (queryId) Api.answerCallbackQuery({ callback_query_id: queryId, text: "❌ Category deleted!", show_alert: true });
          return;
      }
      
      if (isReseller && selectedCat.reseller_price !== undefined && selectedCat.reseller_price !== "") {
          finalCost = Number(selectedCat.reseller_price);
      } else {
          finalCost = Number(selectedCat.price || 0);
      }
      stockData = selectedCat.stock_list || [];
      displayTypeName = selectedCat.name;
  } else if (rawType == "fb" || rawType == "google") {
      let priceRes = parseFloat(Bot.getProperty("price_res_" + rawType) || 0);
      let priceNorm = parseFloat(Bot.getProperty("price_norm_" + rawType) || 0);
      finalCost = isReseller ? priceRes : priceNorm;
      stockData = Bot.getProperty("ff_stock_" + rawType) || [];
      displayTypeName = rawType.toUpperCase();
  } else {
      var categories = Bot.getProperty("ff_categories") || {};
      if (!categories[rawType]) {
          if (queryId) Api.answerCallbackQuery({ callback_query_id: String(queryId), text: "❌ Invalid Product!", show_alert: true });
          return;
      }
      isGeneralCategory = true;
      selectedCat = categories[rawType];
      
      if (isReseller) {
          if (selectedCat.reseller_price !== undefined && selectedCat.reseller_price !== "" && selectedCat.reseller_price !== null && Number(selectedCat.reseller_price) > 0) {
              finalCost = Number(selectedCat.reseller_price);
          } else if (selectedCat.price !== undefined && selectedCat.price !== "" && selectedCat.price !== null) {
              finalCost = Number(selectedCat.price); 
          } else {
              finalCost = Number(selectedCat.normal_price || 0);
          }
      } else {
          finalCost = Number(selectedCat.normal_price || selectedCat.price || 0);
      }
      
      let fallbackStock = Bot.getProperty("ff_stock_" + rawType) || [];
      stockData = (selectedCat.stock_list && selectedCat.stock_list.length > 0) ? selectedCat.stock_list : fallbackStock;
      displayTypeName = selectedCat.name;
  }

  if (!stockData || stockData.length === 0) {
      if (queryId) {
          Api.answerCallbackQuery({
              callback_query_id: String(queryId),
              text: "❌ Stock is empty! Cannot process purchase.",
              show_alert: true
          });
      } else {
          Api.sendMessage({ chat_id: chatID, text: "❌ Out of stock items cannot be processed." });
      }
      return;
  }

  var userRes = Libs.ResourcesLib.userRes("balance");
  var bonusBal = Bot.getProperty("balance" + userId) || 0;
  var unifiedTotalBalance = Number(userRes.value()) + Number(bonusBal);

  if (unifiedTotalBalance < finalCost) {
      var needToPay = finalCost - unifiedTotalBalance;
      
      User.setProperty("buy_price", finalCost, "number");
      User.setProperty("buy_needpay", needToPay, "number");
      User.setProperty("buy_prod_name", displayTypeName, "string");

      if (queryId) {
          Api.answerCallbackQuery({ 
              callback_query_id: String(queryId), 
              text: "⚠️ Balance low! Generating QR for ₹" + needToPay + "...", 
              show_alert: true 
          });
      }

      var targetUrl = "https://fampay.anujbots.xyz/qr.php?upi=" + encodeURIComponent(Bot.getProperty("payment_upi_id") || "galureang@fam") + "&amount=" + needToPay;

      Api.sendMessage({
          chat_id: chatID,
          text: "<b>📉 Requesting QR from server...\n<code>" + targetUrl + "</code></b>",
          parse_mode: "HTML"
      });

      HTTP.get({
          url: targetUrl,
          success: "/onBuyQR"
      });
      return;
  }

  if (bonusBal >= finalCost) {
      Bot.setProperty("balance" + userId, bonusBal - finalCost, "number");
  } else {
      var remainingDeduction = finalCost - bonusBal;
      Bot.setProperty("balance" + userId, 0, "number");
      userRes.remove(remainingDeduction);
  }

  var accountExtracted = stockData.shift();
  
  if (isDynamicCategory && selectedCat) {
      selectedCat.stock_list = stockData;
      Bot.setProperty("fb_categories", fbCategories, "json");
  } else if (isGeneralCategory && selectedCat) {
      selectedCat.stock_list = stockData;
      var categories = Bot.getProperty("ff_categories") || {};
      categories[rawType] = selectedCat;
      Bot.setProperty("ff_categories", categories, "json");
      Bot.setProperty("ff_stock_" + rawType, stockData, "json");
  } else {
      Bot.setProperty("ff_stock_" + rawType, stockData, "json");
  }

  var fullRawString = String(accountExtracted || "").trim();
  var emailData = fullRawString;
  var passwordData = "No Password Found";

  if (fullRawString.indexOf("|") !== -1) {
      var lastPipeIndex = fullRawString.lastIndexOf("|");
      var firstPart = fullRawString.substring(0, lastPipeIndex).trim();
      var secondPart = fullRawString.substring(lastPipeIndex + 1).trim();

      if (firstPart.indexOf(" ") !== -1) {
          var spaceParts = firstPart.split(" ");
          emailData = spaceParts[spaceParts.length - 1].trim();
      } else {
          emailData = firstPart;
      }
      passwordData = secondPart;
  }

  let purchasedKeys = User.getProperty("my_purchased_keys") || [];
  if (!Array.isArray(purchasedKeys)) { purchasedKeys = []; }
  
  let currentDate = new Date().toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' });
  purchasedKeys.push({
      productName: displayTypeName,
      cost: finalCost.toString(),
      key: emailData + (passwordData !== "No Password Found" ? " | " + passwordData : ""),
      days: "Permanent", 
      date: currentDate
  });
  User.setProperty("my_purchased_keys", purchasedKeys, "json");

  var deliveryText = 
    "┏━━━━━━━━━━━━━━━━━━━━━━━━┓\n" +
    "┃ ❤️‍🔥 <b>PURCHASE SUCCESSFUL!</b> ❤️‍🔥 ┃\n" +
    "┗━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n" +
    "📦 <b>Item:</b> <code>" + displayTypeName + "</code>\n" +
    "💰 <b>Paid:</b> <code>₹" + finalCost + "</code> " + (isReseller ? "<b>(Reseller)</b>" : "") + "\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
    "👤 <b>ACCOUNT DETAILS:</b>\n\n" +
    "🚀 <b>Email:</b> <code>" + emailData + "</code>\n" +
    "🔒 <b>Password:</b> <code>" + passwordData + "</code>\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
    "⚠️ <i>Copy details instantly.</i>";

  Api.sendMessage({
      chat_id: chatID,
      text: deliveryText,
      parse_mode: "HTML"
  });

  if (queryId) {
      Api.answerCallbackQuery({
          callback_query_id: String(queryId),
          text: "✅ Released Successfully!",
          show_alert: false
      });
  }

  var adminLogChannel = "7088682169"; 
  var adminNotificationMsg = 
    "<blockquote>⚠️ <b>NEW ORDER ALERT</b>" + (isReseller ? " [RESELLER]" : "") + "</blockquote>\n" +
    "👤 <b>User:</b> <a href='tg://user?id=" + userId + "'>" + user.first_name + "</a> (<code>" + userId + "</code>)\n" +
    "📦 <b>Item:</b> <code>" + displayTypeName + "</code>\n" +
    "💰 <b>Revenue:</b> <code>₹" + finalCost + "</code>\n" +
    "⚡ <b>Stock Left:</b> <code>" + stockData.length + " units</code>\n\n" +
    "🖥 <b>ACCOUNT DETAILS:</b>\n" +
    "➔ <b>Email:</b> <code>" + emailData + "</code>\n" +
    "➔ <b>Password:</b> <code>" + passwordData + "</code>";

  Api.sendMessage({
      chat_id: adminLogChannel,
      text: adminNotificationMsg,
      parse_mode: "HTML"
  });

} catch(e) {
  Bot.sendMessage("Critical Execution Failure Module Error: " + e.message);
}