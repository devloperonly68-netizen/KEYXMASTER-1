/**#command
name: /how
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  // Click loading spinner band karne ke liye instant answer
  if (request && request.id) {
    HTTP.post({
      url: "https://api.telegram.org/bot" + bot.token + "/answerCallbackQuery",
      body: { callback_query_id: request.id }
    });
  }

  var chatId = chat.chatid;
  var messageId = request && request.message ? request.message.message_id : null;

  // Premium Text with your custom premium emojis
  var text = "━━━━━━━━━━━━━━━━━━━━\n" +
             "<tg-emoji emoji-id='6195222374355311655'>👑</tg-emoji> <b>HOW TO USE THE BOT</b>\n" +
             "━━━━━━━━━━━━━━━━━━━━\n\n" +
             "<blockquote>" +
             "<tg-emoji emoji-id='6219605968846591564'>😎</tg-emoji> Follow these simple steps to use the bot:\n\n" +
             "<tg-emoji emoji-id='6194809138371904539'>📉</tg-emoji> 1. Add balance to your wallet first.\n" +
             "<tg-emoji emoji-id='6298597328022407025'>💰</tg-emoji> 2. Go to products section and pick your plan.\n" +
             "<tg-emoji emoji-id='5316728625465146646'>👆</tg-emoji> 3. Click buy and copy your instant key!\n\n" +
             "<i>Watch the detailed video tutorial below for full guide!</i>" +
             "</blockquote>";

  // Inline Keyboard configuration with direct URL system
  var howToLink = Bot.getProperty("how_to_use_link") || "https://youtu.be/oe2Ja08Vvpo";
  var keyboard = {
    inline_keyboard: [
      [
        {
          text: "Watch Video Guide",
          url: howToLink, 
          style: "primary", // ⚡ Style property added here as requested
          icon_custom_emoji_id: "5258077307985207053" 
        }
      ],
      [
        {
          text: "Back",
          callback_data: "/back", 
          style: "danger", 
          icon_custom_emoji_id: "5316623368701623632"
        }
      ]
    ]
  };

  var endpoint = messageId ? "editMessageText" : "sendMessage";
  var requestBody = {
    chat_id: String(chatId),
    text: text,
    parse_mode: "HTML",
    reply_markup: JSON.stringify(keyboard)
  };

  if (messageId) {
    requestBody.message_id = Number(messageId);
  }

  HTTP.post({
    url: "https://api.telegram.org/bot" + bot.token + "/" + endpoint,
    body: requestBody
  });

} catch (err) {}