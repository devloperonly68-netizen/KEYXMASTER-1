/**#command
name: /confirm_rem_stock
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169";
  if (String(chat.chatid) !== adminId) return;

  if (!params) return;
  
  // Params split karein (slug aur stock index nikalne ke liye)
  var parts = params.split(" ");
  var slug = parts[0];
  var stockIndex = parseInt(parts[1]);

  var currentStock = Bot.getProperty("ff_stock_" + slug) || [];
  if (!Array.isArray(currentStock) || stockIndex >= currentStock.length) {
    Bot.sendMessage("❌ Account pehle hi delete ho chuka hai ya nahi mila.");
    return;
  }

  // Target account ka data store karein report ke liye
  var deletedAccount = currentStock[stockIndex];

  // Array se us specific index ko delete karein
  currentStock.splice(stockIndex, 1);

  // Database me updated array save karein
  Bot.setProperty("ff_stock_" + slug, currentStock, "json");

  // Success message confirmation ke sath
  Bot.sendMessage("🗑 <b>Stock Deleted Successfully!</b>\n\n• <b>Category:</b> " + slug.toUpperCase() + "\n• <b>Removed Data:</b> <code>" + deletedAccount + "</code>", {parse_mode: "HTML"});

  // Stock list ko refresh karne ke liye auto-run karein taaki updated list dikhe
  Bot.run({
    command: "/view_rem_stock",
    options: { params: slug }
  });

} catch (e) {
  Bot.sendMessage("Error: " + e.message);
}