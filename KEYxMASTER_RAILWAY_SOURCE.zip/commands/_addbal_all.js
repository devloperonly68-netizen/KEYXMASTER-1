/**#command
name: /addbal_all
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// ✅ FIXED (v3): dynamic owner_id + co-admin check (same fix as /addbal).
let admin_id = Bot.getProperty("owner_id") || "7088682169";
let requesterId = String(user.telegramid);
let isCoAdmin = Bot.getProperty("co_admin_" + requesterId);

if (requesterId === admin_id || isCoAdmin) {

    // ✅ FIXED: instantly ack the button press so it doesn't feel stuck/slow.
    if (request && request.id) {
        try {
            HTTP.post({
                url: "https://api.telegram.org/bot" + bot.token + "/answerCallbackQuery",
                body: { callback_query_id: request.id }
            });
        } catch (ackErr) {}
    }

    let params = (typeof message !== "undefined" && message) ? message.split(" ") : [];
    let data = params[1];

    // Agar amount na mila ho, toh prompt bhejo aur agla text message
    // auto-capture ho jaayega (see _start.js "MODULE 5").
    if (!data || isNaN(parseFloat(data.trim()))) {
        User.setProperty("addbalall_step", "waiting_input", "string");
        Bot.sendMessage(
            "<tg-emoji emoji-id='5409048419211682843'>💵</tg-emoji> <b>Add Balance To ALL Users</b>\n\n" +
            "<i>Kitna amount har user ko add karna hai, sirf number bhejein:</i>\n<code>amount</code>\n\n" +
            "<i>Example:</i> <code>50</code>",
            {parse_mode: "HTML"}
        );
        return;
    }

    let amountToAdd = parseFloat(data.trim());

    if (isNaN(amountToAdd) || amountToAdd <= 0) {
        Bot.sendMessage("❌ *Invalid Amount!*", {parse_mode: "Markdown"});
        return;
    }

    try {
        let userList = Bot.getProperty("all_users_list") || [];
        if (!Array.isArray(userList)) { userList = []; }

        if (userList.length === 0) {
            Bot.sendMessage("⚠️ <b>Database Empty:</b> Abhi tak koi bhi user register nahi hua hai.", {parse_mode: "HTML"});
            return;
        }

        Bot.sendMessage(
            "<tg-emoji emoji-id='6147936236125298267'>⏳</tg-emoji> <b>Adding ₹" + amountToAdd + " to " + userList.length + " users, please wait...</b>",
            {parse_mode: "HTML"}
        );

        let notificationText =
            "<blockquote>" +
            "<tg-emoji emoji-id='6192822213486321961'>🗣</tg-emoji> Admin Added: " + amountToAdd + "\n" +
            "<tg-emoji emoji-id='6266967801580231067'>💎</tg-emoji> Balance Credited!\n" +
            "<tg-emoji emoji-id='6267068789146260253'>💰</tg-emoji> Wallet Updated\n" +
            "<tg-emoji emoji-id='5866053971960929280'>🛒</tg-emoji> /start TO SHOP NOW" +
            "</blockquote>";

        let successCount = 0;
        let failCount = 0;

        for (let i = 0; i < userList.length; i++) {
            let targetUserId = userList[i];
            try {
                // Balance add karna
                let targetUserBalance = Libs.ResourcesLib.anotherUserRes("balance", targetUserId);
                targetUserBalance.add(amountToAdd);
                successCount++;

                // ✅ FIXED: raw HTTP.post ki jagah Api.sendMessage — zyada reliable delivery.
                try {
                    Api.sendMessage({
                        chat_id: targetUserId,
                        text: notificationText,
                        parse_mode: "HTML"
                    });
                } catch (notifyErr) {
                    // Notification fail hone se balance-add process nahi rukna chahiye
                }
            } catch (userErr) {
                failCount++;
            }
        }

        Bot.sendMessage(
            "✅ <b>Bulk Add Balance Complete!</b>\n\n" +
            "💰 <b>Amount per user:</b> ₹" + amountToAdd + "\n" +
            "👥 <b>Success:</b> " + successCount + "\n" +
            "⚠️ <b>Failed:</b> " + failCount,
            {parse_mode: "HTML"}
        );

    } catch (err) {
        Bot.sendMessage("⚠️ *Error:* " + err.message, {parse_mode: "Markdown"});
    }

} else {
    Bot.sendMessage("❌ You are not authorized to use this command.");
}
