/**#command
name: /buy_hack_cat
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🛒 SHOP MENU — Product listing filtered by category (Step 1.5)
// Called after user selects "ANDROID ROOT" or "ANDROID NON ROOT" from
// /buy_hack. Shows only products matching that category. Products added
// with category "both" (or no category set at all — legacy products)
// show up under BOTH root and nonroot listings.
// =========================================================

try {
  var rawData = Bot.getProperty("stored_products");
  var productList = [];

  if (Array.isArray(rawData)) {
    productList = rawData;
  } else if (typeof rawData === "string") {
    try {
      productList = JSON.parse(rawData);
      if (!Array.isArray(productList)) { productList = []; }
    } catch (e) {
      productList = [];
    }
  }

  var chatId = chat.chatid;
  var firstName = user && user.first_name ? user.first_name : "User";

  // Category param — "root" or "nonroot"
  var category = params ? params.trim().toLowerCase() : "";
  if (category === "") {
    var cbData = request && request.callback_query ? request.callback_query.data : "";
    category = cbData.replace("/buy_hack_cat ", "").replace("buy_hack_cat ", "").trim().toLowerCase();
  }
  if (category !== "root" && category !== "nonroot" && category !== "iphone") { category = "nonroot"; }

  var categoryLabel = (category === "root") ? "ANDROID ROOT" : (category === "iphone") ? "iPHONE" : "ANDROID NON ROOT";

  var productButtons = [];

  for (var i = 0; i < productList.length; i++) {
    var item = productList[i];
    if (!item) { continue; }

    // Legacy products (no category field) ya "both" wale — dono categories me dikhte hain.
    var itemCategory = item.category ? String(item.category).toLowerCase() : "both";
    if (itemCategory !== "both" && itemCategory !== category) { continue; }

    var itemName = item.name ? String(item.name) : "Product " + (i + 1);
    var itemEmoji = item.emoji ? String(item.emoji) : "5226656353744862682";

    productButtons.push([
      {
        text: itemName,
        callback_data: "/viewprod " + i,
        style: "primary",
        icon_custom_emoji_id: itemEmoji
      }
    ]);
  }

  var storeText;

  if (productButtons.length === 0) {
    storeText =
      "<blockquote><b>" + categoryLabel + "</b></blockquote>\n" +
      "━━━━━━━━━━━━━━━━━━━━━\n\n" +
      "<tg-emoji emoji-id='6093854128193152827'>⚠️</tg-emoji> <i>Is category me abhi koi product available nahi hai. Jald hi add kiya jayega!</i>\n" +
      "━━━━━━━━━━━━━━━━━━━━━";
  } else {
    storeText =
      "<blockquote><b>" + categoryLabel + " — SELECT A PRODUCT</b></blockquote>\n" +
      "━━━━━━━━━━━━━━━━━━━━━\n\n" +
      "<tg-emoji emoji-id='6091571559233755994'>👋</tg-emoji> <b>Yoo " + firstName + "!</b>\n" +
      "<i>Choose any product below to view its price and available duration plans.</i>\n" +
      "━━━━━━━━━━━━━━━━━━━━━";
  }

  productButtons.push([
    {
      text: "Back",
      callback_data: "/buy_hack",
      style: "danger",
      icon_custom_emoji_id: "5893163582194978381"
    }
  ]);

  var replyMarkupStr = JSON.stringify({ inline_keyboard: productButtons });

  if (request && request.message && request.message.message_id) {
    if (request.message.photo) {
      try { Api.deleteMessage({ chat_id: chatId, message_id: request.message.message_id }); } catch (e) {}
      Api.sendMessage({ chat_id: chatId, text: storeText, parse_mode: "HTML", reply_markup: replyMarkupStr });
    } else {
      Api.editMessageText({
        chat_id: chatId,
        message_id: request.message.message_id,
        text: storeText,
        parse_mode: "HTML",
        reply_markup: replyMarkupStr
      });
    }
  } else {
    Api.sendMessage({ chat_id: chatId, text: storeText, parse_mode: "HTML", reply_markup: replyMarkupStr });
  }

  if (request && request.id) {
    try { Api.answerCallbackQuery({ callback_query_id: request.id }); } catch (e) {}
  }

} catch (err) {
  Bot.sendMessage("⚠️ Shop Menu Error: " + err.message, { parse_mode: "HTML" });
}
