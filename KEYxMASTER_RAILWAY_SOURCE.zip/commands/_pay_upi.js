/**#command
name: /pay_upi
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 💳 "Pay via UPI" button — generates the shortfall QR
// (this used to be inline inside buyitem.js; moved here since buyitem.js
// now always shows the Payment Method screen first)
// =========================================================

try {
  var productList = Bot.getProperty("stored_products") || [];
  var callbackId = (request && request.id) ? request.id : ((request && request.callback_query && request.callback_query.id) || null);
  var chatId = chat.chatid;
  var userId = user.telegramid;

  var parts = params ? String(params).trim().split(" ") : [];
  var prodIdx = Number(parts[0]);
  var planIdx = Number(parts[1]);

  var product = productList[prodIdx];
  if (!product || !product.plans || !product.plans[planIdx]) {
    Bot.sendMessage("❌ Product or Plan configuration missing!");
    return;
  }

  var plan = product.plans[planIdx];
  var planUnit = plan.unit || "day";
  var cleanPlanDays = String(plan.days).replace(/[^0-9.]/g, "").trim();

  var unifiedBal = (function () {
    var resBal = 0;
    try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
    var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
    return resBal + bonusBal;
  })();

  var isReseller = Bot.getProperty("is_reseller_" + userId) === true;
  var cleanProdName = product.name.trim().toUpperCase();
  var priceKeySuffix = (planUnit === "day") ? cleanPlanDays : (cleanPlanDays + "_" + planUnit);
  var normalKey = "price_normal_" + cleanProdName + "_" + priceKeySuffix;
  var resellerKey = "price_reseller_" + cleanProdName + "_" + priceKeySuffix;

  var adminNormalPrice = Bot.getProperty(normalKey);
  var adminResellerPrice = Bot.getProperty(resellerKey);
  var currentNormal = (adminNormalPrice !== undefined && adminNormalPrice !== null) ? adminNormalPrice : plan.normal_price;
  var currentReseller = (adminResellerPrice !== undefined && adminResellerPrice !== null) ? adminResellerPrice : plan.reseller_price;
  var originalPrice = isReseller ? Number(currentReseller) : Number(currentNormal);
  var price = originalPrice;

  var planSpecificDiscKey = "auto_discount_" + cleanProdName + "_" + cleanPlanDays + "_" + planUnit.toUpperCase();
  var productWideDiscKey = "auto_discount_" + cleanProdName + "_ALL";
  var autoDiscountPercent = Bot.getProperty(planSpecificDiscKey) || Bot.getProperty(productWideDiscKey) || Bot.getProperty("auto_discount_global") || 0;

  var appliedCouponCode = User.getProperty("applied_coupon_" + prodIdx + "_" + planIdx);
  if (appliedCouponCode) {
    var couponRec = Bot.getProperty("coupon_" + appliedCouponCode);
    if (couponRec && couponRec.discountPercent) {
      price = Number((originalPrice * (1 - couponRec.discountPercent / 100)).toFixed(2));
    }
  } else if (autoDiscountPercent > 0) {
    price = Number((originalPrice * (1 - autoDiscountPercent / 100)).toFixed(2));
  }

  var needToPay = Math.max(price - unifiedBal, 0);
  if (needToPay <= 0) { needToPay = price; } // safety fallback

  // ✅ Product context save karo taaki /onCheck payment verify hone ke baad
  // is exact plan ko khud-ba-khud (bina dobara confirm maange) purchase kar de.
  User.setProperty("last_selected_prod_idx", prodIdx);
  User.setProperty("last_selected_plan_idx", planIdx);

  User.setProperty("buy_prod_idx", prodIdx, "number");
  User.setProperty("buy_plan_idx", planIdx, "number");
  User.setProperty("buy_price", Number(price), "number");
  User.setProperty("buy_needpay", Number(needToPay), "number");
  User.setProperty("buy_prod_name", String(product.name).trim(), "string");
  User.setProperty("buy_plan_days", cleanPlanDays, "string");

  var genText = "<tg-emoji emoji-id='6147936236125298267'>⏳</tg-emoji> <b>Creating order for ₹" +
    needToPay.toFixed(2) + ", please wait...</b>";

  if (request && request.message) {
    Api.editMessageText({
      chat_id: String(chatId),
      message_id: Number(request.message.message_id),
      text: genText,
      parse_mode: "HTML"
    });
    // ✅ FIX: is "Creating order..." message ka ID save karo taaki QR photo
    // aane par ye properly delete (vanish) ho jaaye — pehle ye chat me stuck
    // reh jaata tha kyunki iska ID kahi track hi nahi hota tha.
    try {
      Bot.setProperty("gen_msg_id_" + userId, request.message.message_id, "string");
      User.setProperty("gen_msg_id_" + userId, request.message.message_id, "string");
    } catch (e) {}
  } else {
    var genMsg = Api.sendMessage({ chat_id: chatId, text: genText, parse_mode: "HTML" });
    try {
      var gmid = (genMsg && genMsg.result && genMsg.result.message_id) ? genMsg.result.message_id : (genMsg && genMsg.message_id ? genMsg.message_id : null);
      if (gmid) {
        Bot.setProperty("gen_msg_id_" + userId, gmid, "string");
        User.setProperty("gen_msg_id_" + userId, gmid, "string");
      }
    } catch (e) {}
  }

  var upi_id = Bot.getProperty("payment_upi_id") || "galureang@fam";

  HTTP.get({
    url: "https://fampay.anujbots.xyz/qr.php?upi=" + encodeURIComponent(upi_id) +
         "&amount=" + encodeURIComponent(needToPay.toFixed(2)),
    success: "/onQR",
    error: "/onApiError"
  });

  if (callbackId) {
    Api.answerCallbackQuery({
      callback_query_id: String(callbackId),
      text: "⏳ Generating QR...",
      show_alert: false
    });
  }

} catch (e) {
  var errChatId = (typeof chat !== "undefined" && chat && chat.chatid) ? chat.chatid : null;
  if (errChatId) {
    try { Api.sendMessage({ chat_id: errChatId, text: "❌ <b>Error:</b> <code>" + e.message + "</code>", parse_mode: "HTML" }); } catch (fatal) {}
  }
}