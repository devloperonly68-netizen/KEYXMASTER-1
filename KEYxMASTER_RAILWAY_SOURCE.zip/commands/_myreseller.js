/**#command
name: /myreseller
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var userId = user.telegramid;
  var isReseller = Bot.getProperty("is_reseller_" + userId);

  if (!isReseller) {
    Bot.sendMessage("<tg-emoji emoji-id='6143299028655280273'>❌</tg-emoji> Aapke paas reseller role nahi hai.", { parse_mode: "HTML" });
    return;
  }

  var name = user.first_name || "N/A";
  var username = user.username ? "@" + user.username : "N/A";

  var infoText = "<blockquote><b><tg-emoji emoji-id='5346024644635804737'>🔰</tg-emoji> MY RESELLER ACCOUNT INFO</b>\n\n" +
                 "• <b>Name:</b> " + name + "\n" +
                 "• <b>User ID:</b> <code>" + userId + "</code>\n" +
                 "• <b>Username:</b> " + username + "</blockquote>";

  Bot.sendMessage(infoText, { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("Error: " + err.message);
}