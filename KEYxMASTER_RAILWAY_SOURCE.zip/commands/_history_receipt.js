/**#command
name: /history_receipt
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🧾 Sends the user's full purchase history as a downloadable .txt file
// =========================================================

try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;
  var userKeys = User.getProperty("my_purchased_keys") || [];

  if (userKeys.length === 0) {
    Bot.sendMessage("<blockquote>🧾 <b>No purchase history found!</b>\n<i>Aapne abhi tak kuch bhi buy nahi kiya.</i></blockquote>", { parse_mode: "HTML" });
    return;
  }

  var lines = [];
  lines.push("=========================================");
  lines.push("       KEYxMASTER PANEL — PURCHASE RECEIPT");
  lines.push("=========================================");
  lines.push("User ID     : " + userId);
  lines.push("Name        : " + ((user.first_name || "") + (user.last_name ? " " + user.last_name : "")));
  lines.push("Username    : " + (user.username ? "@" + user.username : "N/A"));
  lines.push("Generated   : " + new Date().toLocaleString());
  lines.push("Total Orders: " + userKeys.length);
  lines.push("=========================================\n");

  var totalSpent = 0;
  for (var i = 0; i < userKeys.length; i++) {
    var k = userKeys[i];
    var pName = k.productName || k.product || "N/A";
    var pPrice = Number(k.cost || k.price || 0);
    var pKey = k.key || "N/A";
    var pDays = k.days || "N/A";
    var pDate = k.date || "N/A";
    totalSpent += pPrice;

    lines.push("Order #" + (i + 1));
    lines.push("-----------------------------------------");
    lines.push("Product   : " + pName);
    lines.push("Duration  : " + pDays);
    lines.push("Price     : Rs. " + pPrice.toFixed(2));
    lines.push("Key       : " + pKey);
    lines.push("Date      : " + pDate);
    lines.push("");
  }

  lines.push("=========================================");
  lines.push("Total Amount Spent: Rs. " + totalSpent.toFixed(2));
  lines.push("=========================================");
  lines.push("Thank you for shopping with KEYxMASTER PANEL!");

  var receiptText = lines.join("\n");

  Api.sendDocument({
    chat_id: chatId,
    document: {
      content: receiptText,
      filename: "Receipt_" + userId + ".txt"
    },
    caption: "<blockquote>🧾 <b>YOUR PURCHASE RECEIPT</b></blockquote>\n<i>Poori purchase history is file me hai.</i>",
    parse_mode: "HTML"
  });

  Api.sendMessage({
    chat_id: chatId,
    text: "<i>Receipt file bheji gayi hai upar 👆</i>",
    parse_mode: "HTML",
    reply_markup: JSON.stringify({
      inline_keyboard: [[
        { text: "Back to Menu", callback_data: "/back", style: "primary", icon_custom_emoji_id: "5893163582194978381" }
      ]]
    })
  });

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Receipt Error: " + err.message, { parse_mode: "HTML" });
}