/**#command
name: /onDeepLinkPlanShow
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var userId = user.telegramid;
  var chatId = User.getProperty("dl_wait_chatid") || chat.chatid;
  var loadingMsgId = User.getProperty("dl_wait_msgid");
  var matchedIdx = Number(User.getProperty("dl_wait_prodidx"));

  var productList = Bot.getProperty("stored_products") || [];
  var product = productList[matchedIdx];

  if (!product) {
    Bot.sendMessage("⚠️ Product data mismatch, dobara try karein.");
    return;
  }

  var isResellerDL = Bot.getProperty("is_reseller_" + userId) === true;
  var planButtons = [];
  var plans = product.plans || [];

  if (plans.length === 0) {
    plans = [
      { days: "1", normal_price: "79", reseller_price: "65" },
      { days: "7", normal_price: "350", reseller_price: "300" }
    ];
  }

  for (var j = 0; j < plans.length; j++) {
    var plan = plans[j];
    var cleanProdName = product.name.trim().toUpperCase();
    var cleanPlanDays = String(plan.days).replace(/[^0-9]/g, "").trim();

    var normalKey = "price_normal_" + cleanProdName + "_" + cleanPlanDays;
    var resellerKey = "price_reseller_" + cleanProdName + "_" + cleanPlanDays;

    var adminNormalPrice = Bot.getProperty(normalKey);
    var adminResellerPrice = Bot.getProperty(resellerKey);

    var currentNormal = (adminNormalPrice !== undefined && adminNormalPrice !== null) ? adminNormalPrice : plan.normal_price;
    var currentReseller = (adminResellerPrice !== undefined && adminResellerPrice !== null) ? adminResellerPrice : plan.reseller_price;

    var displayPrice = isResellerDL ? currentReseller : currentNormal;

    planButtons.push([{
      text: plan.days + " DAYS ➔ " + displayPrice + "₹",
      callback_data: "/buyitem " + matchedIdx + " " + j,
      style: "success",
      icon_custom_emoji_id: "5866053971960929280"
    }]);
  }

  planButtons.push([{
    text: "Back to Products",
    callback_data: "/buy_hack",
    style: "danger",
    icon_custom_emoji_id: "5893163582194978381"
  }]);

  var productEmojiId = product.emoji || "6266967801580231067";

  var productDLMsg = "<blockquote><tg-emoji emoji-id='6102856637343600044'>👑</tg-emoji> <b>PRODUCT: " + product.name.toUpperCase() + "</b></blockquote>\n\n" +
    "<tg-emoji emoji-id='6093677128295914531'>✏️</tg-emoji> <b>CHOOSE YOUR PLAN</b> <tg-emoji emoji-id='6093677128295914531'>✏️</tg-emoji>\n\n" +
    "<blockquote><tg-emoji emoji-id='6093854128193152827'>🎉</tg-emoji> Select your validity plan below to proceed with the secure order <tg-emoji emoji-id='6091571559233755994'>👉</tg-emoji></blockquote>";

  if (loadingMsgId) {
    Api.editMessageText({
      chat_id: String(chatId),
      message_id: Number(loadingMsgId),
      text: productDLMsg,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: planButtons })
    });
  } else {
    Api.sendMessage({
      chat_id: String(chatId),
      text: productDLMsg,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: planButtons })
    });
  }

  // cleanup
  User.setProperty("dl_wait_msgid", null, "number");
  User.setProperty("dl_wait_prodidx", null, "number");
  User.setProperty("dl_wait_chatid", null, "string");

} catch (err) {
  Bot.sendMessage("⚠️ Delay Callback Error: " + err.message);
}