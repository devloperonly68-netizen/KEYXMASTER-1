/**#command
name: /confirm_rem_prod
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var adminId = "7088682169";
  if (String(chat.chatid) !== adminId) return;

  var callbackId = request ? request.id : null;
  var targetIndex = params ? Number(params.trim()) : -1;

  if (targetIndex === -1 || isNaN(targetIndex)) {
    if (callbackId) Api.answerCallbackQuery({ callback_query_id: callbackId, text: "❌ Invalid product data index!", show_alert: true });
    return;
  }

  var productList = Bot.getProperty("stored_products") || [];

  if (productList.length === 0 || targetIndex >= productList.length) {
    if (callbackId) {
      Api.answerCallbackQuery({ callback_query_id: callbackId, text: "❌ Product already removed or missing!", show_alert: true });
    }
    return;
  }

  // Target product ko data array se nikalna (Delete execution)
  var removedProduct = productList[targetIndex];
  var removedName = removedProduct.name;
  
  productList.splice(targetIndex, 1); // Array modification

  // Updated array registry ko re-save karna
  Bot.setProperty("stored_products", productList, "json");

  var successText = "<blockquote><b>🗑️ PRODUCT SUCCESSFULLY REMOVED</b>\n\n" +
                    "• <b>Product Name:</b> <code>" + removedName.toUpperCase() + "</code>\n" +
                    "• <b>Status:</b> Completely wiped from database matrix.\n" +
                    "• <b>Remaining Products:</b> <code>" + productList.length + " Left</code></blockquote>";

  // Message window ko live text update edit dena
  if (request && request.message) {
    HTTP.post({
      url: "https://api.telegram.org/bot" + bot.token + "/editMessageText",
      body: {
        chat_id: String(chat.chatid),
        message_id: Number(request.message.message_id),
        text: successText,
        parse_mode: "HTML"
      }
    });
  } else {
    Bot.sendMessage(successText, { parse_mode: "HTML" });
  }

  if (callbackId) {
    Api.answerCallbackQuery({ callback_query_id: callbackId, text: "✅ Product Wiped!" });
  }

} catch (err) {
  Bot.sendMessage("⚠️ Execution Error: " + err.message);
}