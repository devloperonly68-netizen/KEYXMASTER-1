/**#command
name: /buy_hack
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🛒 SHOP MENU — Category selection (entry point of the whole buy flow)
// ✅ NEW: Shop Now ab seedha product list nahi, pehle "ANDROID ROOT" /
// "ANDROID NON ROOT" category selection dikhata hai. Product asli list
// /buy_hack_cat me dikhti hai (category ke hisaab se filter hokar).
// ✅ BUG FIX: reply_markup pehle raw object bheja jaa raha tha (JSON.stringify
// missing) — is wajah se product buttons kabhi kabhi properly render/work
// nahi karte the, jisse poora buy flow shuru hone se pehle hi tootta tha.
// ✅ BUG FIX: photo-message (jaise Profile) se yahan aane par editMessageText
// fail ho jaata — ab photo detect hoke delete + fresh send hota hai.
// ✅ Premium redesign.
// =========================================================

try {
  var rawData = Bot.getProperty("stored_products");
  var productList = [];

  if (Array.isArray(rawData)) {
    productList = rawData;
  } else if (typeof rawData === "string") {
    try {
      productList = JSON.parse(rawData);
      if (!Array.isArray(productList)) { productList = []; }
    } catch (e) {
      productList = [];
    }
  }

  // Agar list bilkul khali hai toh ek default product dal do taaki store khali na dikhe
  if (productList.length === 0) {
    productList.push({
      name: "Drip Client (Non Root)",
      emoji: "5226656353744862682",
      id: "1",
      category: "nonroot",
      plans: []
    });
    Bot.setProperty("stored_products", productList, "json");
  }

  var chatId = chat.chatid;
  var firstName = user && user.first_name ? user.first_name : "User";

  var categoryButtons = [
    [
      {
        text: "ANDROID NON ROOT",
        callback_data: "/buy_hack_cat nonroot",
        style: "primary",
        icon_custom_emoji_id: "6181418358055900195"
      }
    ],
    [
      {
        text: "ANDROID ROOT",
        callback_data: "/buy_hack_cat root",
        style: "primary",
        icon_custom_emoji_id: "5931415565955503486"
      }
    ],
    [
      {
        text: "iPHONE",
        callback_data: "/buy_hack_cat iphone",
        style: "primary",
        icon_custom_emoji_id: "6145197004768157529"
      }
    ],
    [
      {
        text: "Back to Menu",
        callback_data: "/back",
        style: "danger",
        icon_custom_emoji_id: "5893163582194978381"
      }
    ]
  ];

  var storeText =
    "<blockquote>🛒 <b>SELECT YOUR DEVICE TYPE</b> ✨</blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "<tg-emoji emoji-id='6091571559233755994'>👋</tg-emoji> <b>Yoo " + firstName + "!</b>\n" +
    "<i>Pehle apna device type chunein, uske baad products dikhenge.</i>\n" +
    "━━━━━━━━━━━━━━━━━━━━━";

  var replyMarkupStr = JSON.stringify({ inline_keyboard: categoryButtons });

  if (request && request.message && request.message.message_id) {
    if (request.message.photo) {
      try { Api.deleteMessage({ chat_id: chatId, message_id: request.message.message_id }); } catch (e) {}
      Api.sendMessage({ chat_id: chatId, text: storeText, parse_mode: "HTML", reply_markup: replyMarkupStr });
    } else {
      Api.editMessageText({
        chat_id: chatId,
        message_id: request.message.message_id,
        text: storeText,
        parse_mode: "HTML",
        reply_markup: replyMarkupStr
      });
    }
  } else {
    Api.sendMessage({ chat_id: chatId, text: storeText, parse_mode: "HTML", reply_markup: replyMarkupStr });
  }

  if (request && request.id) {
    try { Api.answerCallbackQuery({ callback_query_id: request.id }); } catch (e) {}
  }

} catch (err) {
  Bot.sendMessage("⚠️ Shop Menu Error: " + err.message, { parse_mode: "HTML" });
}