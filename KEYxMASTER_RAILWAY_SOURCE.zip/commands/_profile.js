/**#command
name: /profile
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 👤 COMMAND = /profile  (Premium Profile — Step 1: fetch user's DP)
// ✅ BUG FIX: pehle ek separate "Loading your premium profile..." message
// bhejke uska ID save karke baad me delete karne ki koshish hoti thi — lekin
// ID capture kabhi-kabhi chained HTTP.get callback ke through reliably
// propagate nahi hota tha, isliye ye "Loading..." message hamesha stuck reh
// jaata tha. Fix: ab koi separate loading message bheja hi nahi jaata — seedha
// DP fetch hoke turant final profile aata hai (delay itna chhota hai ki
// loading indicator ki zarurat hi nahi).
// =========================================================

try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;

  // ✅ Purani menu message ko clean karke hatate hain (agar button click se aaya ho)
  if (request && request.message && request.message.message_id) {
    try { Api.deleteMessage({ chat_id: chatId, message_id: request.message.message_id }); } catch (e) {}
  }

  // 📸 User ki Telegram DP fetch karo — response async /onProfilePhoto par aayega
  HTTP.get({
    url: "https://api.telegram.org/bot" + bot.token + "/getUserProfilePhotos?user_id=" + userId + "&limit=1",
    success: "/onProfilePhoto",
    error: "/onProfilePhoto"
  });

} catch (err) {
  Bot.sendMessage("⚠️ Profile Error: " + err.message, { parse_mode: "HTML" });
}