/**#command
name: /set_how_link_btn
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 📹 ADMIN PANEL BUTTON — "Set How To Use Link"
// Pressing this button prompts the admin to send the new video/tutorial
// link as a normal text message next; _start.js (MODULE 5) auto-captures
// that reply and forwards it to /set_how_link internally.
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var currentChatId = String(chat.chatid);
  var isCoAdmin = Bot.getProperty("co_admin_" + currentChatId);

  if (currentChatId !== adminId && !isCoAdmin) {
    Bot.sendMessage("❌ You are not authorized to use this.");
    return;
  }

  var currentLink = Bot.getProperty("how_to_use_link") || "https://youtu.be/oe2Ja08Vvpo (default)";

  User.setProperty("set_how_link_step", "waiting_input", "string");

  var promptText =
    "<blockquote><tg-emoji emoji-id='5258077307985207053'>📹</tg-emoji> <b>Set 'How To Use' Video Link</b></blockquote>\n\n" +
    "<i>Naya link (http/https) bhejein jo 'Watch Video Guide' button pe khulega.</i>\n\n" +
    "<b>Current link:</b> " + currentLink;

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;

  if (request && request.message && request.message.message_id) {
    try {
      Api.editMessageText({
        chat_id: String(chat.chatid),
        message_id: Number(request.message.message_id),
        text: promptText,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "Cancel", callback_data: "/admin", style: "danger" }]] })
      });
    } catch (e) {
      Api.sendMessage({ chat_id: chat.chatid, text: promptText, parse_mode: "HTML" });
    }
  } else {
    Bot.sendMessage(promptText, { parse_mode: "HTML" });
  }

  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
