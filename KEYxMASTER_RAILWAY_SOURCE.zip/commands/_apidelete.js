/**#command
name: /apidelete
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  var ownerId=String(Bot.getProperty("owner_id")||"7088682169"), uid=String(chat.chatid), co=Bot.getProperty("co_admin_"+uid);
  if(uid!==ownerId && !co) return;
  var id=params?String(params).trim():"", reg=Bot.getProperty("api_registry")||{};
  if(!id || !reg[id]){Bot.sendMessage("❌ Use <code>/apidelete API_ID</code>",{parse_mode:"HTML"});return;}
  if(Bot.getProperty("active_reseller_api")===id){Bot.sendMessage("❌ Active API ko pehle <code>/apiset OTHER_ID</code> se change karein.",{parse_mode:"HTML"});return;}
  delete reg[id]; Bot.setProperty("api_registry",reg,"json");
  Bot.sendMessage("✅ API <code>"+id+"</code> removed.",{parse_mode:"HTML"});
} catch(e){Bot.sendMessage("⚠️ API Delete Error: "+e.message);}
