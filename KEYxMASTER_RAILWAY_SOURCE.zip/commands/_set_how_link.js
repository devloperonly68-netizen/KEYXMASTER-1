/**#command
name: /set_how_link
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🔧 ADMIN — Configure the "How To Use" video/tutorial link
// Usage: /set_how_link https://youtu.be/xxxx
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "7088682169";
  var isCoAdmin0 = Bot.getProperty("co_admin_" + String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  if (!params || params.trim() === "") {
    var currentLink = Bot.getProperty("how_to_use_link") || "https://youtu.be/oe2Ja08Vvpo (default)";
    Bot.sendMessage(
      "⚠️ <b>Format:</b> <code>/set_how_link https://youtu.be/xxxx</code>\n\n" +
      "<b>Current link:</b> " + currentLink,
      { parse_mode: "HTML" }
    );
    return;
  }

  var link = params.trim();
  if (link.indexOf("http") !== 0) {
    Bot.sendMessage("❌ Link http:// ya https:// se shuru honi chahiye!");
    return;
  }

  Bot.setProperty("how_to_use_link", link, "string");
  Bot.sendMessage("✅ <b>How To Use link update ho gaya:</b>\n" + link, { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
