/**#command
name: /mykey
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🔑 MY KEYS — shows all purchased keys
// ✅ BUG FIXES:
// 1. Pehle photo message (Profile se aane par) editMessageText try karta tha
//    jo Telegram me fail hota hai — isi wajah se "My Keys" click karne par
//    kuch dikhta hi nahi tha.
// 2. catch(err) block errors ko SILENTLY hide kar raha tha — koi feedback
//    hi nahi milta tha jab kuch fail hota.
// 3. Raw HTTP.post use ho raha tha bina success/error handling ke — ab
//    consistent Api.* wrapper functions use hote hain (poore bot jaisa).
// =========================================================

try {
    let userKeys = User.getProperty("my_purchased_keys");
    let chatId = chat.chatid;

    let text = "";
    let keyboard = { inline_keyboard: [] };

    if (!userKeys || userKeys.length === 0) {
        text = "<blockquote>" +
            "<tg-emoji emoji-id='6192822213486321961'>🗣</tg-emoji> <b>No keys found!</b>\n" +
            "<tg-emoji emoji-id='5866053971960929280'>💎</tg-emoji> You haven't purchased anything yet." +
            "</blockquote>";

        keyboard.inline_keyboard = [
            [
                { text: "Shop Now", callback_data: "/buy_hack", style: "success", icon_custom_emoji_id: "5866053971960929280" },
                { text: "Back", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
            ]
        ];
    } else {
        text = "<b>📋 Your Active Keys:</b>\n\n";

        for (let i = 0; i < userKeys.length; i++) {
            let keyData = userKeys[i];
            let pName = keyData.productName || keyData.product || "N/A";
            let pPrice = keyData.cost || keyData.price || "0";
            let pKey = keyData.key || "No Key Found";
            let pDays = keyData.days || "N/A";
            let pDate = keyData.date || "N/A";

            text += "<blockquote>" +
                "<tg-emoji emoji-id='6192822213486321961'>🗣</tg-emoji> <b>Product Name:</b> " + pName + "\n" +
                "<tg-emoji emoji-id='6266967801580231067'>⏳</tg-emoji> <b>Days:</b> " + pDays + "\n" +
                "<tg-emoji emoji-id='6176966310920983412'>➡️</tg-emoji> <b>Key:</b> <code>" + pKey + "</code>\n" +
                "<tg-emoji emoji-id='6267068789146260253'>🛒</tg-emoji> <b>Price:</b> ₹" + pPrice + "\n" +
                "<tg-emoji emoji-id='5866053971960929280'>📅</tg-emoji> <b>Date:</b> " + pDate +
                "</blockquote>\n";
        }

        // Telegram caption/message length limits ke against safety trim (very large history)
        if (text.length > 3800) {
            text = text.substring(0, 3800) + "\n\n<i>... (list truncated — download full receipt from History)</i>";
        }

        keyboard.inline_keyboard = [
            [
                { text: "🧾 Download Receipt", callback_data: "/history_receipt", style: "primary", icon_custom_emoji_id: "6100170496077204999" }
            ],
            [
                { text: "Back To Menu", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
            ]
        ];
    }

    // ✅ FIX: photo-message ho to delete + fresh send, warna edit; Api.* wrapper use hota hai
    if (request && request.message && request.message.message_id) {
        if (request.message.photo) {
            try { Api.deleteMessage({ chat_id: chatId, message_id: request.message.message_id }); } catch (delErr) {}
            Api.sendMessage({ chat_id: chatId, text: text, parse_mode: "HTML", reply_markup: JSON.stringify(keyboard) });
        } else {
            Api.editMessageText({
                chat_id: chatId,
                message_id: request.message.message_id,
                text: text,
                parse_mode: "HTML",
                reply_markup: JSON.stringify(keyboard)
            });
        }
    } else {
        Api.sendMessage({ chat_id: chatId, text: text, parse_mode: "HTML", reply_markup: JSON.stringify(keyboard) });
    }

    var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
    if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
    // ✅ FIX: ab error silently hide nahi hoti — user ko dikhti hai
    try { Bot.sendMessage("⚠️ My Keys Error: " + err.message, { parse_mode: "HTML" }); } catch (e) {}
}