/**#command
name: /savepack
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Command: /savepack
// Admin Check (Aapki ID direct set hai)
if (String(user.telegramid) !== "7088682169") {
  Bot.sendMessage("❌ Only Admin can use this.");
  return;
}

Bot.sendMessage("📦 **Emoji Pack Registration**\n\nPehle apne naye pack ka ek short naam likh kar bhejiye (e.g., `pubg`, `buttons`):");

// Agle step par bhejne ke liye controller
Bot.runCommand("onGetPackName");