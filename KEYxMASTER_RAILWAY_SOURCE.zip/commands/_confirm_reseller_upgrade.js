/**#command
name: /confirm_reseller_upgrade
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 👑 Reseller Upgrade — Confirm button handler
// Balance sufficient -> instant upgrade. Insufficient -> shortfall QR
// (payment completion handled automatically in _onCheck.js).
// =========================================================

try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;

  if (Bot.getProperty("is_reseller_" + userId)) {
    Bot.sendMessage("💎 Aap already ek Reseller hain!");
    return;
  }

  var price = Number(Bot.getProperty("reseller_upgrade_price") || 0);
  if (!price) {
    Bot.sendMessage("❌ Reseller Upgrade price admin ne abhi set nahi kiya.");
    return;
  }

  var unifiedBal = (function () {
    var resBal = 0;
    try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
    var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
    return resBal + bonusBal;
  })();

  function grantReseller(chatIdTarget) {
    Bot.setProperty("is_reseller_" + userId, true, "boolean");
    var congratsText =
      "<blockquote><tg-emoji emoji-id='6102856637343600044'>🎉</tg-emoji> <b>CONGRATULATIONS!</b></blockquote>\n\n" +
      "<tg-emoji emoji-id='6215386799133433653'>👑</tg-emoji> <b>You are now a Reseller!</b>\n\n" +
      "<i>Aapko ab har product/plan par reseller pricing milegi, priority processing, aur reseller-only stock ka access. Enjoy your upgraded status!</i>";
    Api.sendMessage({
      chat_id: chatIdTarget,
      text: congratsText,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "Explore Shop", callback_data: "/buy_hack", style: "success", icon_custom_emoji_id: "5866053971960929280" }]] })
    });

    var ownerId = Bot.getProperty("owner_id") || "7088682169";
    try {
      Api.sendMessage({
        chat_id: ownerId,
        text: "👑 <b>NEW RESELLER!</b>\n👤 <b>User:</b> <code>" + userId + "</code>\n💰 <b>Paid:</b> ₹" + price.toFixed(2),
        parse_mode: "HTML"
      });
    } catch (e) {}
  }

  if (unifiedBal >= price) {
    try { Libs.ResourcesLib.userRes("balance").add(-price); } catch (e) {}
    grantReseller(chatId);
  } else {
    var needToPay = price - unifiedBal;
    User.setProperty("buy_reseller_upgrade", true, "boolean");
    User.setProperty("buy_reseller_price", price, "number");

    var genText = "<tg-emoji emoji-id='6100657257605763582'>⏳</tg-emoji> <b>Creating order for ₹" + needToPay.toFixed(2) + ", please wait...</b>";
    if (request && request.message) {
      Api.editMessageText({ chat_id: String(chatId), message_id: Number(request.message.message_id), text: genText, parse_mode: "HTML" });
      try {
        Bot.setProperty("gen_msg_id_" + userId, request.message.message_id, "string");
        User.setProperty("gen_msg_id_" + userId, request.message.message_id, "string");
      } catch (e) {}
    } else {
      var genMsg = Api.sendMessage({ chat_id: chatId, text: genText, parse_mode: "HTML" });
      try {
        var gmid = (genMsg && genMsg.result && genMsg.result.message_id) ? genMsg.result.message_id : (genMsg && genMsg.message_id ? genMsg.message_id : null);
        if (gmid) {
          Bot.setProperty("gen_msg_id_" + userId, gmid, "string");
          User.setProperty("gen_msg_id_" + userId, gmid, "string");
        }
      } catch (e) {}
    }

    var upi_id = Bot.getProperty("payment_upi_id") || "galureang@fam";
    HTTP.get({
      url: "https://fampay.anujbots.xyz/qr.php?upi=" + encodeURIComponent(upi_id) + "&amount=" + encodeURIComponent(needToPay.toFixed(2)),
      success: "/onQR",
      error: "/onApiError"
    });
  }

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}